# Alpha Security - Real-Time Sync Testing Guide

## 🎯 What Was Fixed/Implemented

### 1. **Persistent Login** ✅
- Users now stay logged in after closing the app
- Authentication state restored from secure storage
- No more repeated login prompts

### 2. **Profile Management** ✅
- New Settings screen in side menu
- Update email address
- Change password with current password verification
- Real-time validation and feedback

### 3. **Real-Time Synchronization** ✅
- WebSocket connection between mobile app and server
- Instant command execution (lock, unlock, alarm)
- Live status updates (location, battery, device state)
- Bidirectional communication

### 4. **Web Dashboard** ✅
- Complete remote control interface
- Live device monitoring
- Real-time command execution
- Interactive map with device locations

---

## 🧪 How to Test Everything

### Prerequisites
1. **Start the server:**
   ```bash
   cd C:\app\alpha-server
   npm start
   ```
   Server runs on: `http://localhost:3000`

2. **Build and run mobile app:**
   - Open Android Studio
   - Load `C:\app` project
   - Sync Gradle (downloads Socket.IO dependency)
   - Run on emulator or device

---

## Test #1: Persistent Login

**Steps:**
1. Open mobile app
2. Login/register
3. Use app normally
4. **CLOSE APP COMPLETELY** (swipe from recents)
5. Reopen app

**Expected Result:**
✅ App should open directly to home screen WITHOUT showing login page

**If it fails:**
- Check Logcat for `AuthManager` logs
- Verify SharedPreferences are working
- Ensure no crashes on startup

---

## Test #2: Profile Management

**Steps:**
1. Open mobile app
2. Tap hamburger menu (☰)
3. Scroll down and tap "Settings"
4. Try changing email:
   - Enter new email
   - Tap "UPDATE PROFILE"
5. Try changing password:
   - Enter current password
   - Enter new password
   - Confirm new password
   - Tap "UPDATE PROFILE"

**Expected Results:**
✅ Email updates successfully
✅ Password change requires current password
✅ Error messages show for invalid input
✅ Success message after update
✅ Can login with new credentials after logout

**Common Issues:**
- "Current password incorrect" → Verify you're entering the right password
- Network error → Check server is running
- API key missing → Logout and login again

---

## Test #3: Web Dashboard Control

### Setup:
1. Start server (if not already running)
2. Open browser: `http://localhost:3000/dashboard`
3. Login with same credentials as mobile app
4. Keep mobile app running in background

### Test Lock Command:
1. In dashboard, click on your device
2. Click "Lock Device" button
3. **Watch mobile phone** → Should lock within 1-2 seconds
4. ✅ Phone screen locks with message

### Test Alarm Command:
1. Click "Start Alarm"
2. **Listen to phone** → Alarm should play immediately
3. Click "Stop Alarm" to stop it
4. ✅ Alarm starts and stops on command

### Test Location:
1. Ensure location permission granted on mobile
2. Click "Locate Device" in dashboard
3. Wait 3-5 seconds
4. ✅ Map updates with current location

---

## Test #4: Real-Time Sync (Advanced)

### Using the Test Page:
1. Open: `http://localhost:3000/test-sync.html`
2. Watch for "WebSocket connected successfully"
3. Click test buttons and watch logs

**What to test:**
- 📍 Location Update → Should show in logs
- 📱 Device Status → Status changes logged
- ⚡ Command Execution → See command flow
- 🚨 Alarm Sync → Remote command received
- 🔒 Lock Sync → Lock command received

**Expected:**
✅ All messages show in event log
✅ Latency < 100ms for local network
✅ Messages counter increases
✅ Live data updates in real-time

---

## Test #5: End-to-End Flow

This tests the complete workflow:

1. **Mobile Side:**
   - Register device (happens automatically on first location share)
   - Keep app running with screen on

2. **Web Side:**
   - Login to dashboard
   - Find device in list
   - Device should show "Online" status
   - Battery level should be visible
   - Last seen time should be recent

3. **Send Command:**
   - Click on device
   - Click "Lock Device"
   - **Watch mobile → Locks in 1-2 seconds**

4. **Verify Sync:**
   - Dashboard updates lock status icon
   - Recent activity log shows command
   - Mobile shows lock screen

5. **Send Location:**
   - On mobile, use Anti-Theft → Track Location
   - **Watch dashboard → Map updates**
   - New marker appears on map

---

## 🔍 Debugging Tools

### Check Mobile App Logs:
```
Android Studio → Logcat
Filter: "RemoteCommandService" or "Alpha"
```

**Key logs to look for:**
```
RemoteCommandService: Connected to server
RemoteCommandService: Joined device room: <device-id>
RemoteCommandService: Received remote command: LOCK_DEVICE
RemoteCommandService: Command response sent: <command-id> - completed
```

### Check Server Logs:
```
Look in terminal where server is running
```

**Key logs:**
```
Client connected: <socket-id>
Device <device-id> joined room
Command sent to device...
```

### Check Database:
```bash
cd C:\app\alpha-server
sqlite3 data/alpha-security.db
```

**Useful queries:**
```sql
-- Check devices
SELECT * FROM devices;

-- Check commands
SELECT * FROM commands ORDER BY sent_at DESC LIMIT 10;

-- Check locations
SELECT * FROM location_history ORDER BY timestamp DESC LIMIT 10;

-- Check device logs
SELECT * FROM device_logs ORDER BY timestamp DESC LIMIT 20;
```

---

## 🐛 Common Issues & Solutions

### Issue: Mobile app not connecting to WebSocket

**Solution:**
1. Check `ServerConfig.kt`:
   ```kotlin
   const val SERVER_BASE_URL = "http://10.0.2.2:3000"  // For emulator
   // OR
   const val SERVER_BASE_URL = "http://YOUR_IP:3000"  // For real device
   ```
2. Ensure server is reachable from device
3. Check notification bar for "Remote command service active"

### Issue: Commands not executing

**Checks:**
1. Device Admin enabled? (Go to Anti-Theft screen)
2. Location permission granted?
3. WebSocket connected? (Check notification)
4. Server running?
5. Correct API key?

### Issue: Location not updating

**Solution:**
1. Grant location permission in Android settings
2. Enable GPS on device
3. Go outdoors or use location simulation in emulator
4. Check for location permission errors in Logcat

### Issue: Dashboard not showing devices

**Solution:**
1. Device must be registered (happens automatically)
2. Device must have shared location at least once
3. Check if API key matches between mobile and web
4. Try refreshing dashboard
5. Check browser console for errors (F12)

---

## 📊 Performance Expectations

### Latency:
- **Local network:** < 50ms
- **Same WiFi:** < 100ms
- **Mobile data:** 200-500ms

### Command Execution:
- **Lock device:** 1-2 seconds
- **Start alarm:** < 1 second
- **Location update:** 3-5 seconds (GPS acquisition time)

### Battery Impact:
- **WebSocket service:** ~2-3% per hour (minimal)
- **Location tracking:** Depends on frequency
- Foreground service required for background operation

---

## ✅ Success Criteria

All these should work:

- ✅ Login once, never asked again
- ✅ Update email from mobile app
- ✅ Change password from mobile app
- ✅ Lock phone from web dashboard (< 2 sec)
- ✅ Start/stop alarm from web (< 1 sec)
- ✅ See live location on map
- ✅ Device status updates in real-time
- ✅ Battery level shows correctly
- ✅ Online/offline status accurate
- ✅ Commands logged in history
- ✅ No crashes or freezes

---

## 🚀 Production Deployment

Before deploying to production:

1. **Security:**
   - Change JWT_SECRET in `.env`
   - Use HTTPS for server
   - Enable proper CORS settings
   - Rate limit sensitive endpoints

2. **Mobile App:**
   - Update SERVER_BASE_URL to production URL
   - Use release build with ProGuard
   - Test on multiple Android versions

3. **Server:**
   - Set NODE_ENV=production
   - Use process manager (PM2)
   - Configure reverse proxy (Nginx)
   - Setup SSL certificates
   - Monitor logs and errors

4. **Database:**
   - Regular backups
   - Index optimization
   - Cleanup old logs periodically

---

## 📞 Need Help?

**Check logs first:**
- Mobile: Android Studio Logcat
- Server: Terminal output
- Browser: Developer Console (F12)

**Common log locations:**
- Mobile: Filter for "Alpha" or "RemoteCommandService"
- Server: Console output with colored logs
- Database: `alpha-server/data/alpha-security.db`

---

## 🎉 That's It!

You now have a fully functional, real-time synchronized security application with:
- Persistent authentication
- Profile management
- Remote device control
- Live status monitoring
- WebSocket-based communication

**Enjoy your Alpha Security Suite!** 🛡️
