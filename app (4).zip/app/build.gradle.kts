// Top-level build file where you can add configuration options common to all sub-projects/modules.
plugins {
    // Updated Android Gradle Plugin to the latest stable version (8.7.2)
    id("com.android.application") version "8.7.2" apply false

    // Updated Kotlin plugin to latest compatible with AGP 8.7.x
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
    
    // Google Services plugin for Firebase
    id("com.google.gms.google-services") version "4.4.2" apply false
}
