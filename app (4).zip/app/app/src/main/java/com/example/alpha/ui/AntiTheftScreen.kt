package com.example.alpha.ui

import android.Manifest
import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.alpha.features.antitheft.AntiTheftManager
import com.example.alpha.device.AdminReceiver
import com.example.alpha.ui.components.GradientButton
import com.example.alpha.ui.components.ScreenScaffold
import com.example.alpha.ui.components.BackgroundVariant
import com.example.alpha.ui.theme.*
import com.example.alpha.config.ServerConfig
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AntiTheftScreen(
    onBack: () -> Unit,
    onOpenDrawer: () -> Unit = {}
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val adminComponent = ComponentName(context, AdminReceiver::class.java)
    val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
    var isAdminActive by remember { mutableStateOf(dpm.isAdminActive(adminComponent)) }

    val antiTheftManager = remember { AntiTheftManager(context, adminComponent) }

    // Use a stable device ID for this app session so registration, location
    // uploads, and command polling all refer to the same device on the server.
    val deviceId = remember { ServerConfig.getDeviceId() }

    val deviceAdminLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { _ ->
        isAdminActive = dpm.isAdminActive(adminComponent)
    }

    val locationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { /* handle results */ }

    var showConfirmWipe by remember { mutableStateOf(false) }

    // Poll the server for pending commands while this screen is visible.
    LaunchedEffect(deviceId) {
        while (true) {
            antiTheftManager.processServerCommands(deviceId)
            delay(15_000) // every 15 seconds
        }
    }

    ScreenScaffold(
        title = "Anti-Theft Protection",
        onBack = onBack,
        onOpenDrawer = onOpenDrawer,
        backgroundVariant = BackgroundVariant.Security
    ) { padding ->

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

                Text(
                    if (isAdminActive) "Device Admin: ENABLED" else "Device Admin: DISABLED",
                    color = if (isAdminActive) SuccessGreen else ErrorRed,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )

                GradientButton(
                    text = if (isAdminActive) "Disable Device Admin" else "Enable Device Admin",
                    icon = Icons.Filled.Security,
                    color1 = PrimaryCyberBlue,
                    color2 = NeonPurple
                ) {
                    if (!isAdminActive) {
                        val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
                            putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComponent)
                            putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Alpha needs device admin for lock and wipe features.")
                        }
                        deviceAdminLauncher.launch(intent)
                    } else {
                        dpm.removeActiveAdmin(adminComponent)
                        isAdminActive = false
                    }
                }

                GradientButton(
                    text = "Grant Location Permission",
                    icon = Icons.Filled.LocationOn,
                    color1 = NeonGreen,
                    color2 = PrimaryCyberBlue
                ) {
                    locationPermissionLauncher.launch(arrayOf(
                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION
                    ))
                }

                AnimatedVisibility(visible = isAdminActive) {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        GradientButton(
                            text = "Lock Device",
                            icon = Icons.Filled.Lock,
                            color1 = PrimaryCyberBlue,
                            color2 = NeonPurple
                        ) {
                            antiTheftManager.lockDevice()
                        }

                        GradientButton(
                            text = "Locate Device",
                            icon = Icons.Filled.MyLocation,
                            color1 = NeonGreen,
                            color2 = SuccessGreen
                        ) {
                            scope.launch {
                                antiTheftManager.fetchLocationAndUpload(
                                    serverUrl = ServerConfig.getLocationUploadUrl(),
                                    deviceId = deviceId
                                )
                            }
                        }

                        GradientButton(
                            text = "Start Alarm",
                            icon = Icons.Filled.Alarm,
                            color1 = NeonOrange,
                            color2 = ErrorRed
                        ) {
                            antiTheftManager.startAlarm()
                        }

                        GradientButton(
                            text = "Stop Alarm",
                            icon = Icons.Filled.AlarmOff,
                            color1 = NeonGreen,
                            color2 = SuccessGreen
                        ) {
                            antiTheftManager.stopAlarm()
                        }

                        GradientButton(
                            text = "Factory Reset (Wipe)",
                            icon = Icons.Filled.Delete,
                            color1 = ErrorRed,
                            color2 = NeonOrange
                        ) {
                            showConfirmWipe = true
                        }
                    }
                }
        }
        
        if (showConfirmWipe) {
            AlertDialog(
                onDismissRequest = { showConfirmWipe = false },
                title = { Text("Confirm Factory Reset", color = TextPrimary) },
                text = { Text("This will ERASE all data on the device. Proceed?", color = TextSecondary) },
                confirmButton = {
                    TextButton(onClick = {
                        antiTheftManager.wipeDevice()
                        showConfirmWipe = false
                    }) { Text("Confirm", color = ErrorRed) }
                },
                dismissButton = {
                    TextButton(onClick = { showConfirmWipe = false }) {
                        Text("Cancel", color = TextSecondary)
                    }
                },
                containerColor = Color(0xFF1B0033),
                textContentColor = TextPrimary
            )
        }
    }
}
