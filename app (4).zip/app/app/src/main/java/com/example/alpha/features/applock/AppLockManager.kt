package com.example.alpha.features.applock

import android.content.Intent
import android.provider.Settings
import android.content.Context
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.alpha.device.AdminReceiver
import com.example.alpha.ui.components.GradientButton

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DeviceAdminScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
    val componentName = ComponentName(context, AdminReceiver::class.java)
    val isActive = dpm.isAdminActive(componentName)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Anti-Theft", fontWeight = FontWeight.Bold, color = Color.White) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.mediumTopAppBarColors(containerColor = Color.Transparent)
            )
        },
        containerColor = Color.Transparent
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(listOf(Color(0xFF0E0E10), Color(0xFF121224)))
                )
                .padding(padding)
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Status
            StatusCard(
                active = isActive,
                activeText = "Device Admin Active",
                inactiveText = "Protection Disabled"
            )

            // Actions
            GradientButton("Activate Device Admin", Icons.Filled.Shield) {
                enableDeviceAdmin(context, componentName)
            }
            GradientButton("Lock Device", Icons.Filled.Lock) {
                if (isActive) dpm.lockNow()
            }
            GradientButton("Factory Reset", Icons.Filled.Warning, Color(0xFFFF1744), Color(0xFFD500F9)) {
                if (isActive) dpm.wipeData(0)
            }
            GradientButton("Open Location Settings", Icons.Filled.LocationOn) {
                val intent = Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
                context.startActivity(intent)
            }
        }
    }
}

@Composable
fun StatusCard(active: Boolean, activeText: String, inactiveText: String) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.08f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                if (active) Icons.Filled.Shield else Icons.Filled.Warning,
                contentDescription = null,
                tint = if (active) Color(0xFF00E5FF) else Color(0xFFFF4081),
                modifier = Modifier.size(40.dp)
            )
            Spacer(Modifier.height(8.dp))
            Text(
                if (active) activeText else inactiveText,
                color = Color.White,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

private fun enableDeviceAdmin(context: Context, componentName: ComponentName) {
    val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
        putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, componentName)
        putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Enable Alpha’s Anti-Theft protection.")
    }
    context.startActivity(intent)
}
