package com.example.alpha.ui

import android.content.Context
import android.net.Uri
import android.text.format.Formatter
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Backspace
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Pattern
import androidx.compose.material.icons.filled.Pin
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import com.example.alpha.ui.components.BackgroundVariant
import com.example.alpha.ui.components.GradientButton
import com.example.alpha.ui.components.ScreenScaffold
import com.example.alpha.ui.theme.ErrorRed
import com.example.alpha.ui.theme.NeonGreen
import com.example.alpha.ui.theme.NeonOrange
import com.example.alpha.ui.theme.PrimaryCyberBlue
import com.example.alpha.ui.theme.SuccessGreen
import com.example.alpha.ui.theme.SurfaceGlass
import com.example.alpha.ui.theme.TextPrimary
import com.example.alpha.ui.theme.TextSecondary
import com.example.alpha.ui.theme.TextTertiary
import com.example.alpha.ui.theme.WarningAmber
import com.example.alpha.vault.VaultManager
import com.example.alpha.vault.formatFileSize
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppVaultScreen(
    onBack: () -> Unit,
    onOpenDrawer: () -> Unit = {}
) {
    val context = LocalContext.current
    val vaultManager = remember { VaultManager(context) }
    val documentVaultManager = remember { com.example.alpha.vault.DocumentVaultManager(context) }
    var vaultUnlocked by remember { mutableStateOf(false) }
    var selectedTab by remember { mutableStateOf(0) }
    val scope = rememberCoroutineScope()

    ScreenScaffold(
        title = "App & Document Vault",
        onBack = onBack,
        onOpenDrawer = onOpenDrawer,
        backgroundVariant = BackgroundVariant.Security
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp),
            verticalArrangement = Arrangement.Top,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (!vaultUnlocked) {
                LockedVaultUI(
                    onUnlock = {
                        vaultUnlocked = true
                        documentVaultManager.unlock()
                        Toast.makeText(context, "Vault Unlocked", Toast.LENGTH_SHORT).show()
                    }
                )
            } else {
                // 🔹 Tabs for App Vault & Doc Vault
                TabRow(selectedTabIndex = selectedTab, containerColor = Color.Transparent) {
                    Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("App Vault") })
                    Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("Doc Vault") })
                }

                Spacer(Modifier.height(16.dp))

                if (selectedTab == 0) {
                    AppVaultUI(vaultManager, context)
                } else {
                    DocVaultUI(documentVaultManager, scope)
                }
            }
        }
    }
}

/* 🔒 Locked vault UI */
@Composable
fun LockedVaultUI(onUnlock: () -> Unit) {
    val context = LocalContext.current
    val activity = context as? FragmentActivity
    var showPinInput by remember { mutableStateOf(false) }
    var pinInput by remember { mutableStateOf("") }
    var authMethod by remember { mutableStateOf("biometric") } // "biometric", "pin", "password"
    
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        elevation = CardDefaults.cardElevation(defaultElevation = 12.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.linearGradient(
                        colors = listOf(
                            Color(0xFF1A237E).copy(alpha = 0.3f),
                            Color(0xFF3949AB).copy(alpha = 0.2f),
                            Color.Transparent
                        )
                    )
                )
                .border(
                    2.dp,
                    Color(0xFF3949AB).copy(alpha = 0.5f),
                    RoundedCornerShape(24.dp)
                )
                .padding(32.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    Icons.Filled.Lock, 
                    null, 
                    tint = PrimaryCyberBlue, 
                    modifier = Modifier.size(64.dp)
                )
                Spacer(Modifier.height(16.dp))
                Text(
                    "Vault Locked", 
                    color = TextPrimary, 
                    fontWeight = FontWeight.Bold, 
                    fontSize = 20.sp
                )
                Text(
                    "Choose authentication method to unlock your vault", 
                    color = TextSecondary,
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                )
                
                Spacer(Modifier.height(24.dp))
                
                if (showPinInput) {
                    PinInputSection(
                        pinInput = pinInput,
                        onPinChange = { pinInput = it },
                        onUnlock = {
                            if (pinInput == "1234") { // Demo PIN
                                onUnlock()
                            } else {
                                Toast.makeText(context, "Incorrect PIN", Toast.LENGTH_SHORT).show()
                                pinInput = ""
                            }
                        },
                        onBack = { 
                            showPinInput = false
                            pinInput = ""
                        }
                    )
                } else {
                    // Authentication method buttons
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Biometric Authentication
                        AnimatedActionButton(
                            Icons.Filled.Fingerprint, 
                            "Biometric Unlock", 
                            PrimaryCyberBlue
                        ) {
                            if (activity != null) {
                                authenticateUser(activity) { success ->
                                    if (success) onUnlock()
                                }
                            } else {
                                Toast.makeText(context, "Authentication not available", Toast.LENGTH_SHORT).show()
                            }
                        }
                        
                        // PIN Authentication
                        AnimatedActionButton(
                            Icons.Filled.Pin, 
                            "PIN Unlock", 
                            NeonGreen
                        ) {
                            showPinInput = true
                        }
                        
                        // Pattern or Password (Demo)
                        AnimatedActionButton(
                            Icons.Filled.Pattern, 
                            "Pattern Unlock", 
                            NeonOrange
                        ) {
                            // Demo - instant unlock for pattern
                            Toast.makeText(context, "Pattern authenticated", Toast.LENGTH_SHORT).show()
                            onUnlock()
                        }
                    }
                }
                
                Spacer(Modifier.height(16.dp))
                
                Text(
                    "Demo PIN: 1234",
                    color = TextTertiary,
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}

/* 🧩 App Vault */
@Composable
fun AppVaultUI(vaultManager: VaultManager, context: Context) {
    val vaultItems by vaultManager.vaultItems.collectAsState()
    
    // If no items, show some default secure apps
    val displayItems = if (vaultItems.isEmpty()) {
        listOf("WhatsApp", "Instagram", "Banking App")
    } else {
        vaultItems
    }

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        items(displayItems.size) { index ->
            VaultItemCard(
                title = displayItems[index],
                icon = Icons.Filled.Apps, 
                color = Color(0xFF3949AB),
                onRemove = if (vaultItems.isNotEmpty()) {
                    { vaultManager.removeItem(displayItems[index]) }
                } else null
            )
        }

        item {
            GradientButton(
                text = "Secure New App",
                icon = Icons.Filled.Add,
                color1 = Color(0xFF283593),
                color2 = Color(0xFF512DA8)
            ) {
                // Add app selection dialog logic here
                val newApp = "Secured App ${(displayItems.size + 1)}"
                vaultManager.addItem(newApp)
                Toast.makeText(context, "$newApp added to vault", Toast.LENGTH_SHORT).show()
            }
        }
    }
}

/* 📂 Doc Vault */
@Composable
fun DocVaultUI(
    documentVaultManager: com.example.alpha.vault.DocumentVaultManager,
    scope: kotlinx.coroutines.CoroutineScope
) {
    val context = LocalContext.current
    val securedDocuments by documentVaultManager.securedDocuments.collectAsState()
    val vaultSize = remember { mutableStateOf(documentVaultManager.getTotalVaultSize()) }

    val filePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent(),
        onResult = { uri: Uri? ->
            uri?.let { selectedUri ->
                // Get file name from URI
                val fileName = try {
                    context.contentResolver.query(selectedUri, null, null, null, null)?.use { cursor ->
                        val nameIndex = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                        cursor.moveToFirst()
                        cursor.getString(nameIndex)
                    } ?: "Document_${System.currentTimeMillis()}"
                } catch (e: Exception) {
                    "Document_${System.currentTimeMillis()}"
                }
                
                scope.launch {
                    val result = documentVaultManager.addDocument(selectedUri, fileName)
                    result.onSuccess {
                        vaultSize.value = documentVaultManager.getTotalVaultSize()
                        Toast.makeText(context, "Document secured: $fileName", Toast.LENGTH_SHORT).show()
                    }.onFailure { error ->
                        Toast.makeText(context, "Failed to secure document: ${error.message}", Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
    )

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        // Vault info header
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = PrimaryCyberBlue.copy(alpha = 0.1f))
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Filled.FolderOpen,
                        contentDescription = null,
                        tint = PrimaryCyberBlue,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "${securedDocuments.size} Documents",
                            color = TextPrimary,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        val context = LocalContext.current

                        Text(
                            text = "Vault Size: ${Formatter.formatFileSize(context, vaultSize.value.toLong())}",
                            color = TextSecondary,
                            style = MaterialTheme.typography.bodySmall
                        )

                    }
                }
            }
        }
        
        if (securedDocuments.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.05f))
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            Icons.Filled.Description,
                            contentDescription = null,
                            tint = Color(0xFF00ACC1),
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(Modifier.height(16.dp))
                        Text(
                            "No documents secured yet",
                            color = Color.White,
                            fontWeight = FontWeight.Medium,
                            fontSize = 16.sp
                        )
                        Text(
                            "Add documents to keep them safe",
                            color = Color.White.copy(alpha = 0.7f),
                            fontSize = 14.sp
                        )
                    }
                }
            }
        } else {
            items(securedDocuments.size) { index ->
                val doc = securedDocuments[index]
                SecuredDocumentCard(
                    document = doc,
                    onOpen = {
                        scope.launch {
                            val result = documentVaultManager.getDecryptedDocument(doc.id)
                            result.onSuccess { file ->
                                // Open file with intent
                                try {
                                    val uri = androidx.core.content.FileProvider.getUriForFile(
                                        context,
                                        "${context.packageName}.fileprovider",
                                        file
                                    )
                                    val intent = android.content.Intent(android.content.Intent.ACTION_VIEW).apply {
                                        setDataAndType(uri, doc.mimeType)
                                        addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                    }
                                    context.startActivity(intent)
                                } catch (e: Exception) {
                                    Toast.makeText(context, "No app to open this file", Toast.LENGTH_SHORT).show()
                                }
                            }.onFailure { error ->
                                Toast.makeText(context, "Failed to open: ${error.message}", Toast.LENGTH_SHORT).show()
                            }
                        }
                    },
                    onRemove = {
                        scope.launch {
                            val success = documentVaultManager.removeDocument(doc.id)
                            if (success) {
                                vaultSize.value = documentVaultManager.getTotalVaultSize()
                                Toast.makeText(context, "Document removed", Toast.LENGTH_SHORT).show()
                            } else {
                                Toast.makeText(context, "Failed to remove document", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                )
            }
        }

        item {
            GradientButton(
                text = "Add Secure Document",
                icon = Icons.Filled.Add,
                color1 = Color(0xFF00BCD4),
                color2 = Color(0xFF7C4DFF)
            ) {
                filePicker.launch("*/*")
            }
        }
    }
}

/* 🧧 Reusable vault item card */
@Composable
fun VaultItemCard(
    title: String, 
    icon: androidx.compose.ui.graphics.vector.ImageVector, 
    color: Color,
    onRemove: (() -> Unit)? = null
) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = color.copy(alpha = 0.15f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(16.dp)
        ) {
            Icon(icon, null, tint = color, modifier = Modifier.size(30.dp))
            Spacer(Modifier.width(12.dp))
            Text(
                text = title, 
                color = Color.White, 
                fontWeight = FontWeight.Medium, 
                fontSize = 16.sp,
                modifier = Modifier.weight(1f)
            )
            
            if (onRemove != null) {
                IconButton(
                    onClick = onRemove,
                    modifier = Modifier.size(24.dp)
                ) {
                    Icon(
                        Icons.Filled.DeleteOutline,
                        contentDescription = "Remove",
                        tint = Color(0xFFFF4081),
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}

/* 🔹 Animated button */
@Composable
fun AnimatedActionButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    text: String,
    color: Color,
    onClick: () -> Unit
) {
    var pressed by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (pressed) 0.96f else 1f, animationSpec = spring(), label = "")
    val interactionSource = remember { MutableInteractionSource() }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(60.dp)
            .scale(scale)
            .background(color, RoundedCornerShape(18.dp))
            .clickable(
                interactionSource = interactionSource,
                indication = null // ✅ uses default M3 ripple under the hood
            ) {
                pressed = true
                onClick()
                pressed = false
            },
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Color.White, modifier = Modifier.size(22.dp))
            Spacer(Modifier.width(10.dp))
            Text(text, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Medium)
        }
    }
}

@Composable
fun PinInputSection(
    pinInput: String,
    onPinChange: (String) -> Unit,
    onUnlock: () -> Unit,
    onBack: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            "Enter PIN",
            color = TextPrimary,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )
        
        // PIN Display
        Row(
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            repeat(4) { index ->
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .background(
                            if (index < pinInput.length) PrimaryCyberBlue.copy(alpha = 0.3f) else SurfaceGlass,
                            CircleShape
                        )
                        .border(
                            2.dp,
                            if (index < pinInput.length) PrimaryCyberBlue else SurfaceGlass,
                            CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    if (index < pinInput.length) {
                        Box(
                            modifier = Modifier
                                .size(12.dp)
                                .background(PrimaryCyberBlue, CircleShape)
                        )
                    }
                }
            }
        }
        
        Spacer(Modifier.height(16.dp))
        
        // Number Pad
        Column(
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Row 1: 1, 2, 3
            Row(
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                repeat(3) { index ->
                    NumberPadButton(
                        number = (index + 1).toString(),
                        onClick = {
                            if (pinInput.length < 4) {
                                onPinChange(pinInput + (index + 1))
                            }
                        }
                    )
                }
            }
            
            // Row 2: 4, 5, 6
            Row(
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                repeat(3) { index ->
                    NumberPadButton(
                        number = (index + 4).toString(),
                        onClick = {
                            if (pinInput.length < 4) {
                                onPinChange(pinInput + (index + 4))
                            }
                        }
                    )
                }
            }
            
            // Row 3: 7, 8, 9
            Row(
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                repeat(3) { index ->
                    NumberPadButton(
                        number = (index + 7).toString(),
                        onClick = {
                            if (pinInput.length < 4) {
                                onPinChange(pinInput + (index + 7))
                            }
                        }
                    )
                }
            }
            
            // Row 4: Back, 0, Check
            Row(
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Back button
                IconButton(
                    onClick = onBack,
                    modifier = Modifier
                        .size(64.dp)
                        .background(ErrorRed.copy(alpha = 0.2f), CircleShape)
                ) {
                    Icon(
                        Icons.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = ErrorRed
                    )
                }
                
                // Zero
                NumberPadButton(
                    number = "0",
                    onClick = {
                        if (pinInput.length < 4) {
                            onPinChange(pinInput + "0")
                        }
                    }
                )
                
                // Check/Enter button
                IconButton(
                    onClick = {
                        if (pinInput.length == 4) {
                            onUnlock()
                        }
                    },
                    enabled = pinInput.length == 4,
                    modifier = Modifier
                        .size(64.dp)
                        .background(
                            if (pinInput.length == 4) SuccessGreen.copy(alpha = 0.2f) else SurfaceGlass,
                            CircleShape
                        )
                ) {
                    Icon(
                        Icons.Filled.Check,
                        contentDescription = "Confirm",
                        tint = if (pinInput.length == 4) SuccessGreen else TextTertiary
                    )
                }
            }
        }
        
        // Delete button
        if (pinInput.isNotEmpty()) {
            IconButton(
                onClick = {
                    onPinChange(pinInput.dropLast(1))
                },
                modifier = Modifier
                    .background(WarningAmber.copy(alpha = 0.2f), CircleShape)
                    .size(48.dp)
            ) {
                Icon(
                    Icons.Filled.Backspace,
                    contentDescription = "Delete",
                    tint = WarningAmber
                )
            }
        }
    }
}

@Composable
fun NumberPadButton(
    number: String,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        modifier = Modifier.size(64.dp),
        shape = CircleShape,
        colors = ButtonDefaults.buttonColors(
            containerColor = SurfaceGlass,
            contentColor = TextPrimary
        )
    ) {
        Text(
            text = number,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )
    }
}

/* 🔐 Biometric authentication */
private fun authenticateUser(activity: FragmentActivity, onResult: (Boolean) -> Unit) {
    val context = activity as Context
    val executor = ContextCompat.getMainExecutor(context)
    val biometricManager = BiometricManager.from(context)

    // Check what type of authentication is available
    val authenticators = when {
        biometricManager.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG) == BiometricManager.BIOMETRIC_SUCCESS -> {
            BiometricManager.Authenticators.BIOMETRIC_STRONG
        }
        biometricManager.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK) == BiometricManager.BIOMETRIC_SUCCESS -> {
            BiometricManager.Authenticators.BIOMETRIC_WEAK
        }
        biometricManager.canAuthenticate(BiometricManager.Authenticators.DEVICE_CREDENTIAL) == BiometricManager.BIOMETRIC_SUCCESS -> {
            BiometricManager.Authenticators.DEVICE_CREDENTIAL
        }
        else -> {
            // Try biometric with device credential fallback
            BiometricManager.Authenticators.BIOMETRIC_WEAK or BiometricManager.Authenticators.DEVICE_CREDENTIAL
        }
    }

    val promptInfoBuilder = BiometricPrompt.PromptInfo.Builder()
        .setTitle("Unlock Alpha Vault")
        .setSubtitle("Authenticate to access your secure vault")
        .setAllowedAuthenticators(authenticators)

    // Only add negative button if not using device credentials
    if (authenticators and BiometricManager.Authenticators.DEVICE_CREDENTIAL == 0) {
        promptInfoBuilder.setNegativeButtonText("Cancel")
    }

    val promptInfo = promptInfoBuilder.build()

    try {
        val biometricPrompt = BiometricPrompt(
            context as FragmentActivity,
            executor,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    super.onAuthenticationSucceeded(result)
                    Toast.makeText(context, "Authentication successful", Toast.LENGTH_SHORT).show()
                    onResult(true)
                }
                
                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    super.onAuthenticationError(errorCode, errString)
                    if (errorCode != BiometricPrompt.ERROR_USER_CANCELED) {
                        Toast.makeText(context, "Authentication error: $errString", Toast.LENGTH_LONG).show()
                    }
                    onResult(false)
                }
                
                override fun onAuthenticationFailed() {
                    super.onAuthenticationFailed()
                    Toast.makeText(context, "Authentication failed - please try again", Toast.LENGTH_SHORT).show()
                }
            }
        )
        biometricPrompt.authenticate(promptInfo)
    } catch (e: Exception) {
        Toast.makeText(context, "Biometric authentication not available. Please use PIN.", Toast.LENGTH_LONG).show()
        onResult(false)
    }
}

/* 📄 Secured Document Card */
@Composable
fun SecuredDocumentCard(
    document: com.example.alpha.vault.SecuredDocument,
    onOpen: () -> Unit,
    onRemove: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF00ACC1).copy(alpha = 0.15f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(
                    Icons.Filled.Description,
                    contentDescription = null,
                    tint = Color(0xFF00ACC1),
                    modifier = Modifier.size(32.dp)
                )
                Spacer(Modifier.width(12.dp))
                Column(
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = document.displayName,
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        maxLines = 1,
                        overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = document.originalSize.formatFileSize(),
                        color = TextSecondary,
                        fontSize = 12.sp
                    )
                }
                
                IconButton(
                    onClick = onRemove,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        Icons.Filled.DeleteOutline,
                        contentDescription = "Remove",
                        tint = Color(0xFFFF4081),
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
            
            Spacer(Modifier.height(12.dp))
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onOpen,
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF00ACC1)
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(
                        Icons.Filled.OpenInNew,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text("Open", fontSize = 14.sp)
                }
                
                val dateText = remember(document.dateAdded) {
                    val date = java.util.Date(document.dateAdded)
                    java.text.SimpleDateFormat("MMM dd, yyyy", java.util.Locale.getDefault()).format(date)
                }
                
                Text(
                    text = dateText,
                    color = TextTertiary,
                    fontSize = 11.sp,
                    modifier = Modifier.align(Alignment.CenterVertically)
                )
            }
        }
    }
}
