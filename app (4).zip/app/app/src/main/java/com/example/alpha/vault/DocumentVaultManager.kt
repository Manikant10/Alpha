package com.example.alpha.vault

import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import android.util.Log
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * DocumentVaultManager handles secure document storage with encryption
 */
class DocumentVaultManager(private val context: Context) {
    
    private val vaultDirectory: File = File(context.filesDir, "secure_vault")
    private val sharedPrefs: SharedPreferences
    
    private val _securedDocuments = MutableStateFlow<List<SecuredDocument>>(emptyList())
    val securedDocuments: StateFlow<List<SecuredDocument>> = _securedDocuments.asStateFlow()
    
    private val _isUnlocked = MutableStateFlow(false)
    val isUnlocked: StateFlow<Boolean> = _isUnlocked.asStateFlow()
    
    companion object {
        private const val TAG = "DocumentVaultManager"
        private const val PREFS_NAME = "document_vault_prefs"
        private const val KEY_DOCUMENTS = "secured_documents"
        private const val CIPHER_TRANSFORMATION = "AES/GCM/NoPadding"
        private const val GCM_TAG_LENGTH = 128
        private const val IV_LENGTH = 12
    }
    
    init {
        // Create vault directory if it doesn't exist
        if (!vaultDirectory.exists()) {
            vaultDirectory.mkdirs()
        }
        
        // Initialize encrypted shared preferences
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        
        sharedPrefs = try {
            EncryptedSharedPreferences.create(
                context,
                PREFS_NAME,
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        } catch (e: Exception) {
            Log.e(TAG, "Failed to create encrypted preferences, using standard", e)
            context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        }
        
        loadDocuments()
    }
    
    /**
     * Unlock the vault
     */
    fun unlock() {
        _isUnlocked.value = true
        loadDocuments()
    }
    
    /**
     * Lock the vault
     */
    fun lock() {
        _isUnlocked.value = false
    }
    
    /**
     * Add a document to the secure vault
     */
    suspend fun addDocument(uri: Uri, displayName: String): Result<SecuredDocument> = withContext(Dispatchers.IO) {
        try {
            // Generate unique ID for document
            val documentId = generateDocumentId()
            val fileExtension = getFileExtension(displayName)
            val secureFileName = "$documentId$fileExtension"
            val secureFile = File(vaultDirectory, secureFileName)
            
            // Get original file size and type
            val originalSize = getFileSize(uri)
            val mimeType = getMimeType(uri) ?: "application/octet-stream"
            
            // Encrypt and save the file
            encryptFile(uri, secureFile)
            
            // Create document metadata
            val document = SecuredDocument(
                id = documentId,
                displayName = displayName,
                secureFileName = secureFileName,
                originalSize = originalSize,
                mimeType = mimeType,
                dateAdded = System.currentTimeMillis()
            )
            
            // Save metadata
            saveDocument(document)
            
            Log.d(TAG, "Document secured: $displayName")
            Result.success(document)
            
        } catch (e: Exception) {
            Log.e(TAG, "Failed to secure document", e)
            Result.failure(e)
        }
    }
    
    /**
     * Remove a document from the vault
     */
    suspend fun removeDocument(documentId: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val documents = _securedDocuments.value.toMutableList()
            val document = documents.find { it.id == documentId } ?: return@withContext false
            
            // Delete encrypted file
            val file = File(vaultDirectory, document.secureFileName)
            if (file.exists()) {
                file.delete()
            }
            
            // Remove from list
            documents.remove(document)
            saveDocumentsList(documents)
            _securedDocuments.value = documents
            
            Log.d(TAG, "Document removed: ${document.displayName}")
            true
            
        } catch (e: Exception) {
            Log.e(TAG, "Failed to remove document", e)
            false
        }
    }
    
    /**
     * Get a decrypted document for viewing/sharing
     */
    suspend fun getDecryptedDocument(documentId: String): Result<File> = withContext(Dispatchers.IO) {
        try {
            val document = _securedDocuments.value.find { it.id == documentId }
                ?: return@withContext Result.failure(Exception("Document not found"))
            
            val encryptedFile = File(vaultDirectory, document.secureFileName)
            if (!encryptedFile.exists()) {
                return@withContext Result.failure(Exception("Encrypted file not found"))
            }
            
            // Create temporary decrypted file
            val tempFile = File(context.cacheDir, document.displayName)
            decryptFile(encryptedFile, tempFile)
            
            Result.success(tempFile)
            
        } catch (e: Exception) {
            Log.e(TAG, "Failed to decrypt document", e)
            Result.failure(e)
        }
    }
    
    /**
     * Get total vault size
     */
    fun getTotalVaultSize(): Long {
        return vaultDirectory.listFiles()?.sumOf { it.length() } ?: 0L
    }
    
    /**
     * Clear all documents from vault
     */
    suspend fun clearVault(): Boolean = withContext(Dispatchers.IO) {
        try {
            vaultDirectory.listFiles()?.forEach { it.delete() }
            sharedPrefs.edit().remove(KEY_DOCUMENTS).apply()
            _securedDocuments.value = emptyList()
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to clear vault", e)
            false
        }
    }
    
    // Private helper methods
    
    private fun loadDocuments() {
        try {
            val documentsJson = sharedPrefs.getString(KEY_DOCUMENTS, "[]") ?: "[]"
            // Parse JSON manually (simple implementation)
            val documents = parseDocumentsJson(documentsJson)
            _securedDocuments.value = documents
        } catch (e: Exception) {
            Log.e(TAG, "Failed to load documents", e)
            _securedDocuments.value = emptyList()
        }
    }
    
    private fun saveDocument(document: SecuredDocument) {
        val documents = _securedDocuments.value.toMutableList()
        documents.add(document)
        saveDocumentsList(documents)
        _securedDocuments.value = documents
    }
    
    private fun saveDocumentsList(documents: List<SecuredDocument>) {
        try {
            val json = documentsToJson(documents)
            sharedPrefs.edit().putString(KEY_DOCUMENTS, json).apply()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to save documents list", e)
        }
    }
    
    private fun encryptFile(sourceUri: Uri, destFile: File) {
        val key = getOrCreateEncryptionKey()
        val cipher = Cipher.getInstance(CIPHER_TRANSFORMATION)
        
        // Generate random IV
        val iv = ByteArray(IV_LENGTH)
        SecureRandom().nextBytes(iv)
        val parameterSpec = GCMParameterSpec(GCM_TAG_LENGTH, iv)
        
        cipher.init(Cipher.ENCRYPT_MODE, key, parameterSpec)
        
        context.contentResolver.openInputStream(sourceUri)?.use { input ->
            FileOutputStream(destFile).use { output ->
                // Write IV first
                output.write(iv)
                
                // Encrypt and write data
                val buffer = ByteArray(8192)
                var bytesRead: Int
                while (input.read(buffer).also { bytesRead = it } != -1) {
                    val encryptedBytes = cipher.update(buffer, 0, bytesRead)
                    if (encryptedBytes != null) {
                        output.write(encryptedBytes)
                    }
                }
                
                // Write final block
                val finalBytes = cipher.doFinal()
                output.write(finalBytes)
            }
        }
    }
    
    private fun decryptFile(encryptedFile: File, destFile: File) {
        val key = getOrCreateEncryptionKey()
        val cipher = Cipher.getInstance(CIPHER_TRANSFORMATION)
        
        FileInputStream(encryptedFile).use { input ->
            // Read IV
            val iv = ByteArray(IV_LENGTH)
            input.read(iv)
            val parameterSpec = GCMParameterSpec(GCM_TAG_LENGTH, iv)
            
            cipher.init(Cipher.DECRYPT_MODE, key, parameterSpec)
            
            FileOutputStream(destFile).use { output ->
                val buffer = ByteArray(8192)
                var bytesRead: Int
                while (input.read(buffer).also { bytesRead = it } != -1) {
                    val decryptedBytes = cipher.update(buffer, 0, bytesRead)
                    if (decryptedBytes != null) {
                        output.write(decryptedBytes)
                    }
                }
                
                val finalBytes = cipher.doFinal()
                output.write(finalBytes)
            }
        }
    }
    
    private fun getOrCreateEncryptionKey(): SecretKey {
        val keyString = sharedPrefs.getString("encryption_key", null)
        
        return if (keyString != null) {
            val keyBytes = android.util.Base64.decode(keyString, android.util.Base64.DEFAULT)
            SecretKeySpec(keyBytes, "AES")
        } else {
            // Generate new key
            val keyBytes = ByteArray(32) // 256-bit key
            SecureRandom().nextBytes(keyBytes)
            
            val keyString = android.util.Base64.encodeToString(keyBytes, android.util.Base64.DEFAULT)
            sharedPrefs.edit().putString("encryption_key", keyString).apply()
            
            SecretKeySpec(keyBytes, "AES")
        }
    }
    
    private fun generateDocumentId(): String {
        return "doc_${System.currentTimeMillis()}_${(1000..9999).random()}"
    }
    
    private fun getFileSize(uri: Uri): Long {
        return try {
            context.contentResolver.openFileDescriptor(uri, "r")?.use {
                it.statSize
            } ?: 0L
        } catch (e: Exception) {
            0L
        }
    }
    
    private fun getMimeType(uri: Uri): String? {
        return context.contentResolver.getType(uri)
    }
    
    private fun getFileExtension(fileName: String): String {
        val lastDot = fileName.lastIndexOf('.')
        return if (lastDot > 0) fileName.substring(lastDot) else ""
    }
    
    // Simple JSON parsing (for basic needs)
    private fun parseDocumentsJson(json: String): List<SecuredDocument> {
        if (json == "[]") return emptyList()
        
        val documents = mutableListOf<SecuredDocument>()
        try {
            // Very basic JSON parsing - in production use Gson or kotlinx.serialization
            val items = json.removeSurrounding("[", "]").split("},{")
            for (item in items) {
                val cleanItem = item.removeSurrounding("{", "}")
                val fields = cleanItem.split(",")
                val fieldMap = mutableMapOf<String, String>()
                
                for (field in fields) {
                    val parts = field.split(":")
                    if (parts.size == 2) {
                        val key = parts[0].trim().removeSurrounding("\"")
                        val value = parts[1].trim().removeSurrounding("\"")
                        fieldMap[key] = value
                    }
                }
                
                if (fieldMap.containsKey("id")) {
                    documents.add(
                        SecuredDocument(
                            id = fieldMap["id"] ?: "",
                            displayName = fieldMap["displayName"] ?: "",
                            secureFileName = fieldMap["secureFileName"] ?: "",
                            originalSize = fieldMap["originalSize"]?.toLongOrNull() ?: 0L,
                            mimeType = fieldMap["mimeType"] ?: "",
                            dateAdded = fieldMap["dateAdded"]?.toLongOrNull() ?: 0L
                        )
                    )
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to parse documents JSON", e)
        }
        
        return documents
    }
    
    private fun documentsToJson(documents: List<SecuredDocument>): String {
        if (documents.isEmpty()) return "[]"
        
        val items = documents.joinToString(",") { doc ->
            """{"id":"${doc.id}","displayName":"${doc.displayName}","secureFileName":"${doc.secureFileName}","originalSize":${doc.originalSize},"mimeType":"${doc.mimeType}","dateAdded":${doc.dateAdded}}"""
        }
        
        return "[$items]"
    }
}

/**
 * Data class representing a secured document
 */
data class SecuredDocument(
    val id: String,
    val displayName: String,
    val secureFileName: String,
    val originalSize: Long,
    val mimeType: String,
    val dateAdded: Long
)

/**
 * Format file size for display
 */
fun Long.formatFileSize(): String {
    val kb = 1024.0
    val mb = kb * 1024
    val gb = mb * 1024
    
    return when {
        this >= gb -> String.format("%.2f GB", this / gb)
        this >= mb -> String.format("%.2f MB", this / mb)
        this >= kb -> String.format("%.2f KB", this / kb)
        else -> "$this B"
    }
}
