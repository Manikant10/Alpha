package com.example.alpha.features.antitheft

import android.Manifest
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.SystemClock
import android.provider.Settings
import android.util.Log
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.example.alpha.device.AdminReceiver
import com.example.alpha.data.device.DeviceApiService
import com.example.alpha.data.device.DeviceApiResponse
import com.example.alpha.data.device.PendingCommand
import com.example.alpha.config.ServerConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class AntiTheftManager(
    private val context: Context,
    private val adminComponent: ComponentName
) {

    private val dpm =
        context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager

    private val deviceApiService = DeviceApiService(context)
    private var mediaPlayer: MediaPlayer? = null
    
    companion object {
        private const val TAG = "AntiTheftManager"
    }

    /** 🔒 Lock device immediately */
    fun lockDevice() {
        if (dpm.isAdminActive(adminComponent)) {
            dpm.lockNow()
            Toast.makeText(context, "Device locked", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(context, "Device Admin not active", Toast.LENGTH_SHORT).show()
        }
    }

    /** 📍 Get current GPS and upload to server */
    suspend fun fetchLocationAndUpload(serverUrl: String, deviceId: String): Boolean {
        return withContext(Dispatchers.IO) {
            try {
                // Check for location permissions
                val fineLocationPermission = ContextCompat.checkSelfPermission(
                    context, Manifest.permission.ACCESS_FINE_LOCATION
                )
                val coarseLocationPermission = ContextCompat.checkSelfPermission(
                    context, Manifest.permission.ACCESS_COARSE_LOCATION
                )
                
                if (fineLocationPermission != PackageManager.PERMISSION_GRANTED &&
                    coarseLocationPermission != PackageManager.PERMISSION_GRANTED) {
                    Log.e(TAG, "Location permissions not granted")
                    withContext(Dispatchers.Main) {
                        Toast.makeText(context, "Location permission required", Toast.LENGTH_SHORT).show()
                    }
                    return@withContext false
                }
                
                // Get location
                val locationManager =
                    context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
                val loc: Location? = try {
                    locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                        ?: locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
                } catch (e: SecurityException) {
                    Log.e(TAG, "SecurityException getting location: ${e.message}")
                    null
                }

                if (loc != null) {
                    Log.d(TAG, "Got location: ${loc.latitude}, ${loc.longitude}")
                    
                    // Get battery level
                    val batteryLevel = getBatteryLevel()
                    
                    // Ensure the device is registered on the server before uploading location
                    when (val registrationResult = deviceApiService.registerDevice(
                        deviceId = deviceId,
                        deviceName = Build.MODEL ?: "Android Device",
                        deviceModel = "${Build.MANUFACTURER} ${Build.MODEL}",
                        androidVersion = "Android ${Build.VERSION.RELEASE}"
                    )) {
                        is DeviceApiResponse.Success -> {
                            Log.d(TAG, "Device registered for anti-theft: ${registrationResult.data.deviceId}")
                        }
                        is DeviceApiResponse.Error -> {
                            Log.w(TAG, "Device registration failed before location upload: ${registrationResult.message}")
                        }
                    }
                    
                    // Upload to server using DeviceApiService with proper authentication
                    val result = deviceApiService.uploadLocation(
                        deviceId = deviceId,
                        latitude = loc.latitude,
                        longitude = loc.longitude,
                        accuracy = loc.accuracy,
                        altitude = if (loc.hasAltitude()) loc.altitude else null,
                        bearing = if (loc.hasBearing()) loc.bearing else null,
                        speed = if (loc.hasSpeed()) loc.speed else null,
                        source = if (loc.provider == LocationManager.GPS_PROVIDER) "gps" else "network",
                        batteryLevel = batteryLevel
                    )
                    
                    when (result) {
                        is DeviceApiResponse.Success -> {
                            Log.d(TAG, "Location uploaded successfully: ${result.data.message}")
                            withContext(Dispatchers.Main) {
                                Toast.makeText(context, "Location sent to server", Toast.LENGTH_SHORT).show()
                            }
                            true
                        }
                        is DeviceApiResponse.Error -> {
                            Log.e(TAG, "Failed to upload location: ${result.message}")
                            withContext(Dispatchers.Main) {
                                Toast.makeText(context, "Failed to send location: ${result.message}", Toast.LENGTH_SHORT).show()
                            }
                            false
                        }
                    }
                } else {
                    Log.e(TAG, "No location found")
                    withContext(Dispatchers.Main) {
                        Toast.makeText(context, "Could not get location", Toast.LENGTH_SHORT).show()
                    }
                    false
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error sending location: ${e.message}", e)
                withContext(Dispatchers.Main) {
                    Toast.makeText(context, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
                }
                false
            }
        }
    }
    
    /**
     * Get current battery level
     */
    private fun getBatteryLevel(): Int? {
        return try {
            val batteryManager = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
            batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to get battery level", e)
            null
        }
    }

    /**
     * Poll server for pending commands and execute them on this device.
     * This uses the existing heartbeat API to fetch commands like LOCK_DEVICE,
     * START_ALARM, STOP_ALARM, FACTORY_RESET, REQUEST_LOCATION, etc.
     */
    suspend fun processServerCommands(deviceId: String) {
        try {
            when (val result = deviceApiService.sendHeartbeat(
                deviceId = deviceId,
                status = "active",
                batteryLevel = getBatteryLevel(),
                networkType = null
            )) {
                is DeviceApiResponse.Success -> {
                    val heartbeat = result.data
                    Log.d(TAG, "Heartbeat OK, pending commands: ${heartbeat.pendingCommands.size}")

                    heartbeat.pendingCommands.forEach { cmd ->
                        handleCommand(deviceId, cmd)
                    }
                }
                is DeviceApiResponse.Error -> {
                    Log.w(TAG, "Heartbeat error: ${result.message}")
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "processServerCommands error: ${e.message}", e)
        }
    }

    /**
     * Execute a single pending command from the server.
     */
    private suspend fun handleCommand(deviceId: String, cmd: PendingCommand) {
        Log.d(TAG, "Handling command: ${cmd.command_type} (id=${cmd.id})")

        try {
            when (cmd.command_type.uppercase()) {
                "LOCK_DEVICE" -> {
                    withContext(Dispatchers.Main) { lockDevice() }
                }
                "UNLOCK_DEVICE" -> {
                    // Currently there is no explicit unlock implementation on device.
                    // We just log it so you can extend this later if needed.
                    Log.d(TAG, "UNLOCK_DEVICE command received - no client implementation")
                }
                "START_ALARM" -> {
                    withContext(Dispatchers.Main) { startAlarm() }
                }
                "STOP_ALARM" -> {
                    withContext(Dispatchers.Main) { stopAlarm() }
                }
                "FACTORY_RESET" -> {
                    // DANGEROUS: this will wipe the device.
                    withContext(Dispatchers.Main) { wipeDevice() }
                }
                "REQUEST_LOCATION" -> {
                    // Reuse existing location upload logic
                    fetchLocationAndUpload(
                        serverUrl = ServerConfig.getLocationUploadUrl(),
                        deviceId = deviceId
                    )
                }
                else -> {
                    Log.w(TAG, "Unknown command type: ${cmd.command_type}")
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error executing command ${cmd.command_type}", e)
        }
    }

    /** 🚨 Start loud alarm */
    fun startAlarm() {
        try {
            stopAlarm()
            mediaPlayer = MediaPlayer.create(context, android.provider.Settings.System.DEFAULT_ALARM_ALERT_URI)
            mediaPlayer?.isLooping = true
            mediaPlayer?.start()
            Toast.makeText(context, "Alarm started", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(context, "Failed to start alarm", Toast.LENGTH_SHORT).show()
        }
    }

    /** 🔕 Stop alarm */
    fun stopAlarm() {
        mediaPlayer?.stop()
        mediaPlayer?.release()
        mediaPlayer = null
    }

    /** 🧹 Factory reset (wipe) */
    fun wipeDevice() {
        if (dpm.isAdminActive(adminComponent)) {
            dpm.wipeData(0)
        } else {
            Toast.makeText(context, "Device Admin not active", Toast.LENGTH_SHORT).show()
        }
    }
}
