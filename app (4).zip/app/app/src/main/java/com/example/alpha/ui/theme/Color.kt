package com.example.alpha.ui.theme

import androidx.compose.ui.graphics.Color

// === PROFESSIONAL DARK THEME ===

// Primary Colors - Futuristic Cyber Blue
val PrimaryCyberBlue = Color(0xFF00D4FF)
val PrimaryCyberBlueDark = Color(0xFF0095CC)
val PrimaryCyberBlueLight = Color(0xFF66E3FF)

// Secondary Colors - Neon Accents
val NeonGreen = Color(0xFF00FF88)
val NeonPurple = Color(0xFF8B5CF6)
val NeonPink = Color(0xFFFF0080)
val NeonOrange = Color(0xFFFF6B35)

// Background Colors - Deep Dark Professional
val BackgroundPrimary = Color(0xFF0A0B0E)
val BackgroundSecondary = Color(0xFF111318)
val BackgroundTertiary = Color(0xFF1A1D23)
val BackgroundCard = Color(0xFF1F2329)

// Surface Colors - Glass Morphism
val SurfaceGlass = Color(0x1AFFFFFF)
val SurfaceGlassBright = Color(0x33FFFFFF)
val SurfaceDim = Color(0xFF2A2D35)

// Text Colors - High Contrast Professional
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFFCBD5E1)
val TextTertiary = Color(0xFF64748B)
val TextAccent = Color(0xFF00D4FF)

// Status Colors - Professional System
val SuccessGreen = Color(0xFF22C55E)
val WarningAmber = Color(0xFFF59E0B)
val ErrorRed = Color(0xFFEF4444)
val InfoBlue = Color(0xFF3B82F6)

// Gradient Colors for Effects
val GradientStart1 = Color(0xFF0F172A)
val GradientEnd1 = Color(0xFF1E293B)
val GradientStart2 = Color(0xFF7C3AED)
val GradientEnd2 = Color(0xFF3B82F6)
val GradientStart3 = Color(0xFF059669)
val GradientEnd3 = Color(0xFF0891B2)

// Legacy support
val md_theme_light_primary = PrimaryCyberBlue
val md_theme_light_onPrimary = TextPrimary
val md_theme_light_background = BackgroundPrimary
