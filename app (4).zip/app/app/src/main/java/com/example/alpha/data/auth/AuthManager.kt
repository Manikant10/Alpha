package com.example.alpha.data.auth

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.serialization.json.Json
import kotlinx.serialization.encodeToString
import kotlinx.serialization.decodeFromString

/**
 * Authentication Manager
 * Handles user authentication state, token storage, and session management
 */
class AuthManager(private val context: Context) {
    
    private val apiService = AuthApiService(context)
    private val sharedPrefs: SharedPreferences = context.getSharedPreferences(
        "alpha_auth_prefs", Context.MODE_PRIVATE
    )
    private val json = Json {
        ignoreUnknownKeys = true
        coerceInputValues = true
    }
    
    // Authentication state
    private val _authState = MutableStateFlow<AuthState>(AuthState.Idle)
    val authState: StateFlow<AuthState> = _authState.asStateFlow()
    
    // User data
    private val _currentUser = MutableStateFlow<User?>(null)
    val currentUser: StateFlow<User?> = _currentUser.asStateFlow()
    
    // Login status
    private val _isLoggedIn = MutableStateFlow(false)
    val isLoggedIn: StateFlow<Boolean> = _isLoggedIn.asStateFlow()
    
    companion object {
        private const val TAG = "AuthManager"
        
        @Volatile
        private var INSTANCE: AuthManager? = null
        
        fun getInstance(context: Context): AuthManager {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: AuthManager(context.applicationContext).also { INSTANCE = it }
            }
        }
    }
    
    init {
        // Initialize auth state from stored data
        initializeAuthState()
    }
    
    /**
     * Initialize authentication state from stored preferences
     */
    private fun initializeAuthState() {
        val token = getStoredToken()
        val userData = getStoredUser()
        
        if (token != null && userData != null) {
            _currentUser.value = userData
            _isLoggedIn.value = true
            _authState.value = AuthState.Success(userData, token)
            Log.d(TAG, "Restored auth state for user: ${userData.username}")
        } else {
            _authState.value = AuthState.Idle
        }
    }
    
    /**
     * Login with username and password
     */
    suspend fun login(username: String, password: String): AuthState {
        _authState.value = AuthState.Loading
        
        try {
            val response = apiService.login(username, password)
            
            if (response.success && response.token != null && response.user != null) {
                // Store auth data
                storeAuthData(response.token, response.user)
                
                // Update state
                _currentUser.value = response.user
                _isLoggedIn.value = true
                val successState = AuthState.Success(response.user, response.token)
                _authState.value = successState
                
                Log.d(TAG, "Login successful for user: ${response.user.username}")
                return successState
                
            } else {
                val errorState = AuthState.Error(response.error ?: "Login failed")
                _authState.value = errorState
                Log.w(TAG, "Login failed: ${response.error}")
                return errorState
            }
            
        } catch (e: Exception) {
            val errorState = AuthState.Error("Login error: ${e.message}")
            _authState.value = errorState
            Log.e(TAG, "Login exception", e)
            return errorState
        }
    }
    
    /**
     * Register new user
     */
    suspend fun register(username: String, email: String, password: String): AuthState {
        Log.d(TAG, "Starting registration for username: $username, email: $email")
        _authState.value = AuthState.Loading
        
        try {
            Log.d(TAG, "Calling API service register method")
            val response = apiService.register(username, email, password)
            Log.d(TAG, "API service returned: success=${response.success}, error=${response.error}")
            
            if (response.success && response.token != null && response.user != null) {
                // Store auth data
                storeAuthData(response.token, response.user)
                
                // Update state
                _currentUser.value = response.user
                _isLoggedIn.value = true
                val successState = AuthState.Success(response.user, response.token)
                _authState.value = successState
                
                Log.d(TAG, "Registration successful for user: ${response.user.username}")
                return successState
                
            } else {
                val errorState = AuthState.Error(response.error ?: "Registration failed")
                _authState.value = errorState
                Log.w(TAG, "Registration failed: ${response.error}")
                return errorState
            }
            
        } catch (e: Exception) {
            val errorState = AuthState.Error("Registration error: ${e.message}")
            _authState.value = errorState
            Log.e(TAG, "Registration exception", e)
            return errorState
        }
    }
    
    /**
     * Logout current user
     */
    fun logout() {
        // Clear stored data
        clearAuthData()
        
        // Reset state
        _currentUser.value = null
        _isLoggedIn.value = false
        _authState.value = AuthState.Idle
        
        Log.d(TAG, "User logged out")
    }
    
    /**
     * Verify stored token is still valid
     */
    suspend fun verifyToken(): Boolean {
        val token = getStoredToken() ?: return false
        
        return try {
            val isValid = apiService.verifyToken(token)
            if (!isValid) {
                Log.w(TAG, "Token verification failed, logging out")
                logout()
            }
            isValid
        } catch (e: Exception) {
            Log.e(TAG, "Token verification error", e)
            logout()
            false
        }
    }
    
    /**
     * Get current auth token
     */
    fun getCurrentToken(): String? {
        return getStoredToken()
    }
    
    /**
     * Get current API key for device operations
     */
    fun getCurrentApiKey(): String? {
        return _currentUser.value?.apiKey
    }
    
    /**
     * Set API key manually (if needed for testing)
     */
    fun setApiKey(apiKey: String) {
        val currentUser = _currentUser.value
        if (currentUser != null) {
            val updatedUser = currentUser.copy(apiKey = apiKey)
            _currentUser.value = updatedUser
            // Store updated user data
            sharedPrefs.edit().apply {
                putString(AuthPrefs.USER_KEY, json.encodeToString(updatedUser))
                apply()
            }
        }
    }
    
    /**
     * Store authentication data securely
     */
    private fun storeAuthData(token: String, user: User) {
        try {
            sharedPrefs.edit().apply {
                putString(AuthPrefs.TOKEN_KEY, token)
                putString(AuthPrefs.USER_KEY, json.encodeToString(user))
                putBoolean(AuthPrefs.IS_LOGGED_IN, true)
                apply()
            }
            Log.d(TAG, "Auth data stored successfully")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to store auth data", e)
        }
    }
    
    /**
     * Get stored token
     */
    private fun getStoredToken(): String? {
        return sharedPrefs.getString(AuthPrefs.TOKEN_KEY, null)
    }
    
    /**
     * Get stored user data
     */
    private fun getStoredUser(): User? {
        return try {
            val userJson = sharedPrefs.getString(AuthPrefs.USER_KEY, null)
            if (userJson != null) {
                json.decodeFromString<User>(userJson)
            } else {
                null
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to parse stored user data", e)
            null
        }
    }
    
    /**
     * Clear all stored authentication data
     */
    private fun clearAuthData() {
        try {
            sharedPrefs.edit().apply {
                remove(AuthPrefs.TOKEN_KEY)
                remove(AuthPrefs.USER_KEY)
                remove(AuthPrefs.IS_LOGGED_IN)
                remove(AuthPrefs.REMEMBER_ME)
                apply()
            }
            Log.d(TAG, "Auth data cleared")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to clear auth data", e)
        }
    }
    
    /**
     * Update user data (e.g., after profile update)
     */
    fun updateUser(user: User) {
        try {
            _currentUser.value = user
            sharedPrefs.edit().apply {
                putString(AuthPrefs.USER_KEY, json.encodeToString(user))
                apply()
            }
            Log.d(TAG, "User data updated")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to update user data", e)
        }
    }
    
    /**
     * Check if user is authenticated
     */
    fun isAuthenticated(): Boolean {
        return _isLoggedIn.value && _currentUser.value != null && getStoredToken() != null
    }
    
    /**
     * Get user's API key for device operations
     */
    fun getUserApiKey(): String? {
        return _currentUser.value?.apiKey
    }
    
    /**
     * Reset authentication state (for error recovery)
     */
    fun resetAuthState() {
        _authState.value = AuthState.Idle
    }
    
    /**
     * Update user profile (email and/or password)
     */
    suspend fun updateProfile(
        email: String? = null,
        currentPassword: String? = null,
        newPassword: String? = null
    ): AuthResponse {
        return try {
            val apiKey = getCurrentApiKey() ?: return AuthResponse(
                success = false,
                error = "Not authenticated"
            )
            
            val response = apiService.updateProfile(
                apiKey = apiKey,
                email = email,
                currentPassword = currentPassword,
                newPassword = newPassword
            )
            
            if (response.success && response.user != null) {
                // Update stored user data
                updateUser(response.user)
                Log.d(TAG, "Profile updated successfully")
            }
            
            response
        } catch (e: Exception) {
            Log.e(TAG, "Profile update failed", e)
            AuthResponse(success = false, error = "Update failed: ${e.message}")
        }
    }
}
