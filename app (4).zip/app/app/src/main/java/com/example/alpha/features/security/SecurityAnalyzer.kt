package com.example.alpha.features.security

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
// Removed androidx.security imports - not available in current setup
import com.example.alpha.features.permissions.AppPermissionInfo
import com.example.alpha.features.permissions.PermissionsManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.random.Random

data class SecurityAnalysisResult(
    val overallScore: Int, // 0-100
    val riskLevel: SecurityRiskLevel,
    val categories: List<SecurityCategory>,
    val recommendations: List<SecurityRecommendation>,
    val lastAnalysisTime: Long = System.currentTimeMillis()
)

data class SecurityCategory(
    val name: String,
    val score: Int,
    val weight: Float,
    val status: CategoryStatus,
    val description: String,
    val issues: List<SecurityIssue>
)

data class SecurityIssue(
    val title: String,
    val description: String,
    val severity: IssueSeverity,
    val recommendation: String
)

data class SecurityRecommendation(
    val priority: RecommendationPriority,
    val title: String,
    val description: String,
    val actionText: String,
    val category: String
)

enum class SecurityRiskLevel {
    EXCELLENT, GOOD, FAIR, POOR, CRITICAL
}

enum class CategoryStatus {
    EXCELLENT, GOOD, WARNING, CRITICAL
}

enum class IssueSeverity {
    LOW, MEDIUM, HIGH, CRITICAL
}

enum class RecommendationPriority {
    LOW, MEDIUM, HIGH, CRITICAL
}

class SecurityAnalyzer(private val context: Context) {
    private val permissionsManager = PermissionsManager(context)
    private val packageManager = context.packageManager
    
    suspend fun performFullSecurityAnalysis(): SecurityAnalysisResult = withContext(Dispatchers.IO) {
        val categories = mutableListOf<SecurityCategory>()
        val allRecommendations = mutableListOf<SecurityRecommendation>()
        
        // Analyze different security aspects
        categories.add(analyzeAppPermissions(allRecommendations))
        categories.add(analyzeSystemSecurity(allRecommendations))
        categories.add(analyzeDeviceSettings(allRecommendations))
        categories.add(analyzeNetworkSecurity(allRecommendations))
        categories.add(analyzeDataProtection(allRecommendations))
        
        // Calculate weighted overall score
        val overallScore = calculateOverallScore(categories)
        val riskLevel = determineRiskLevel(overallScore)
        
        // Sort recommendations by priority
        val sortedRecommendations = allRecommendations.sortedByDescending { 
            when (it.priority) {
                RecommendationPriority.CRITICAL -> 4
                RecommendationPriority.HIGH -> 3
                RecommendationPriority.MEDIUM -> 2
                RecommendationPriority.LOW -> 1
            }
        }.take(10) // Limit to top 10 recommendations
        
        SecurityAnalysisResult(
            overallScore = overallScore,
            riskLevel = riskLevel,
            categories = categories,
            recommendations = sortedRecommendations
        )
    }
    
    private suspend fun analyzeAppPermissions(recommendations: MutableList<SecurityRecommendation>): SecurityCategory {
        val appPermissions = permissionsManager.analyzeAllApps()
        val highRiskApps = appPermissions.filter { it.riskScore >= 40 && !it.isSystemApp }
        val criticalPermissionApps = appPermissions.filter { app ->
            app.permissions.any { it.riskLevel.name == "CRITICAL" && it.isGranted }
        }
        
        val issues = mutableListOf<SecurityIssue>()
        var score = 85
        
        // Check for high-risk apps
        if (highRiskApps.size > 5) {
            issues.add(SecurityIssue(
                title = "Too Many High-Risk Apps",
                description = "${highRiskApps.size} apps have high permission risk scores",
                severity = IssueSeverity.HIGH,
                recommendation = "Review and uninstall unnecessary apps with excessive permissions"
            ))
            score -= 15
            recommendations.add(SecurityRecommendation(
                priority = RecommendationPriority.HIGH,
                title = "Review High-Risk Applications",
                description = "You have ${highRiskApps.size} apps with elevated permission risks",
                actionText = "Open Permission Manager",
                category = "App Permissions"
            ))
        }
        
        // Check for critical permissions
        if (criticalPermissionApps.size > 3) {
            issues.add(SecurityIssue(
                title = "Critical Permissions Overused",
                description = "${criticalPermissionApps.size} apps have critical permissions granted",
                severity = IssueSeverity.MEDIUM,
                recommendation = "Review apps with camera, microphone, and location access"
            ))
            score -= 10
        }
        
        val status = when {
            score >= 80 -> CategoryStatus.EXCELLENT
            score >= 60 -> CategoryStatus.GOOD
            score >= 40 -> CategoryStatus.WARNING
            else -> CategoryStatus.CRITICAL
        }
        
        return SecurityCategory(
            name = "App Permissions",
            score = score,
            weight = 0.25f,
            status = status,
            description = "Analysis of app permission usage and risks",
            issues = issues
        )
    }
    
    private fun analyzeSystemSecurity(recommendations: MutableList<SecurityRecommendation>): SecurityCategory {
        val issues = mutableListOf<SecurityIssue>()
        var score = 90
        
        // Check Android version
        val androidVersion = Build.VERSION.SDK_INT
        if (androidVersion < Build.VERSION_CODES.TIRAMISU) { // Android 13
            issues.add(SecurityIssue(
                title = "Outdated Android Version",
                description = "Your Android version may have security vulnerabilities",
                severity = IssueSeverity.MEDIUM,
                recommendation = "Update to the latest Android version when available"
            ))
            score -= 15
            recommendations.add(SecurityRecommendation(
                priority = RecommendationPriority.MEDIUM,
                title = "Update Android Version",
                description = "Your device is running an older Android version with potential security risks",
                actionText = "Check for Updates",
                category = "System Security"
            ))
        }
        
        // Check developer options
        val developmentEnabled = Settings.Secure.getInt(
            context.contentResolver,
            Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, 0
        ) != 0
        
        if (developmentEnabled) {
            issues.add(SecurityIssue(
                title = "Developer Options Enabled",
                description = "Developer options can expose security vulnerabilities",
                severity = IssueSeverity.LOW,
                recommendation = "Disable developer options if not needed"
            ))
            score -= 5
        }
        
        // Check unknown sources (for older Android versions)
        try {
            val unknownSources = Settings.Secure.getInt(
                context.contentResolver,
                Settings.Secure.INSTALL_NON_MARKET_APPS, 0
            ) != 0
            
            if (unknownSources) {
                issues.add(SecurityIssue(
                    title = "Unknown Sources Enabled",
                    description = "Installation from unknown sources increases malware risk",
                    severity = IssueSeverity.HIGH,
                    recommendation = "Disable installation from unknown sources"
                ))
                score -= 20
                recommendations.add(SecurityRecommendation(
                    priority = RecommendationPriority.HIGH,
                    title = "Disable Unknown Sources",
                    description = "Your device allows app installation from unknown sources",
                    actionText = "Open Security Settings",
                    category = "System Security"
                ))
            }
        } catch (e: Exception) {
            // Handle newer Android versions differently
        }
        
        val status = when {
            score >= 85 -> CategoryStatus.EXCELLENT
            score >= 70 -> CategoryStatus.GOOD
            score >= 50 -> CategoryStatus.WARNING
            else -> CategoryStatus.CRITICAL
        }
        
        return SecurityCategory(
            name = "System Security",
            score = score,
            weight = 0.30f,
            status = status,
            description = "Operating system and device security configuration",
            issues = issues
        )
    }
    
    private fun analyzeDeviceSettings(recommendations: MutableList<SecurityRecommendation>): SecurityCategory {
        val issues = mutableListOf<SecurityIssue>()
        var score = 80
        
        // Simulate device settings analysis
        // In a real implementation, you would check actual device settings
        
        // Check screen lock
        val hasSecureScreenLock = Random.nextBoolean() // Placeholder - implement actual check
        if (!hasSecureScreenLock) {
            issues.add(SecurityIssue(
                title = "Weak Screen Lock",
                description = "Device may not have a secure screen lock method",
                severity = IssueSeverity.HIGH,
                recommendation = "Enable PIN, pattern, password, or biometric unlock"
            ))
            score -= 25
            recommendations.add(SecurityRecommendation(
                priority = RecommendationPriority.CRITICAL,
                title = "Enable Secure Screen Lock",
                description = "Protect your device with a strong screen lock method",
                actionText = "Open Lock Screen Settings",
                category = "Device Settings"
            ))
        }
        
        // Check automatic updates
        val autoUpdatesEnabled = Random.nextBoolean() // Placeholder
        if (!autoUpdatesEnabled) {
            issues.add(SecurityIssue(
                title = "Auto-Updates Disabled",
                description = "Automatic security updates are not enabled",
                severity = IssueSeverity.MEDIUM,
                recommendation = "Enable automatic system and app updates"
            ))
            score -= 10
        }
        
        val status = when {
            score >= 80 -> CategoryStatus.EXCELLENT
            score >= 60 -> CategoryStatus.GOOD
            score >= 40 -> CategoryStatus.WARNING
            else -> CategoryStatus.CRITICAL
        }
        
        return SecurityCategory(
            name = "Device Settings",
            score = score,
            weight = 0.20f,
            status = status,
            description = "Device configuration and security settings",
            issues = issues
        )
    }
    
    private fun analyzeNetworkSecurity(recommendations: MutableList<SecurityRecommendation>): SecurityCategory {
        val issues = mutableListOf<SecurityIssue>()
        var score = 75
        
        // Simulate network security analysis
        val usingPublicWifi = Random.nextBoolean() // Placeholder
        if (usingPublicWifi) {
            issues.add(SecurityIssue(
                title = "Public WiFi Usage",
                description = "Connected to potentially insecure public WiFi networks",
                severity = IssueSeverity.MEDIUM,
                recommendation = "Use VPN when connecting to public WiFi networks"
            ))
            score -= 15
            recommendations.add(SecurityRecommendation(
                priority = RecommendationPriority.MEDIUM,
                title = "Enable VPN for Public WiFi",
                description = "Protect your data when using public WiFi networks",
                actionText = "Configure VPN",
                category = "Network Security"
            ))
        }
        
        val status = when {
            score >= 80 -> CategoryStatus.EXCELLENT
            score >= 60 -> CategoryStatus.GOOD
            score >= 40 -> CategoryStatus.WARNING
            else -> CategoryStatus.CRITICAL
        }
        
        return SecurityCategory(
            name = "Network Security",
            score = score,
            weight = 0.15f,
            status = status,
            description = "Network connections and communication security",
            issues = issues
        )
    }
    
    private fun analyzeDataProtection(recommendations: MutableList<SecurityRecommendation>): SecurityCategory {
        val issues = mutableListOf<SecurityIssue>()
        var score = 85
        
        // Check for data backup and encryption
        val hasDataBackup = Random.nextBoolean() // Placeholder
        if (!hasDataBackup) {
            issues.add(SecurityIssue(
                title = "No Data Backup",
                description = "Important data may not be backed up securely",
                severity = IssueSeverity.MEDIUM,
                recommendation = "Enable automatic data backup to secure cloud storage"
            ))
            score -= 10
        }
        
        val status = when {
            score >= 80 -> CategoryStatus.EXCELLENT
            score >= 60 -> CategoryStatus.GOOD
            score >= 40 -> CategoryStatus.WARNING
            else -> CategoryStatus.CRITICAL
        }
        
        return SecurityCategory(
            name = "Data Protection",
            score = score,
            weight = 0.10f,
            status = status,
            description = "Data encryption, backup, and privacy protection",
            issues = issues
        )
    }
    
    private fun calculateOverallScore(categories: List<SecurityCategory>): Int {
        val weightedScore = categories.sumOf { category: SecurityCategory -> (category.score * category.weight).toDouble() }
        return weightedScore.toInt().coerceIn(0, 100)
    }
    
    private fun determineRiskLevel(score: Int): SecurityRiskLevel {
        return when {
            score >= 90 -> SecurityRiskLevel.EXCELLENT
            score >= 75 -> SecurityRiskLevel.GOOD
            score >= 60 -> SecurityRiskLevel.FAIR
            score >= 40 -> SecurityRiskLevel.POOR
            else -> SecurityRiskLevel.CRITICAL
        }
    }
}