package com.example.alpha

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.alpha.ui.components.ButtonStyle
import com.example.alpha.ui.components.GradientButton
import com.example.alpha.ui.components.SimpleGradientButton
import com.example.alpha.ui.theme.*

/**
 * BUTTON COMPARISON TEST - Compare different button implementations
 * This will help identify which approach shows text correctly
 */
class ButtonComparisonTestActivity : ComponentActivity() {
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        setContent {
            AlphaTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    ButtonComparisonTestScreen()
                }
            }
        }
    }
}

@Composable
fun ButtonComparisonTestScreen() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        
        Text(
            text = "🔄 BUTTON COMPARISON TEST",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )
        
        Text(
            text = "Compare different button implementations to find which shows text",
            style = MaterialTheme.typography.bodyMedium,
            color = Color.White,
            modifier = Modifier
                .background(Color.Black.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                .padding(12.dp)
        )
        
        Spacer(modifier = Modifier.height(16.dp))
        
        // Test 1: Original GradientButton
        ComparisonSection("1. ORIGINAL GRADIENT BUTTON") {
            GradientButton(
                text = "Original GradientButton - Primary",
                icon = Icons.Filled.Star,
                style = ButtonStyle.Primary,
                color1 = PrimaryCyberBlue,
                color2 = NeonPurple
            ) { }
            
            GradientButton(
                text = "Original GradientButton - Warning",
                icon = Icons.Filled.Warning,
                style = ButtonStyle.Warning,
                color1 = WarningAmber,
                color2 = NeonOrange
            ) { }
            
            GradientButton(
                text = "Original GradientButton - Success",
                icon = Icons.Filled.CheckCircle,
                style = ButtonStyle.Success,
                color1 = SuccessGreen,
                color2 = NeonGreen
            ) { }
        }
        
        // Test 2: Simple GradientButton
        ComparisonSection("2. SIMPLE GRADIENT BUTTON") {
            SimpleGradientButton(
                text = "Simple GradientButton - Primary",
                icon = Icons.Filled.Star,
                color1 = PrimaryCyberBlue,
                color2 = NeonPurple
            ) { }
            
            SimpleGradientButton(
                text = "Simple GradientButton - Warning",
                icon = Icons.Filled.Warning,
                color1 = WarningAmber,
                color2 = NeonOrange
            ) { }
            
            SimpleGradientButton(
                text = "Simple GradientButton - Success",
                icon = Icons.Filled.CheckCircle,
                color1 = SuccessGreen,
                color2 = NeonGreen
            ) { }
        }
        
        // Test 3: Material3 Buttons with forced colors
        ComparisonSection("3. MATERIAL3 BUTTONS - FORCED COLORS") {
            Button(
                onClick = { },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = PrimaryCyberBlue,
                    contentColor = Color.White
                )
            ) {
                Icon(Icons.Filled.Star, null, tint = Color.White)
                Spacer(Modifier.width(8.dp))
                Text("M3 Button - Forced White", color = Color.White, fontWeight = FontWeight.Bold)
            }
            
            FilledTonalButton(
                onClick = { },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.filledTonalButtonColors(
                    containerColor = WarningAmber,
                    contentColor = Color.White
                )
            ) {
                Icon(Icons.Filled.Warning, null, tint = Color.White)
                Spacer(Modifier.width(8.dp))
                Text("M3 Tonal - Forced White", color = Color.White, fontWeight = FontWeight.Bold)
            }
        }
        
        // Test 4: Direct Box-based buttons
        ComparisonSection("4. DIRECT BOX BUTTONS") {
            BoxButton(
                text = "Direct Box Button - Blue",
                icon = Icons.Filled.Star,
                backgroundColor = PrimaryCyberBlue
            ) { }
            
            BoxButton(
                text = "Direct Box Button - Amber", 
                icon = Icons.Filled.Warning,
                backgroundColor = WarningAmber
            ) { }
            
            BoxButton(
                text = "Direct Box Button - Green",
                icon = Icons.Filled.CheckCircle,
                backgroundColor = SuccessGreen
            ) { }
        }
        
        // Test 5: Theme Color Debug
        ComparisonSection("5. THEME COLOR VALUES") {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.Black.copy(alpha = 0.8f), RoundedCornerShape(12.dp))
                    .padding(16.dp)
            ) {
                Text("Theme Colors Debug:", color = Color.Yellow, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))
                
                Text("PrimaryCyberBlue = #${PrimaryCyberBlue.value.toString(16)}", color = Color.White, fontSize = 12.sp)
                Text("TextPrimary = #${TextPrimary.value.toString(16)}", color = Color.White, fontSize = 12.sp)
                Text("WarningAmber = #${WarningAmber.value.toString(16)}", color = Color.White, fontSize = 12.sp)
                Text("Color.White = #${Color.White.value.toString(16)}", color = Color.White, fontSize = 12.sp)
                
                Spacer(modifier = Modifier.height(8.dp))
                Text("Material Theme Colors:", color = Color.Yellow, fontWeight = FontWeight.Bold)
                Text("primary = #${MaterialTheme.colorScheme.primary.value.toString(16)}", color = Color.White, fontSize = 12.sp)
                Text("onPrimary = #${MaterialTheme.colorScheme.onPrimary.value.toString(16)}", color = Color.White, fontSize = 12.sp)
                Text("onSurface = #${MaterialTheme.colorScheme.onSurface.value.toString(16)}", color = Color.White, fontSize = 12.sp)
            }
        }
        
        Spacer(modifier = Modifier.height(24.dp))
        
        Text(
            text = "📝 COMPARISON RESULTS:\n" +
                  "• Which buttons show text clearly?\n" +
                  "• Which approach works best?\n" +
                  "• Are any buttons completely blank?\n" +
                  "• Test by tapping buttons to verify they work",
            color = Color.White,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier
                .background(Color.Red.copy(alpha = 0.8f), RoundedCornerShape(12.dp))
                .padding(16.dp)
        )
    }
}

@Composable
fun ComparisonSection(
    title: String,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = Color.Black.copy(alpha = 0.4f)
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = title,
                color = Color.Cyan,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )
            
            content()
        }
    }
}

@Composable
fun BoxButton(
    text: String,
    icon: ImageVector,
    backgroundColor: Color,
    onClick: () -> Unit = {}
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(56.dp)
            .background(backgroundColor, RoundedCornerShape(12.dp))
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = Color.White,
            modifier = Modifier.size(20.dp)
        )
        Spacer(Modifier.width(8.dp))
        Text(
            text = text,
            color = Color.White,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold
        )
    }
}