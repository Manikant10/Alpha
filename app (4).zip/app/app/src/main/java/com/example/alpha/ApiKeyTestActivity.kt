package com.example.alpha

import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import com.example.alpha.data.auth.AuthManager
import com.example.alpha.data.device.DeviceApiResponse
import com.example.alpha.data.device.DeviceApiService
import com.example.alpha.ui.theme.AlphaTheme
import kotlinx.coroutines.launch

/**
 * Test Activity for API Key Operations
 * Use this to test your API key and device operations
 */
class ApiKeyTestActivity : ComponentActivity() {
    
    companion object {
        private const val TAG = "ApiKeyTestActivity"
        // 🔑 Your API Key
        private const val YOUR_API_KEY = "c7ce5244a6fac1802b20bede02fa88b0755113d73324f7cb283da951dfae694a"
    }
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        setContent {
            AlphaTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    ApiKeyTestScreen()
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ApiKeyTestScreen() {
    val context = LocalContext.current
    val authManager = AuthManager.getInstance(context)
    val deviceApiService = DeviceApiService(context)
    
    var currentApiKey by remember { mutableStateOf("") }
    var testResults by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    
    // Initialize with current API key
    LaunchedEffect(Unit) {
        currentApiKey = authManager.getCurrentApiKey() ?: ""
    }
    
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        
        Text(
            text = "🔑 API Key Test Center",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold
        )
        
        Spacer(modifier = Modifier.height(24.dp))
        
        // API Key Section
        Card(
            modifier = Modifier.fillMaxWidth(),
            elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp)
            ) {
                Text(
                    text = "API Key Management",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )
                
                Spacer(modifier = Modifier.height(12.dp))
                
                OutlinedTextField(
                    value = currentApiKey,
                    onValueChange = { currentApiKey = it },
                    label = { Text("API Key") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                
                Spacer(modifier = Modifier.height(12.dp))
                
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = {
                            currentApiKey = "c7ce5244a6fac1802b20bede02fa88b0755113d73324f7cb283da951dfae694a"
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Use Your API Key")
                    }
                    
                    Button(
                        onClick = {
                            if (currentApiKey.isNotBlank()) {
                                authManager.setApiKey(currentApiKey)
                                testResults += "✅ API Key set successfully!\n\n"
                            }
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Save API Key")
                    }
                }
            }
        }
        
        Spacer(modifier = Modifier.height(16.dp))
        
        // Test Operations Section
        Card(
            modifier = Modifier.fillMaxWidth(),
            elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp)
            ) {
                Text(
                    text = "Test Operations",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )
                
                Spacer(modifier = Modifier.height(12.dp))
                
                val scope = rememberCoroutineScope()
                
                // Test Device Registration
                Button(
                    onClick = {
                        scope.launch {
                            isLoading = true
                            testResults += "🔄 Testing device registration...\n"
                            
                            val result = deviceApiService.registerDevice(
                                deviceId = "test-device-${System.currentTimeMillis()}",
                                deviceName = "Test Android Device",
                                deviceModel = android.os.Build.MODEL,
                                androidVersion = "Android ${android.os.Build.VERSION.RELEASE}"
                            )
                            
                            when (result) {
                                is DeviceApiResponse.Success -> {
                                    testResults += "✅ Device registration successful!\n"
                                    testResults += "   Message: ${result.data.message}\n"
                                    testResults += "   Device ID: ${result.data.deviceId}\n"
                                    testResults += "   Status: ${result.data.status}\n\n"
                                }
                                is DeviceApiResponse.Error -> {
                                    testResults += "❌ Device registration failed!\n"
                                    testResults += "   Error: ${result.message}\n\n"
                                }
                            }
                            
                            isLoading = false
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !isLoading
                ) {
                    Text("🔧 Test Device Registration")
                }
                
                Spacer(modifier = Modifier.height(8.dp))
                
                // Test Location Upload
                Button(
                    onClick = {
                        scope.launch {
                            isLoading = true
                            testResults += "🔄 Testing location upload...\n"
                            
                            val result = deviceApiService.uploadLocation(
                                deviceId = "test-device-001",
                                latitude = 40.7128, // New York coordinates
                                longitude = -74.0060,
                                accuracy = 10.0f,
                                source = "test",
                                batteryLevel = 85
                            )
                            
                            when (result) {
                                is DeviceApiResponse.Success -> {
                                    testResults += "✅ Location upload successful!\n"
                                    testResults += "   Message: ${result.data.message}\n"
                                    testResults += "   Location ID: ${result.data.locationId}\n"
                                    testResults += "   Timestamp: ${result.data.timestamp}\n\n"
                                }
                                is DeviceApiResponse.Error -> {
                                    testResults += "❌ Location upload failed!\n"
                                    testResults += "   Error: ${result.message}\n\n"
                                }
                            }
                            
                            isLoading = false
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !isLoading
                ) {
                    Text("📍 Test Location Upload")
                }
                
                Spacer(modifier = Modifier.height(8.dp))
                
                Button(
                    onClick = {
                        testResults = ""
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("🗑️ Clear Results")
                }
            }
        }
        
        Spacer(modifier = Modifier.height(16.dp))
        
        // Results Section
        Card(
            modifier = Modifier.fillMaxWidth(),
            elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp)
            ) {
                Text(
                    text = "Test Results",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )
                
                Spacer(modifier = Modifier.height(12.dp))
                
                if (isLoading) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CircularProgressIndicator(modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Testing...")
                    }
                } else {
                    Text(
                        text = testResults.ifBlank { "No tests run yet. Click buttons above to test your API key!" },
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
    }
}