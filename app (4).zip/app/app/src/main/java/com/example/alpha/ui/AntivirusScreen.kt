package com.example.alpha.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.alpha.features.antivirus.AntivirusScanner
import com.example.alpha.features.antivirus.ScanResult
import com.example.alpha.features.antivirus.ThreatLevel
import com.example.alpha.ui.components.GradientButton
import com.example.alpha.ui.components.ScreenScaffold
import com.example.alpha.ui.theme.*
import kotlinx.coroutines.delay
import androidx.compose.ui.platform.LocalContext
import android.widget.Toast
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun AntivirusScreen(
    onBack: () -> Unit,
    onOpenDrawer: () -> Unit = {}
) {
    val context = LocalContext.current
    val scanner = remember { AntivirusScanner(context) }
    
    ScreenScaffold(
        title = "Antivirus Scanner",
        onBack = onBack,
        onOpenDrawer = onOpenDrawer
    ) {
        var scanning by remember { mutableStateOf(false) }
        var deepScanning by remember { mutableStateOf(false) }
        var cleaningJunk by remember { mutableStateOf(false) }
        var progress by remember { mutableStateOf(0f) }
        var scanResults by remember { mutableStateOf(listOf<ScanResult>()) }
        var showResults by remember { mutableStateOf(false) }

        // ✅ Launch scanning coroutine when scanning starts
        LaunchedEffect(scanning) {
            if (scanning) {
                for (i in 1..100) {
                    delay(50)
                    progress = i / 100f
                }
                delay(400)
                scanning = false
            }
        }
        
        // Deep scanning logic
        LaunchedEffect(deepScanning) {
            if (deepScanning) {
                withContext(Dispatchers.IO) {
                    progress = 0f
                    scanResults = emptyList()
                    showResults = false
                    
                    for (i in 1..50) {
                        delay(40)
                        progress = i / 100f
                    }
                    
                    scanResults = scanner.scanInstalledApps()
                    
                    for (i in 51..100) {
                        delay(40)
                        progress = i / 100f
                    }
                }
                
                val threatCount = scanResults.count { it.suspicious }
                Toast.makeText(context, "Deep scan complete: $threatCount threats found", Toast.LENGTH_LONG).show()
                showResults = true
                deepScanning = false
            }
        }
        
        // Junk cleaning logic
        LaunchedEffect(cleaningJunk) {
            if (cleaningJunk) {
                withContext(Dispatchers.IO) {
                    progress = 0f
                    var cleanedSize = 0L
                    
                    // Clean cache directories
                    try {
                        val cacheDir = context.cacheDir
                        cleanedSize += cleanDirectory(cacheDir)
                        
                        val externalCacheDir = context.externalCacheDir
                        if (externalCacheDir != null) {
                            cleanedSize += cleanDirectory(externalCacheDir)
                        }
                    } catch (e: Exception) {
                        // Handle permission issues gracefully
                    }
                    
                    for (i in 1..100) {
                        delay(30)
                        progress = i / 100f
                    }
                    
                    val cleanedMB = cleanedSize / (1024 * 1024)
                    Toast.makeText(context, "Cleaned ${cleanedMB}MB of junk files", Toast.LENGTH_LONG).show()
                }
                cleaningJunk = false
            }
        }

        val infiniteRotation = rememberInfiniteTransition(label = "shieldRotation")
        val isAnyScanning = scanning || deepScanning || cleaningJunk
        val rotation by infiniteRotation.animateFloat(
            initialValue = 0f,
            targetValue = if (isAnyScanning) 360f else 0f,
            animationSpec = infiniteRepeatable(
                animation = tween(2000, easing = LinearEasing),
                repeatMode = RepeatMode.Restart
            ),
            label = "rotationAnim"
        )

        val animatedGradient = Brush.linearGradient(
            colors = listOf(
                Color(0xFF00E5FF),
                Color(0xFF9C27B0)
            )
        )

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(
                            MaterialTheme.colorScheme.surface,
                            MaterialTheme.colorScheme.inverseOnSurface.copy(alpha = 0.05f)
                        )
                    )
                )
                .padding(24.dp)
        ) {
            if (showResults && scanResults.isNotEmpty()) {
                // Show detailed scan results
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "SCAN RESULTS",
                                    style = MaterialTheme.typography.titleLarge.copy(
                                        color = TextPrimary,
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                                Text(
                                    text = "${scanResults.count { it.suspicious }} threats detected",
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        color = if (scanResults.any { it.suspicious }) ErrorRed else SuccessGreen
                                    )
                                )
                            }
                            IconButton(onClick = { showResults = false }) {
                                Icon(
                                    Icons.Filled.Close,
                                    contentDescription = "Close",
                                    tint = TextSecondary
                                )
                            }
                        }
                    }
                    
                    // Show threats first
                    items(scanResults.filter { it.suspicious }.take(20)) { result ->
                        ThreatItemCard(result)
                    }
                    
                    if (scanResults.count { it.suspicious } > 20) {
                        item {
                            Text(
                                text = "+ ${scanResults.count { it.suspicious } - 20} more threats",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    color = TextSecondary
                                ),
                                modifier = Modifier.padding(8.dp)
                            )
                        }
                    }
                    
                    item {
                        GradientButton(
                            text = "Run New Scan",
                            icon = Icons.Filled.Refresh,
                            color1 = PrimaryCyberBlue,
                            color2 = NeonPurple
                        ) {
                            showResults = false
                            scanResults = emptyList()
                        }
                    }
                }
            } else {
                // Show scan controls
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(20.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                // 🛡 Animated Shield
                Box(
                    modifier = Modifier
                        .size(150.dp)
                        .background(Color.Transparent),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(130.dp)
                            .shadow(8.dp, CircleShape)
                            .background(animatedGradient, CircleShape)
                            .rotate(rotation),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Filled.Shield,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(70.dp)
                        )
                    }

                    if (isAnyScanning) {
                        Text(
                            text = "${(progress * 100).toInt()}%",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp
                        )
                    }
                }

                Text(
                    text = when {
                        deepScanning -> "Deep scanning all apps..."
                        cleaningJunk -> "Cleaning junk files..."
                        scanning && progress < 1f -> "Scanning in progress..."
                        progress >= 1f -> when {
                            scanResults.isNotEmpty() -> "Scan complete — ${scanResults.count { it.suspicious }} suspicious apps found"
                            else -> "System Secure — No Threats Found!"
                        }
                        else -> "Ready to Scan"
                    },
                    fontWeight = FontWeight.Medium,
                    fontSize = 18.sp,
                    color = MaterialTheme.colorScheme.onBackground
                )

                GradientButton(
                    text = if (!isAnyScanning) "Run Smart Scan" else when {
                        deepScanning -> "Deep Scanning..."
                        cleaningJunk -> "Cleaning..."
                        else -> "Scanning..."
                    },
                    icon = Icons.Filled.Refresh,
                    color1 = Color(0xFF00E5FF),
                    color2 = Color(0xFF00897B)
                ) {
                    if (!isAnyScanning) {
                        scanning = true
                        progress = 0f
                        scanResults = emptyList()
                    }
                }

                AnimatedVisibility(visible = !isAnyScanning) {
                    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                        GradientButton(
                            text = "Deep Scan (Full System)",
                            icon = Icons.Filled.BugReport,
                            color1 = Color(0xFF7E57C2),
                            color2 = Color(0xFF512DA8)
                        ) {
                            deepScanning = true
                            progress = 0f
                        }

                        GradientButton(
                            text = "Clean Junk Files",
                            icon = Icons.Filled.Delete,
                            color1 = Color(0xFFFF4081),
                            color2 = Color(0xFFD500F9)
                        ) {
                            cleaningJunk = true
                            progress = 0f
                        }
                    }
                }

                Spacer(Modifier.height(30.dp))

                Text(
                    text = "Your device is protected with next-gen antivirus technology.",
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f),
                    fontSize = 14.sp,
                    modifier = Modifier.padding(horizontal = 24.dp),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
                }
            }
        }
    }
}

@Composable
fun ThreatItemCard(result: ScanResult) {
    val threatColor = when (result.threatLevel) {
        ThreatLevel.CRITICAL -> ErrorRed
        ThreatLevel.HIGH -> NeonOrange
        ThreatLevel.MEDIUM -> WarningAmber
        ThreatLevel.LOW -> InfoBlue
        else -> SuccessGreen
    }
    
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        modifier = Modifier.fillMaxWidth()
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.linearGradient(
                        colors = listOf(
                            threatColor.copy(alpha = 0.15f),
                            threatColor.copy(alpha = 0.05f)
                        )
                    )
                )
                .border(
                    1.dp,
                    threatColor.copy(alpha = 0.3f),
                    RoundedCornerShape(16.dp)
                )
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .background(threatColor.copy(alpha = 0.2f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        when (result.threatLevel) {
                            ThreatLevel.CRITICAL, ThreatLevel.HIGH -> Icons.Filled.Warning
                            ThreatLevel.MEDIUM -> Icons.Filled.Error
                            ThreatLevel.LOW -> Icons.Filled.Info
                            else -> Icons.Filled.CheckCircle
                        },
                        contentDescription = null,
                        tint = threatColor,
                        modifier = Modifier.size(24.dp)
                    )
                }
                
                Spacer(Modifier.width(16.dp))
                
                Column(
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = result.label,
                        style = MaterialTheme.typography.titleSmall.copy(
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = result.threatType,
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = threatColor,
                            fontWeight = FontWeight.Medium
                        )
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = result.description,
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = TextSecondary
                        ),
                        maxLines = 2
                    )
                }
            }
        }
    }
}

// Helper function to clean directory and return size cleaned
private fun cleanDirectory(dir: File): Long {
    var cleanedSize = 0L
    try {
        dir.listFiles()?.forEach { file ->
            if (file.isFile) {
                cleanedSize += file.length()
                file.delete()
            } else if (file.isDirectory) {
                cleanedSize += cleanDirectory(file)
                file.delete()
            }
        }
    } catch (e: Exception) {
        // Handle permission issues or other errors
    }
    return cleanedSize
}
