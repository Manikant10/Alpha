package com.example.alpha.ui

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.alpha.ui.components.GradientButton
import com.example.alpha.ui.components.ScreenScaffold
import com.example.alpha.ui.components.BackgroundVariant
import com.example.alpha.ui.theme.*
import com.example.alpha.features.webprotect.WebProtect
import com.example.alpha.features.webprotect.SafetyResult
import kotlinx.coroutines.launch

@Composable
fun WebProtectScreen(
    onBack: () -> Unit,
    onOpenDrawer: () -> Unit = {}
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val webProtect = remember { WebProtect(context) }
    
    var safeBrowsingEnabled by remember { mutableStateOf(true) }
    var maliciousSitesBlocked by remember { mutableStateOf(false) }
    var dnsProtectionEnabled by remember { mutableStateOf(false) }
    var vpnConnected by remember { mutableStateOf(false) }
    
    var urlToCheck by remember { mutableStateOf("") }
    var checkResult by remember { mutableStateOf<SafetyResult?>(null) }
    var isChecking by remember { mutableStateOf(false) }
    
    ScreenScaffold(
        title = "Web Protection",
        onBack = onBack,
        onOpenDrawer = onOpenDrawer,
        backgroundVariant = BackgroundVariant.Security
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Protection Status Header
            item {
                WebProtectionStatusCard(
                    protectionLevel = when {
                        safeBrowsingEnabled && maliciousSitesBlocked && dnsProtectionEnabled -> "MAXIMUM"
                        safeBrowsingEnabled && maliciousSitesBlocked -> "HIGH"
                        safeBrowsingEnabled -> "MEDIUM"
                        else -> "LOW"
                    }
                )
            }
            
            // Protection Features
            item {
                Text(
                    text = "PROTECTION FEATURES",
                    style = MaterialTheme.typography.titleMedium.copy(
                        color = TextAccent,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    ),
                    modifier = Modifier.padding(vertical = 8.dp)
                )
            }
            
            // Safe Browsing
            item {
                WebProtectionFeatureCard(
                    title = "Safe Browsing",
                    description = "Real-time protection against phishing and malicious websites",
                    icon = Icons.Filled.Security,
                    isEnabled = safeBrowsingEnabled,
                    onToggle = { safeBrowsingEnabled = it },
                    onClick = {
                        Toast.makeText(
                            context,
                            if (safeBrowsingEnabled) "Safe browsing enabled" else "Safe browsing disabled",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                )
            }
            
            // Malicious Sites Blocking
            item {
                WebProtectionFeatureCard(
                    title = "Block Malicious Sites",
                    description = "Automatically block access to known dangerous websites",
                    icon = Icons.Filled.Block,
                    isEnabled = maliciousSitesBlocked,
                    onToggle = { maliciousSitesBlocked = it },
                    onClick = {
                        Toast.makeText(
                            context,
                            if (maliciousSitesBlocked) "Malicious site blocking enabled" else "Malicious site blocking disabled",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                )
            }
            
            // DNS Protection
            item {
                WebProtectionFeatureCard(
                    title = "DNS Protection",
                    description = "Use secure DNS servers to block malicious domains",
                    icon = Icons.Filled.Dns,
                    isEnabled = dnsProtectionEnabled,
                    onToggle = { dnsProtectionEnabled = it },
                    onClick = {
                        if (dnsProtectionEnabled) {
                            // Open Android DNS settings
                            try {
                                val intent = Intent(Settings.ACTION_WIRELESS_SETTINGS)
                                context.startActivity(intent)
                                Toast.makeText(context, "Configure DNS in WiFi settings", Toast.LENGTH_LONG).show()
                            } catch (e: Exception) {
                                Toast.makeText(context, "Unable to open network settings", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                )
            }
            
            // VPN Protection
            item {
                WebProtectionFeatureCard(
                    title = "VPN Protection",
                    description = "Encrypt your internet connection for maximum security",
                    icon = Icons.Filled.VpnKey,
                    isEnabled = vpnConnected,
                    onToggle = { vpnConnected = it },
                    onClick = {
                        if (vpnConnected) {
                            // Open Android VPN settings
                            try {
                                val intent = Intent(Settings.ACTION_VPN_SETTINGS)
                                context.startActivity(intent)
                                Toast.makeText(context, "Configure VPN settings", Toast.LENGTH_LONG).show()
                            } catch (e: Exception) {
                                Toast.makeText(context, "Unable to open VPN settings", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                )
            }
            
            // URL Checker
            item {
                Text(
                    text = "URL SAFETY CHECKER",
                    style = MaterialTheme.typography.titleMedium.copy(
                        color = TextAccent,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    ),
                    modifier = Modifier.padding(vertical = 8.dp)
                )
            }
            
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.Transparent),
                    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                Brush.linearGradient(
                                    colors = listOf(
                                        SurfaceGlass,
                                        SurfaceGlassBright.copy(alpha = 0.1f)
                                    )
                                )
                            )
                            .border(
                                1.dp,
                                PrimaryCyberBlue.copy(alpha = 0.3f),
                                RoundedCornerShape(16.dp)
                            )
                            .padding(20.dp)
                    ) {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            OutlinedTextField(
                                value = urlToCheck,
                                onValueChange = { 
                                    urlToCheck = it
                                    checkResult = null
                                },
                                label = { Text("Enter URL to check", color = TextSecondary) },
                                placeholder = { Text("https://example.com", color = TextTertiary) },
                                modifier = Modifier.fillMaxWidth(),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = PrimaryCyberBlue,
                                    unfocusedBorderColor = SurfaceGlass,
                                    focusedTextColor = TextPrimary,
                                    unfocusedTextColor = TextPrimary,
                                    cursorColor = PrimaryCyberBlue
                                ),
                                singleLine = true
                            )
                            
                            Button(
                                onClick = {
                                    if (urlToCheck.isNotBlank()) {
                                        isChecking = true
                                        scope.launch {
                                            checkResult = webProtect.checkUrlSafety(urlToCheck)
                                            isChecking = false
                                        }
                                    }
                                },
                                modifier = Modifier.fillMaxWidth(),
                                enabled = urlToCheck.isNotBlank() && !isChecking,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = PrimaryCyberBlue,
                                    disabledContainerColor = SurfaceGlass
                                )
                            ) {
                                Icon(
                                    Icons.Filled.Search,
                                    contentDescription = null,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(Modifier.width(8.dp))
                                Text(if (isChecking) "Checking..." else "Check URL Safety")
                            }
                            
                            checkResult?.let { result ->
                                Spacer(Modifier.height(8.dp))
                                URLSafetyResultCard(result)
                            }
                        }
                    }
                }
            }
            
            // Quick Actions
            item {
                Text(
                    text = "QUICK ACTIONS",
                    style = MaterialTheme.typography.titleMedium.copy(
                        color = TextAccent,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    ),
                    modifier = Modifier.padding(vertical = 8.dp)
                )
            }
            
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(modifier = Modifier.weight(1f)) {
                        GradientButton(
                            text = "Test Connection",
                            icon = Icons.Filled.NetworkCheck,
                            color1 = InfoBlue,
                            color2 = PrimaryCyberBlue
                        ) {
                            // Test internet connection
                            Toast.makeText(context, "Testing secure connection...", Toast.LENGTH_SHORT).show()
                        }
                    }
                    
                    Box(modifier = Modifier.weight(1f)) {
                        GradientButton(
                            text = "Clear Cache",
                            icon = Icons.Filled.ClearAll,
                            color1 = WarningAmber,
                            color2 = NeonOrange
                        ) {
                            // Clear browser cache
                            Toast.makeText(context, "Browser cache cleared", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            }
            
            // Advanced Settings
            item {
                GradientButton(
                    text = "Advanced Network Settings",
                    icon = Icons.Filled.Tune,
                    color1 = NeonPurple,
                    color2 = NeonPink
                ) {
                    try {
                        val intent = Intent(Settings.ACTION_WIRELESS_SETTINGS)
                        context.startActivity(intent)
                    } catch (e: Exception) {
                        Toast.makeText(context, "Unable to open network settings", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }
}

@Composable
fun WebProtectionStatusCard(
    protectionLevel: String,
    modifier: Modifier = Modifier
) {
    val statusColor = when (protectionLevel) {
        "MAXIMUM" -> SuccessGreen
        "HIGH" -> NeonGreen
        "MEDIUM" -> WarningAmber
        else -> ErrorRed
    }
    
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.linearGradient(
                        colors = listOf(
                            statusColor.copy(alpha = 0.1f),
                            statusColor.copy(alpha = 0.05f),
                            Color.Transparent
                        )
                    )
                )
                .border(
                    1.dp,
                    statusColor.copy(alpha = 0.3f),
                    RoundedCornerShape(20.dp)
                )
                .padding(24.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "WEB PROTECTION STATUS",
                        style = MaterialTheme.typography.labelMedium.copy(
                            color = TextSecondary,
                            letterSpacing = 1.sp
                        )
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "$protectionLevel PROTECTION",
                        style = MaterialTheme.typography.titleLarge.copy(
                            color = statusColor,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    Text(
                        text = "Your browsing is protected",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = TextTertiary
                        )
                    )
                }
                
                Box(
                    modifier = Modifier
                        .size(60.dp)
                        .background(
                            statusColor.copy(alpha = 0.2f),
                            CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        when (protectionLevel) {
                            "MAXIMUM" -> Icons.Filled.Shield
                            "HIGH" -> Icons.Filled.Security
                            "MEDIUM" -> Icons.Filled.Warning
                            else -> Icons.Filled.Error
                        },
                        contentDescription = null,
                        tint = statusColor,
                        modifier = Modifier.size(32.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun URLSafetyResultCard(result: SafetyResult) {
    val resultColor = if (result.isSafe) {
        when (result.threatLevel) {
            com.example.alpha.features.webprotect.ThreatSeverity.NONE -> SuccessGreen
            com.example.alpha.features.webprotect.ThreatSeverity.LOW -> WarningAmber
            else -> InfoBlue
        }
    } else {
        when (result.threatLevel) {
            com.example.alpha.features.webprotect.ThreatSeverity.CRITICAL, 
            com.example.alpha.features.webprotect.ThreatSeverity.HIGH -> ErrorRed
            com.example.alpha.features.webprotect.ThreatSeverity.MEDIUM -> NeonOrange
            else -> WarningAmber
        }
    }
    
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.linearGradient(
                        colors = listOf(
                            resultColor.copy(alpha = 0.2f),
                            resultColor.copy(alpha = 0.05f)
                        )
                    )
                )
                .border(
                    1.dp,
                    resultColor.copy(alpha = 0.4f),
                    RoundedCornerShape(12.dp)
                )
                .padding(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .background(resultColor.copy(alpha = 0.2f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        if (result.isSafe) Icons.Filled.CheckCircle else Icons.Filled.Warning,
                        contentDescription = null,
                        tint = resultColor,
                        modifier = Modifier.size(24.dp)
                    )
                }
                
                Spacer(Modifier.width(12.dp))
                
                Column {
                    Text(
                        text = if (result.isSafe) "Safe to visit" else "Potentially unsafe",
                        style = MaterialTheme.typography.titleSmall.copy(
                            color = resultColor,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = result.reason,
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = TextSecondary
                        )
                    )
                    Text(
                        text = "Category: ${result.category}",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = TextTertiary
                        )
                    )
                }
            }
        }
    }
}

@Composable
fun WebProtectionFeatureCard(
    title: String,
    description: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isEnabled: Boolean,
    onToggle: (Boolean) -> Unit,
    onClick: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.linearGradient(
                        colors = listOf(
                            SurfaceGlass,
                            SurfaceGlassBright.copy(alpha = 0.1f)
                        )
                    )
                )
                .border(
                    1.dp,
                    if (isEnabled) SuccessGreen.copy(alpha = 0.3f) else SurfaceGlass,
                    RoundedCornerShape(16.dp)
                )
                .padding(20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .background(
                            if (isEnabled) SuccessGreen.copy(alpha = 0.2f) else SurfaceGlass,
                            CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = if (isEnabled) SuccessGreen else TextSecondary,
                        modifier = Modifier.size(24.dp)
                    )
                }
                
                Spacer(modifier = Modifier.width(16.dp))
                
                Column(
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleSmall.copy(
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = description,
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = TextSecondary
                        )
                    )
                }
                
                Switch(
                    checked = isEnabled,
                    onCheckedChange = { newState ->
                        onToggle(newState)
                        if (newState) onClick()
                    },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = SuccessGreen,
                        checkedTrackColor = SuccessGreen.copy(alpha = 0.3f),
                        uncheckedThumbColor = TextTertiary,
                        uncheckedTrackColor = SurfaceGlass
                    )
                )
            }
        }
    }
}
