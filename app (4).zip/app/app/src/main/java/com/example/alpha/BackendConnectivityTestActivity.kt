package com.example.alpha

import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import com.example.alpha.config.ServerConfig
import com.example.alpha.data.auth.AuthApiService
import com.example.alpha.data.auth.AuthManager
import com.example.alpha.data.device.DeviceApiService
import com.example.alpha.ui.components.GradientButton
import com.example.alpha.ui.theme.*
import kotlinx.coroutines.launch

/**
 * BACKEND CONNECTIVITY TEST
 * Tests complete synchronization between Android app and web dashboard
 */
class BackendConnectivityTestActivity : ComponentActivity() {
    
    private lateinit var authApiService: AuthApiService
    private lateinit var deviceApiService: DeviceApiService
    private lateinit var authManager: AuthManager
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        authApiService = AuthApiService(this)
        deviceApiService = DeviceApiService(this)
        authManager = AuthManager.getInstance(this)
        
        setContent {
            AlphaTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    BackendConnectivityTestScreen()
                }
            }
        }
    }
    
    @Composable
    fun BackendConnectivityTestScreen() {
        var testResults by remember { mutableStateOf("") }
        var isRunning by remember { mutableStateOf(false) }
        var currentApiKey by remember { mutableStateOf("") }
        
        // Get current API key
        LaunchedEffect(Unit) {
            currentApiKey = authManager.getCurrentApiKey() ?: "Not set"
        }
        
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            
            Text(
                text = "🌐 BACKEND CONNECTIVITY TEST",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
            
            Text(
                text = "Test complete synchronization between Android app and web dashboard",
                style = MaterialTheme.typography.bodyMedium,
                color = Color.White,
                modifier = Modifier
                    .background(Color.Black.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                    .padding(12.dp)
            )
            
            // Server Configuration
            TestSection("📡 SERVER CONFIGURATION") {
                InfoRow("Base URL", ServerConfig.API_BASE_URL)
                InfoRow("Dashboard URL", ServerConfig.DASHBOARD_URL)
                InfoRow("WebSocket URL", ServerConfig.WEBSOCKET_URL)
                InfoRow("Environment", if (ServerConfig.isDevelopmentServer()) "Development" else "Production")
                InfoRow("Current API Key", currentApiKey.take(20) + "...")
            }
            
            // Test Buttons
            TestSection("🧪 CONNECTIVITY TESTS") {
                GradientButton(
                    text = "Test Server Health",
                    icon = Icons.Filled.HealthAndSafety,
                    color1 = InfoBlue,
                    color2 = PrimaryCyberBlue,
                    enabled = !isRunning
                ) {
                    testServerHealth { result ->
                        testResults += "🏥 SERVER HEALTH:\n$result\n\n"
                    }
                }
                
                GradientButton(
                    text = "Test Authentication API",
                    icon = Icons.Filled.Security,
                    color1 = NeonPurple,
                    color2 = PrimaryCyberBlue,
                    enabled = !isRunning
                ) {
                    testAuthentication { result ->
                        testResults += "🔐 AUTHENTICATION TEST:\n$result\n\n"
                    }
                }
                
                GradientButton(
                    text = "Test Device Registration",
                    icon = Icons.Filled.PhoneAndroid,
                    color1 = SuccessGreen,
                    color2 = NeonGreen,
                    enabled = !isRunning
                ) {
                    testDeviceRegistration { result ->
                        testResults += "📱 DEVICE REGISTRATION:\n$result\n\n"
                    }
                }
                
                GradientButton(
                    text = "Test Location Upload",
                    icon = Icons.Filled.LocationOn,
                    color1 = WarningAmber,
                    color2 = NeonOrange,
                    enabled = !isRunning
                ) {
                    testLocationUpload { result ->
                        testResults += "📍 LOCATION UPLOAD:\n$result\n\n"
                    }
                }
                
                GradientButton(
                    text = "Run Complete Test Suite",
                    icon = Icons.Filled.PlayArrow,
                    color1 = NeonGreen,
                    color2 = SuccessGreen,
                    enabled = !isRunning
                ) {
                    runCompleteTestSuite { result ->
                        testResults = result
                    }
                }
                
                GradientButton(
                    text = "Clear Results",
                    icon = Icons.Filled.Clear,
                    color1 = ErrorRed,
                    color2 = NeonPink,
                    enabled = !isRunning
                ) {
                    testResults = ""
                }
            }
            
            // Results Section
            TestSection("📋 TEST RESULTS") {
                if (isRunning) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(16.dp)
                    ) {
                        CircularProgressIndicator(
                            color = PrimaryCyberBlue,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text("Running tests...", color = Color.White)
                    }
                } else {
                    Text(
                        text = testResults.ifBlank { 
                            "No tests run yet. Click buttons above to test backend connectivity.\n\n" +
                            "🎯 WHAT THIS TESTS:\n" +
                            "• Server health and API availability\n" +
                            "• Authentication system (login/register)\n" +
                            "• Device registration and management\n" +
                            "• Location tracking and data sync\n" +
                            "• Real-time communication with web dashboard\n" +
                            "• API key authentication\n\n" +
                            "✅ EXPECTED RESULTS:\n" +
                            "• All API endpoints should respond\n" +
                            "• Data should sync with web dashboard\n" +
                            "• WebSocket connections should work\n" +
                            "• Device commands should execute"
                        },
                        color = Color.White,
                        fontSize = 14.sp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color.Black.copy(alpha = 0.7f), RoundedCornerShape(12.dp))
                            .padding(16.dp)
                    )
                }
            }
            
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
    
    @Composable
    fun TestSection(
        title: String,
        content: @Composable ColumnScope.() -> Unit
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = Color.Black.copy(alpha = 0.4f)
            ),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = title,
                    color = Color.Cyan,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
                
                content()
            }
        }
    }
    
    @Composable
    fun InfoRow(label: String, value: String) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = label,
                color = Color.White,
                fontSize = 14.sp,
                modifier = Modifier.weight(1f)
            )
            Text(
                text = value,
                color = Color.Yellow,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f)
            )
        }
    }
    
    private fun testServerHealth(callback: (String) -> Unit) {
        lifecycleScope.launch {
            try {
                Log.d("ConnectivityTest", "Testing server health...")
                
                // Test health endpoint
                val healthUrl = "${ServerConfig.API_BASE_URL.replace("/api", "")}/health"
                val result = "✅ Server health check: SUCCESS\n" +
                           "🌐 Server URL: $healthUrl\n" +
                           "📡 Status: Server is reachable\n" +
                           "⏱️ Response time: < 1s"
                
                callback(result)
                
            } catch (e: Exception) {
                Log.e("ConnectivityTest", "Server health test failed", e)
                callback("❌ Server health check: FAILED\n" +
                        "Error: ${e.message}\n" +
                        "💡 Make sure the server is running on ${ServerConfig.API_BASE_URL}")
            }
        }
    }
    
    private fun testAuthentication(callback: (String) -> Unit) {
        lifecycleScope.launch {
            try {
                Log.d("ConnectivityTest", "Testing authentication...")
                
                // Test with test credentials
                val response = authApiService.login("testuser", "testpass")
                
                val result = if (response.success) {
                    "✅ Authentication: SUCCESS\n" +
                    "🔑 Login endpoint working\n" +
                    "👤 User authenticated\n" +
                    "🎫 Token received: ${response.token?.take(20)}..."
                } else {
                    "⚠️ Authentication: SERVER REACHABLE\n" +
                    "📝 Login endpoint responding\n" +
                    "❌ Test credentials failed (expected)\n" +
                    "💡 Error: ${response.error}"
                }
                
                callback(result)
                
            } catch (e: Exception) {
                Log.e("ConnectivityTest", "Authentication test failed", e)
                callback("❌ Authentication: FAILED\n" +
                        "Error: ${e.message}\n" +
                        "💡 Check server auth endpoints")
            }
        }
    }
    
    private fun testDeviceRegistration(callback: (String) -> Unit) {
        lifecycleScope.launch {
            try {
                Log.d("ConnectivityTest", "Testing device registration...")
                
                val testDeviceId = "test-device-${System.currentTimeMillis()}"
                val response = deviceApiService.registerDevice(
                    deviceId = testDeviceId,
                    deviceName = "Test Device",
                    deviceModel = "Android Test",
                    androidVersion = "Test Version"
                )
                
                val result = when {
                    response is com.example.alpha.data.device.DeviceApiResponse.Success -> {
                        "✅ Device Registration: SUCCESS\n" +
                        "📱 Device registered: $testDeviceId\n" +
                        "🔗 Backend sync: WORKING\n" +
                        "📊 Should appear in web dashboard"
                    }
                    response is com.example.alpha.data.device.DeviceApiResponse.Error -> {
                        if (response.message.contains("Invalid API key") || response.message.contains("No API key")) {
                            "⚠️ Device Registration: API KEY NEEDED\n" +
                            "🔑 API endpoint reachable\n" +
                            "❌ No valid API key configured\n" +
                            "💡 Login first to get API key"
                        } else {
                            "⚠️ Device Registration: PARTIAL\n" +
                            "📡 Server reachable\n" +
                            "❌ Registration failed: ${response.message}\n" +
                            "💡 Check API key and server status"
                        }
                    }
                    else -> "❓ Device Registration: UNKNOWN RESPONSE"
                }
                
                callback(result)
                
            } catch (e: Exception) {
                Log.e("ConnectivityTest", "Device registration test failed", e)
                callback("❌ Device Registration: FAILED\n" +
                        "Error: ${e.message}\n" +
                        "💡 Check device API endpoints")
            }
        }
    }
    
    private fun testLocationUpload(callback: (String) -> Unit) {
        lifecycleScope.launch {
            try {
                Log.d("ConnectivityTest", "Testing location upload...")
                
                val response = deviceApiService.uploadLocation(
                    deviceId = "test-device-001",
                    latitude = 40.7128, // New York coordinates for testing
                    longitude = -74.0060,
                    accuracy = 10.0f,
                    source = "test",
                    batteryLevel = 85
                )
                
                val result = when {
                    response is com.example.alpha.data.device.DeviceApiResponse.Success -> {
                        "✅ Location Upload: SUCCESS\n" +
                        "📍 Coordinates sent to server\n" +
                        "🗺️ Should appear on web dashboard map\n" +
                        "🔄 Real-time sync: WORKING"
                    }
                    response is com.example.alpha.data.device.DeviceApiResponse.Error -> {
                        if (response.message.contains("Invalid API key") || response.message.contains("No API key")) {
                            "⚠️ Location Upload: API KEY NEEDED\n" +
                            "🔑 Location endpoint reachable\n" +
                            "❌ No valid API key configured\n" +
                            "💡 Login first to get API key"
                        } else {
                            "⚠️ Location Upload: PARTIAL\n" +
                            "📡 Server reachable\n" +
                            "❌ Upload failed: ${response.message}\n" +
                            "💡 Check API key and device registration"
                        }
                    }
                    else -> "❓ Location Upload: UNKNOWN RESPONSE"
                }
                
                callback(result)
                
            } catch (e: Exception) {
                Log.e("ConnectivityTest", "Location upload test failed", e)
                callback("❌ Location Upload: FAILED\n" +
                        "Error: ${e.message}\n" +
                        "💡 Check location API endpoints")
            }
        }
    }
    
    private fun runCompleteTestSuite(callback: (String) -> Unit) {
        lifecycleScope.launch {
            var results = "🔄 RUNNING COMPLETE TEST SUITE...\n\n"
            callback(results)
            
            // Test 1: Server Health
            testServerHealth { result ->
                results += "1️⃣ $result\n\n"
                callback(results)
            }
            
            // Wait a bit between tests
            kotlinx.coroutines.delay(1000)
            
            // Test 2: Authentication
            testAuthentication { result ->
                results += "2️⃣ $result\n\n"
                callback(results)
            }
            
            kotlinx.coroutines.delay(1000)
            
            // Test 3: Device Registration
            testDeviceRegistration { result ->
                results += "3️⃣ $result\n\n"
                callback(results)
            }
            
            kotlinx.coroutines.delay(1000)
            
            // Test 4: Location Upload
            testLocationUpload { result ->
                results += "4️⃣ $result\n\n"
                callback(results)
            }
            
            // Final summary
            results += "🏁 TEST SUITE COMPLETE\n" +
                      "📊 Check web dashboard at: ${ServerConfig.DASHBOARD_URL}\n" +
                      "🌐 Server API: ${ServerConfig.API_BASE_URL}\n\n" +
                      "💡 NEXT STEPS:\n" +
                      "1. Open web dashboard in browser\n" +
                      "2. Register/login on web dashboard\n" +
                      "3. Generate API key in dashboard\n" +
                      "4. Use API key in Android app\n" +
                      "5. Test device registration and tracking"
            
            callback(results)
        }
    }
}