package com.example.alpha.ui.auth

import androidx.compose.animation.*
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import android.content.Intent
import com.example.alpha.RegistrationTestActivity
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.alpha.data.auth.*
import com.example.alpha.ui.components.GradientBackground
import com.example.alpha.ui.components.GradientButton
import com.example.alpha.ui.components.BackgroundVariant
import com.example.alpha.ui.components.ButtonStyle
import com.example.alpha.ui.theme.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class, ExperimentalAnimationApi::class)
@Composable
fun AuthScreen(
    onAuthSuccess: (User, String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val authManager = remember { AuthManager.getInstance(context) }
    val keyboardController = LocalSoftwareKeyboardController.current
    
    // Tab state
    var selectedTab by remember { mutableStateOf(AuthTab.Login) }
    
    // Form states
    var loginUsername by remember { mutableStateOf("") }
    var loginPassword by remember { mutableStateOf("") }
    var registerUsername by remember { mutableStateOf("") }
    var registerEmail by remember { mutableStateOf("") }
    var registerPassword by remember { mutableStateOf("") }
    var registerConfirmPassword by remember { mutableStateOf("") }
    
    // UI states
    var loginPasswordVisible by remember { mutableStateOf(false) }
    var registerPasswordVisible by remember { mutableStateOf(false) }
    var registerConfirmPasswordVisible by remember { mutableStateOf(false) }
    
    // Error states
    var loginUsernameError by remember { mutableStateOf<String?>(null) }
    var loginPasswordError by remember { mutableStateOf<String?>(null) }
    var registerUsernameError by remember { mutableStateOf<String?>(null) }
    var registerEmailError by remember { mutableStateOf<String?>(null) }
    var registerPasswordError by remember { mutableStateOf<String?>(null) }
    var registerConfirmPasswordError by remember { mutableStateOf<String?>(null) }
    var generalError by remember { mutableStateOf<String?>(null) }
    
    // Auth state observation
    val authState by authManager.authState.collectAsState()
    
    // Handle auth state changes
    LaunchedEffect(authState) {
        when (val state = authState) {
            is AuthState.Success -> {
                onAuthSuccess(state.user, state.token)
            }
            is AuthState.Error -> {
                generalError = state.message
            }
            else -> {
                generalError = null
            }
        }
    }
    
    // Focus requesters
    val loginPasswordFocus = remember { FocusRequester() }
    val registerEmailFocus = remember { FocusRequester() }
    val registerPasswordFocus = remember { FocusRequester() }
    val registerConfirmPasswordFocus = remember { FocusRequester() }
    
    // Animation (simplified to static values to avoid compatibility issues)
    val headerFloat = 0f
    val logoScale = 1f
    
    GradientBackground(variant = BackgroundVariant.Security) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp),
            contentAlignment = Alignment.Center
        ) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .offset(y = headerFloat.dp),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color.Transparent
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 16.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    SurfaceGlass,
                                    SurfaceGlassBright,
                                    SurfaceGlass
                                )
                            )
                        )
                        .border(
                            width = 1.dp,
                            brush = Brush.linearGradient(
                                colors = listOf(
                                    PrimaryCyberBlue.copy(alpha = 0.6f),
                                    NeonPurple.copy(alpha = 0.4f),
                                    PrimaryCyberBlue.copy(alpha = 0.2f)
                                )
                            ),
                            shape = RoundedCornerShape(24.dp)
                        )
                        .padding(32.dp)
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // Logo and Header
                        Icon(
                            Icons.Filled.Shield,
                            contentDescription = null,
                            tint = PrimaryCyberBlue,
                            modifier = Modifier
                                .size(64.dp)
                                .scale(logoScale)
                        )
                        
                        Spacer(modifier = Modifier.height(16.dp))
                        
                        Text(
                            "ALPHA SECURITY",
                            style = MaterialTheme.typography.headlineMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary,
                                letterSpacing = 2.sp
                            )
                        )
                        
                        Text(
                            "Neural Defense System",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = PrimaryCyberBlue,
                                letterSpacing = 1.sp
                            )
                        )
                        
                        Spacer(modifier = Modifier.height(32.dp))
                        
                        // Tabs
                        AuthTabRow(
                            selectedTab = selectedTab,
                            onTabSelected = { 
                                selectedTab = it
                                generalError = null // Clear errors when switching tabs
                                authManager.resetAuthState()
                            }
                        )
                        
                        Spacer(modifier = Modifier.height(24.dp))
                        
                        // Forms
                        AnimatedContent(
                            targetState = selectedTab,
                            transitionSpec = {
                                slideInHorizontally { width -> 
                                    if (targetState == AuthTab.Register) width else -width
                                } with slideOutHorizontally { width ->
                                    if (targetState == AuthTab.Register) -width else width
                                }
                            },
                            label = "tab_animation"
                        ) { tab ->
                            when (tab) {
                                AuthTab.Login -> {
                                    LoginForm(
                                        username = loginUsername,
                                        password = loginPassword,
                                        passwordVisible = loginPasswordVisible,
                                        usernameError = loginUsernameError,
                                        passwordError = loginPasswordError,
                                        isLoading = authState is AuthState.Loading,
                                        onUsernameChange = { 
                                            loginUsername = it
                                            loginUsernameError = null
                                        },
                                        onPasswordChange = { 
                                            loginPassword = it
                                            loginPasswordError = null
                                        },
                                        onPasswordVisibilityToggle = { 
                                            loginPasswordVisible = !loginPasswordVisible 
                                        },
                                        onPasswordNext = { loginPasswordFocus.requestFocus() },
                                        onLogin = {
                                            keyboardController?.hide()
                                            
                                            // Validate inputs
                                            val usernameValidation = AuthValidator.validateUsername(loginUsername)
                                            val passwordValidation = AuthValidator.validatePassword(loginPassword)
                                            
                                            loginUsernameError = if (!usernameValidation.isValid) usernameValidation.errorMessage else null
                                            loginPasswordError = if (!passwordValidation.isValid) passwordValidation.errorMessage else null
                                            
                                            if (usernameValidation.isValid && passwordValidation.isValid) {
                                                scope.launch {
                                                    authManager.login(loginUsername.trim(), loginPassword)
                                                }
                                            }
                                        },
                                        passwordFocusRequester = loginPasswordFocus
                                    )
                                }
                                
                                AuthTab.Register -> {
                                    RegisterForm(
                                        username = registerUsername,
                                        email = registerEmail,
                                        password = registerPassword,
                                        confirmPassword = registerConfirmPassword,
                                        passwordVisible = registerPasswordVisible,
                                        confirmPasswordVisible = registerConfirmPasswordVisible,
                                        usernameError = registerUsernameError,
                                        emailError = registerEmailError,
                                        passwordError = registerPasswordError,
                                        confirmPasswordError = registerConfirmPasswordError,
                                        isLoading = authState is AuthState.Loading,
                                        onUsernameChange = { 
                                            registerUsername = it
                                            registerUsernameError = null
                                        },
                                        onEmailChange = { 
                                            registerEmail = it
                                            registerEmailError = null
                                        },
                                        onPasswordChange = { 
                                            registerPassword = it
                                            registerPasswordError = null
                                        },
                                        onConfirmPasswordChange = { 
                                            registerConfirmPassword = it
                                            registerConfirmPasswordError = null
                                        },
                                        onPasswordVisibilityToggle = { 
                                            registerPasswordVisible = !registerPasswordVisible 
                                        },
                                        onConfirmPasswordVisibilityToggle = { 
                                            registerConfirmPasswordVisible = !registerConfirmPasswordVisible 
                                        },
                                        onUsernameNext = { registerEmailFocus.requestFocus() },
                                        onEmailNext = { registerPasswordFocus.requestFocus() },
                                        onPasswordNext = { registerConfirmPasswordFocus.requestFocus() },
                                        onRegister = {
                                            keyboardController?.hide()
                                            
                                            // Validate inputs
                                            val usernameValidation = AuthValidator.validateUsername(registerUsername)
                                            val emailValidation = AuthValidator.validateEmail(registerEmail)
                                            val passwordValidation = AuthValidator.validatePassword(registerPassword)
                                            val confirmPasswordValidation = AuthValidator.validatePasswordConfirmation(
                                                registerPassword, registerConfirmPassword
                                            )
                                            
                                            registerUsernameError = if (!usernameValidation.isValid) usernameValidation.errorMessage else null
                                            registerEmailError = if (!emailValidation.isValid) emailValidation.errorMessage else null
                                            registerPasswordError = if (!passwordValidation.isValid) passwordValidation.errorMessage else null
                                            registerConfirmPasswordError = if (!confirmPasswordValidation.isValid) confirmPasswordValidation.errorMessage else null
                                            
                                            if (usernameValidation.isValid && 
                                                emailValidation.isValid && 
                                                passwordValidation.isValid && 
                                                confirmPasswordValidation.isValid) {
                                                scope.launch {
                                                    authManager.register(
                                                        registerUsername.trim(), 
                                                        registerEmail.trim(), 
                                                        registerPassword
                                                    )
                                                }
                                            }
                                        },
                                        emailFocusRequester = registerEmailFocus,
                                        passwordFocusRequester = registerPasswordFocus,
                                        confirmPasswordFocusRequester = registerConfirmPasswordFocus
                                    )
                                }
                            }
                        }
                        
                        // General error message
                        if (generalError != null) {
                            Spacer(modifier = Modifier.height(16.dp))
                            Card(
                                colors = CardDefaults.cardColors(
                                    containerColor = ErrorRed.copy(alpha = 0.1f)
                                ),
                                border = BorderStroke(1.dp, ErrorRed.copy(alpha = 0.5f))
                            ) {
                                Text(
                                    text = generalError!!,
                                    color = ErrorRed,
                                    style = MaterialTheme.typography.bodyMedium,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.padding(16.dp)
                                )
                            }
                        }
                        
                        Spacer(modifier = Modifier.height(24.dp))
                        
                        // Footer
                        Text(
                            "Secure • Encrypted • Private",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = TextTertiary,
                                letterSpacing = 1.sp
                            ),
                            textAlign = TextAlign.Center
                        )
                        
                        // Debug button to open test registration screen
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = {
                                val intent = Intent(context, RegistrationTestActivity::class.java)
                                context.startActivity(intent)
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color.Gray.copy(alpha = 0.3f)
                            )
                        ) {
                            Text("Debug: Test Registration", color = TextSecondary)
                        }
                    }
                }
            }
        }
    }
}

enum class AuthTab {
    Login, Register
}

@Composable
private fun AuthTabRow(
    selectedTab: AuthTab,
    onTabSelected: (AuthTab) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        AuthTab.values().forEach { tab ->
            val isSelected = selectedTab == tab
            val scale by animateFloatAsState(
                targetValue = if (isSelected) 1.02f else 1f,
                animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
                label = "tab_scale"
            )
            
            Card(
                modifier = Modifier
                    .weight(1f)
                    .scale(scale)
                    .clickable { onTabSelected(tab) },
                colors = CardDefaults.cardColors(
                    containerColor = if (isSelected) 
                        PrimaryCyberBlue.copy(alpha = 0.8f) 
                    else 
                        Color.Transparent
                ),
                border = if (!isSelected) BorderStroke(1.dp, TextTertiary.copy(alpha = 0.3f)) else null
            ) {
                Text(
                    text = tab.name,
                    style = MaterialTheme.typography.labelLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = if (isSelected) Color.White else TextSecondary
                    ),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(16.dp)
                )
            }
        }
    }
}

@Composable
private fun LoginForm(
    username: String,
    password: String,
    passwordVisible: Boolean,
    usernameError: String?,
    passwordError: String?,
    isLoading: Boolean,
    onUsernameChange: (String) -> Unit,
    onPasswordChange: (String) -> Unit,
    onPasswordVisibilityToggle: () -> Unit,
    onPasswordNext: () -> Unit,
    onLogin: () -> Unit,
    passwordFocusRequester: FocusRequester
) {
    Column(
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Username field
        OutlinedTextField(
            value = username,
            onValueChange = onUsernameChange,
            label = { Text("Username") },
            leadingIcon = { 
                Icon(Icons.Filled.Person, contentDescription = null, tint = PrimaryCyberBlue) 
            },
            isError = usernameError != null,
            supportingText = usernameError?.let { { Text(it, color = ErrorRed) } },
            keyboardOptions = KeyboardOptions(
                keyboardType = KeyboardType.Text,
                imeAction = ImeAction.Next
            ),
            keyboardActions = KeyboardActions(
                onNext = { onPasswordNext() }
            ),
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = PrimaryCyberBlue,
                focusedLabelColor = PrimaryCyberBlue,
                cursorColor = PrimaryCyberBlue
            )
        )
        
        // Password field
        OutlinedTextField(
            value = password,
            onValueChange = onPasswordChange,
            label = { Text("Password") },
            leadingIcon = { 
                Icon(Icons.Filled.Lock, contentDescription = null, tint = PrimaryCyberBlue) 
            },
            trailingIcon = {
                IconButton(onClick = onPasswordVisibilityToggle) {
                    Icon(
                        imageVector = if (passwordVisible) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                        contentDescription = if (passwordVisible) "Hide password" else "Show password",
                        tint = TextTertiary
                    )
                }
            },
            visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
            isError = passwordError != null,
            supportingText = passwordError?.let { { Text(it, color = ErrorRed) } },
            keyboardOptions = KeyboardOptions(
                keyboardType = KeyboardType.Password,
                imeAction = ImeAction.Done
            ),
            keyboardActions = KeyboardActions(
                onDone = { onLogin() }
            ),
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .focusRequester(passwordFocusRequester),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = PrimaryCyberBlue,
                focusedLabelColor = PrimaryCyberBlue,
                cursorColor = PrimaryCyberBlue
            )
        )
        
        // Login button
        GradientButton(
            text = if (isLoading) "Logging in..." else "LOGIN",
            icon = if (isLoading) Icons.Filled.Refresh else Icons.Filled.Login,
            style = ButtonStyle.Primary,
            enabled = !isLoading && username.isNotBlank() && password.isNotBlank(),
            color1 = PrimaryCyberBlue,
            color2 = NeonPurple
        ) {
            onLogin()
        }
    }
}

@Composable
private fun RegisterForm(
    username: String,
    email: String,
    password: String,
    confirmPassword: String,
    passwordVisible: Boolean,
    confirmPasswordVisible: Boolean,
    usernameError: String?,
    emailError: String?,
    passwordError: String?,
    confirmPasswordError: String?,
    isLoading: Boolean,
    onUsernameChange: (String) -> Unit,
    onEmailChange: (String) -> Unit,
    onPasswordChange: (String) -> Unit,
    onConfirmPasswordChange: (String) -> Unit,
    onPasswordVisibilityToggle: () -> Unit,
    onConfirmPasswordVisibilityToggle: () -> Unit,
    onUsernameNext: () -> Unit,
    onEmailNext: () -> Unit,
    onPasswordNext: () -> Unit,
    onRegister: () -> Unit,
    emailFocusRequester: FocusRequester,
    passwordFocusRequester: FocusRequester,
    confirmPasswordFocusRequester: FocusRequester
) {
    Column(
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Username field
        OutlinedTextField(
            value = username,
            onValueChange = onUsernameChange,
            label = { Text("Username") },
            leadingIcon = { 
                Icon(Icons.Filled.Person, contentDescription = null, tint = PrimaryCyberBlue) 
            },
            isError = usernameError != null,
            supportingText = usernameError?.let { { Text(it, color = ErrorRed) } },
            keyboardOptions = KeyboardOptions(
                keyboardType = KeyboardType.Text,
                imeAction = ImeAction.Next
            ),
            keyboardActions = KeyboardActions(
                onNext = { onUsernameNext() }
            ),
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = PrimaryCyberBlue,
                focusedLabelColor = PrimaryCyberBlue,
                cursorColor = PrimaryCyberBlue
            )
        )
        
        // Email field
        OutlinedTextField(
            value = email,
            onValueChange = onEmailChange,
            label = { Text("Email") },
            leadingIcon = { 
                Icon(Icons.Filled.Email, contentDescription = null, tint = PrimaryCyberBlue) 
            },
            isError = emailError != null,
            supportingText = emailError?.let { { Text(it, color = ErrorRed) } },
            keyboardOptions = KeyboardOptions(
                keyboardType = KeyboardType.Email,
                imeAction = ImeAction.Next
            ),
            keyboardActions = KeyboardActions(
                onNext = { onEmailNext() }
            ),
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .focusRequester(emailFocusRequester),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = PrimaryCyberBlue,
                focusedLabelColor = PrimaryCyberBlue,
                cursorColor = PrimaryCyberBlue
            )
        )
        
        // Password field
        OutlinedTextField(
            value = password,
            onValueChange = onPasswordChange,
            label = { Text("Password") },
            leadingIcon = { 
                Icon(Icons.Filled.Lock, contentDescription = null, tint = PrimaryCyberBlue) 
            },
            trailingIcon = {
                IconButton(onClick = onPasswordVisibilityToggle) {
                    Icon(
                        imageVector = if (passwordVisible) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                        contentDescription = if (passwordVisible) "Hide password" else "Show password",
                        tint = TextTertiary
                    )
                }
            },
            visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
            isError = passwordError != null,
            supportingText = passwordError?.let { { Text(it, color = ErrorRed) } },
            keyboardOptions = KeyboardOptions(
                keyboardType = KeyboardType.Password,
                imeAction = ImeAction.Next
            ),
            keyboardActions = KeyboardActions(
                onNext = { onPasswordNext() }
            ),
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .focusRequester(passwordFocusRequester),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = PrimaryCyberBlue,
                focusedLabelColor = PrimaryCyberBlue,
                cursorColor = PrimaryCyberBlue
            )
        )
        
        // Confirm password field
        OutlinedTextField(
            value = confirmPassword,
            onValueChange = onConfirmPasswordChange,
            label = { Text("Confirm Password") },
            leadingIcon = { 
                Icon(Icons.Filled.Lock, contentDescription = null, tint = PrimaryCyberBlue) 
            },
            trailingIcon = {
                IconButton(onClick = onConfirmPasswordVisibilityToggle) {
                    Icon(
                        imageVector = if (confirmPasswordVisible) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                        contentDescription = if (confirmPasswordVisible) "Hide password" else "Show password",
                        tint = TextTertiary
                    )
                }
            },
            visualTransformation = if (confirmPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
            isError = confirmPasswordError != null,
            supportingText = confirmPasswordError?.let { { Text(it, color = ErrorRed) } },
            keyboardOptions = KeyboardOptions(
                keyboardType = KeyboardType.Password,
                imeAction = ImeAction.Done
            ),
            keyboardActions = KeyboardActions(
                onDone = { onRegister() }
            ),
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .focusRequester(confirmPasswordFocusRequester),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = PrimaryCyberBlue,
                focusedLabelColor = PrimaryCyberBlue,
                cursorColor = PrimaryCyberBlue
            )
        )
        
        // Register button
        GradientButton(
            text = if (isLoading) "Creating Account..." else "CREATE ACCOUNT",
            icon = if (isLoading) Icons.Filled.Refresh else Icons.Filled.PersonAdd,
            style = ButtonStyle.Primary,
            enabled = !isLoading && username.isNotBlank() && email.isNotBlank() && 
                     password.isNotBlank() && confirmPassword.isNotBlank(),
            color1 = NeonGreen,
            color2 = PrimaryCyberBlue
        ) {
            onRegister()
        }
    }
}