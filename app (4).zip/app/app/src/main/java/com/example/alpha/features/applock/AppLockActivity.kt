package com.example.alpha.features.applock

import android.app.Activity
import android.content.Context
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import com.example.alpha.ui.theme.*

class AppLockActivity : ComponentActivity() {
    
    private var lockedPackage: String? = null
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        lockedPackage = intent.getStringExtra("locked_package")
        
        setContent {
            AlphaTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    AppLockScreen(
                        onUnlockSuccess = {
                            finish()
                        },
                        onUnlockFailed = {
                            // Move app to background
                            moveTaskToBack(true)
                        }
                    )
                }
            }
        }
    }
    
    override fun onBackPressed() {
        // Prevent going back to the locked app
        moveTaskToBack(true)
    }
}

@Composable
fun AppLockScreen(
    onUnlockSuccess: () -> Unit,
    onUnlockFailed: () -> Unit
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF0A0F29),
                        Color(0xFF1B0033),
                        Color(0xFF0A0F29)
                    )
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.9f)
                .wrapContentHeight(),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(
                containerColor = Color(0xFF1A1A2E).copy(alpha = 0.95f)
            ),
            elevation = CardDefaults.cardElevation(defaultElevation = 16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(24.dp)
            ) {
                // Lock Icon
                Icon(
                    Icons.Filled.Lock,
                    contentDescription = "Locked",
                    tint = PrimaryCyberBlue,
                    modifier = Modifier.size(72.dp)
                )
                
                // Title
                Text(
                    text = "App Locked",
                    style = MaterialTheme.typography.headlineMedium.copy(
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                )
                
                // Description
                Text(
                    text = "This app is protected by Alpha Security",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = TextSecondary
                    )
                )
                
                // Unlock Button
                Button(
                    onClick = {
                        authenticateUser(context as FragmentActivity) { success ->
                            if (success) {
                                onUnlockSuccess()
                            } else {
                                onUnlockFailed()
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = PrimaryCyberBlue
                    ),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Text(
                        text = "Unlock with Biometric",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                
                // Cancel Button
                TextButton(
                    onClick = onUnlockFailed,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Go Back",
                        color = TextSecondary
                    )
                }
            }
        }
    }
}

private fun authenticateUser(activity: FragmentActivity, onResult: (Boolean) -> Unit) {
    val executor = ContextCompat.getMainExecutor(activity)
    val biometricManager = BiometricManager.from(activity)
    
    // Check what type of authentication is available
    val authenticators = when {
        biometricManager.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG) == BiometricManager.BIOMETRIC_SUCCESS -> {
            BiometricManager.Authenticators.BIOMETRIC_STRONG
        }
        biometricManager.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK) == BiometricManager.BIOMETRIC_SUCCESS -> {
            BiometricManager.Authenticators.BIOMETRIC_WEAK
        }
        biometricManager.canAuthenticate(BiometricManager.Authenticators.DEVICE_CREDENTIAL) == BiometricManager.BIOMETRIC_SUCCESS -> {
            BiometricManager.Authenticators.DEVICE_CREDENTIAL
        }
        else -> {
            BiometricManager.Authenticators.BIOMETRIC_WEAK or BiometricManager.Authenticators.DEVICE_CREDENTIAL
        }
    }
    
    val promptInfoBuilder = BiometricPrompt.PromptInfo.Builder()
        .setTitle("Unlock App")
        .setSubtitle("Authenticate to access this app")
        .setAllowedAuthenticators(authenticators)
    
    // Only add negative button if not using device credentials
    if (authenticators and BiometricManager.Authenticators.DEVICE_CREDENTIAL == 0) {
        promptInfoBuilder.setNegativeButtonText("Cancel")
    }
    
    val promptInfo = promptInfoBuilder.build()
    
    try {
        val biometricPrompt = BiometricPrompt(
            activity,
            executor,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    super.onAuthenticationSucceeded(result)
                    Toast.makeText(activity, "Authentication successful", Toast.LENGTH_SHORT).show()
                    onResult(true)
                }
                
                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    super.onAuthenticationError(errorCode, errString)
                    if (errorCode != BiometricPrompt.ERROR_USER_CANCELED) {
                        Toast.makeText(activity, "Authentication error: $errString", Toast.LENGTH_LONG).show()
                    }
                    onResult(false)
                }
                
                override fun onAuthenticationFailed() {
                    super.onAuthenticationFailed()
                    Toast.makeText(activity, "Authentication failed", Toast.LENGTH_SHORT).show()
                }
            }
        )
        biometricPrompt.authenticate(promptInfo)
    } catch (e: Exception) {
        Toast.makeText(activity, "Biometric authentication not available", Toast.LENGTH_LONG).show()
        onResult(false)
    }
}
