package com.example.alpha.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.launch
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Canvas
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.foundation.Canvas
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.alpha.ui.components.GradientButton
import com.example.alpha.ui.components.GradientBackground
import com.example.alpha.ui.components.BackgroundVariant
import com.example.alpha.ui.components.ButtonStyle
import com.example.alpha.ui.theme.*
import com.example.alpha.features.security.SecurityAnalyzer
import com.example.alpha.features.security.SecurityAnalysisResult
import com.example.alpha.features.security.SecurityRiskLevel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    onOpenAntiTheft: () -> Unit = {},
    onOpenAntivirus: () -> Unit = {},
    onOpenPermissions: () -> Unit = {},
    onOpenWebProtect: () -> Unit = {},
    onOpenAppVault: () -> Unit = {},
    onOpenDrawer: () -> Unit = {}
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val securityAnalyzer = remember { SecurityAnalyzer(context) }
    
    var securityAnalysis by remember { mutableStateOf<SecurityAnalysisResult?>(null) }
    var isAnalyzing by remember { mutableStateOf(false) }
    
    // Perform security analysis on first load
    LaunchedEffect(Unit) {
        isAnalyzing = true
        try {
            securityAnalysis = securityAnalyzer.performFullSecurityAnalysis()
        } catch (e: Exception) {
            // Handle error
        } finally {
            isAnalyzing = false
        }
    }
    
    // Advanced floating animations for dashboard elements
    val infiniteTransition = rememberInfiniteTransition(label = "dashboard_animations")
    
    val headerFloat by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 10f,
        animationSpec = infiniteRepeatable(
            tween(4000, easing = FastOutSlowInEasing),
            RepeatMode.Reverse
        ),
        label = "header_float"
    )
    
    val cardFloat by infiniteTransition.animateFloat(
        initialValue = -5f,
        targetValue = 5f,
        animationSpec = infiniteRepeatable(
            tween(6000, easing = FastOutSlowInEasing),
            RepeatMode.Reverse
        ),
        label = "card_float"
    )
    
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            tween(2000, easing = FastOutSlowInEasing),
            RepeatMode.Reverse
        ),
        label = "pulse"
    )

    GradientBackground(variant = BackgroundVariant.Primary) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.offset(y = headerFloat.dp)
                        ) {
                            Icon(
                                Icons.Filled.Shield,
                                contentDescription = null,
                                tint = PrimaryCyberBlue,
                                modifier = Modifier
                                    .size(32.dp)
                                    .scale(pulseAlpha)
                            )
                            Spacer(Modifier.width(12.dp))
                            Column {
                                Text(
                                    "ALPHA SECURITY",
                                    style = MaterialTheme.typography.titleLarge.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = TextPrimary,
                                        letterSpacing = 2.sp
                                    )
                                )
                                Text(
                                    "Neural Defense System",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = PrimaryCyberBlue,
                                        letterSpacing = 1.sp
                                    )
                                )
                            }
                        }
                    },
                    navigationIcon = {
                        IconButton(
                            onClick = onOpenDrawer,
                            modifier = Modifier
                                .background(
                                    PrimaryCyberBlue.copy(alpha = 0.1f),
                                    CircleShape
                                )
                                .border(
                                    1.dp,
                                    PrimaryCyberBlue.copy(alpha = 0.3f),
                                    CircleShape
                                )
                        ) {
                            Icon(
                                Icons.Filled.Menu,
                                contentDescription = "Open menu",
                                tint = PrimaryCyberBlue
                            )
                        }
                    },
                    colors = TopAppBarDefaults.mediumTopAppBarColors(
                        containerColor = Color.Transparent
                    ),
                    modifier = Modifier.background(
                        Brush.horizontalGradient(
                            colors = listOf(
                                SurfaceGlass,
                                SurfaceGlass.copy(alpha = 0.8f),
                                Color.Transparent
                            )
                        )
                    )
                )
            },
            containerColor = Color.Transparent
        ) { padding ->
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(horizontal = 20.dp),
                verticalArrangement = Arrangement.spacedBy(24.dp),
                contentPadding = PaddingValues(vertical = 16.dp)
            ) {
                // AI Security Analysis Score
                item {
                    AISecurityScoreCard(
                        securityAnalysis = securityAnalysis,
                        isAnalyzing = isAnalyzing,
                        onRefresh = {
                            scope.launch {
                                isAnalyzing = true
                                try {
                                    securityAnalysis = securityAnalyzer.performFullSecurityAnalysis()
                                } catch (e: Exception) {
                                    // Handle error
                                } finally {
                                    isAnalyzing = false
                                }
                            }
                        },
                        modifier = Modifier.offset(y = cardFloat.dp)
                    )
                }
                
                // Status Dashboard Header
                item {
                    StatusDashboard(
                        modifier = Modifier.offset(y = (-cardFloat).dp)
                    )
                }
                
                // Quick Actions Section
                item {
                    Text(
                        "SECURITY MODULES",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = TextAccent,
                            letterSpacing = 1.5.sp
                        ),
                        modifier = Modifier.padding(vertical = 8.dp)
                    )
                }
                
                // Feature Cards Grid
                item {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(2),
                        verticalArrangement = Arrangement.spacedBy(16.dp),
                        horizontalArrangement = Arrangement.spacedBy(16.dp),
                        modifier = Modifier.height(400.dp)
                    ) {
                        item {
                            FuturisticFeatureCard(
                                title = "Anti-Theft",
                                subtitle = "Location Shield",
                                icon = Icons.Filled.LocationOn,
                                color = PrimaryCyberBlue,
                                onClick = onOpenAntiTheft,
                                animationDelay = 0
                            )
                        }
                        item {
                            FuturisticFeatureCard(
                                title = "Antivirus",
                                subtitle = "Threat Scanner",
                                icon = Icons.Filled.Shield,
                                color = NeonPurple,
                                onClick = onOpenAntivirus,
                                animationDelay = 100
                            )
                        }
                        item {
                            FuturisticFeatureCard(
                                title = "Permissions",
                                subtitle = "Access Control",
                                icon = Icons.Filled.Settings,
                                color = NeonOrange,
                                onClick = onOpenPermissions,
                                animationDelay = 200
                            )
                        }
                        item {
                            FuturisticFeatureCard(
                                title = "Web Shield",
                                subtitle = "Browse Safe",
                                icon = Icons.Filled.Security,
                                color = NeonGreen,
                                onClick = onOpenWebProtect,
                                animationDelay = 300
                            )
                        }
                    }
                }
                
                // App Vault - Special highlighted card
                item {
                    FuturisticVaultCard(
                        title = "Secure Vault",
                        subtitle = "Apps & Documents",
                        icon = Icons.Filled.Lock,
                        onClick = onOpenAppVault,
                        modifier = Modifier.offset(y = (-cardFloat).dp)
                    )
                }
                
                // Quick Scan Button
                item {
                    GradientButton(
                        text = "INITIATE FULL SYSTEM SCAN",
                        icon = Icons.Filled.Bolt,
                        style = ButtonStyle.Primary,
                        color1 = PrimaryCyberBlue,
                        color2 = NeonPurple
                    ) {
                        onOpenAntivirus()
                    }
                }
                
                // Footer
                item {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(vertical = 24.dp)
                    ) {
                        Text(
                            "ALPHA NEURAL SECURITY SYSTEM",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = TextTertiary,
                                letterSpacing = 1.sp
                            )
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "© 2025 • QUANTUM DEFENSE PROTOCOL ACTIVE",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = PrimaryCyberBlue.copy(alpha = 0.6f),
                                letterSpacing = 0.5.sp
                            )
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun StatusDashboard(
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = SurfaceGlass
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
    ) {
        Box(
            modifier = Modifier
                .background(
                    Brush.linearGradient(
                        colors = listOf(
                            SurfaceGlass,
                            SurfaceGlassBright,
                            SurfaceGlass
                        )
                    )
                )
                .padding(24.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        "SYSTEM STATUS",
                        style = MaterialTheme.typography.labelLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = TextSecondary,
                            letterSpacing = 1.sp
                        )
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "ALL SYSTEMS OPERATIONAL",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = SuccessGreen
                        )
                    )
                }
                
                Box(
                    modifier = Modifier
                        .size(60.dp)
                        .background(
                            SuccessGreen.copy(alpha = 0.2f),
                            CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Filled.CheckCircle,
                        contentDescription = null,
                        tint = SuccessGreen,
                        modifier = Modifier.size(32.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun FuturisticFeatureCard(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    onClick: () -> Unit,
    animationDelay: Int = 0,
    modifier: Modifier = Modifier
) {
    var pressed by remember { mutableStateOf(false) }
    
    val infiniteTransition = rememberInfiniteTransition(label = "card_glow")
    val glowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 0.8f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = 2000 + animationDelay,
                easing = FastOutSlowInEasing
            ),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glow"
    )
    
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.95f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
        label = "scale"
    )
    
    Card(
        modifier = modifier
            .aspectRatio(1f)
            .scale(scale)
            .clickable {
                pressed = true
                onClick()
                pressed = false
            },
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color.Transparent
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 12.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            color.copy(alpha = 0.1f),
                            SurfaceGlass,
                            BackgroundCard
                        ),
                        radius = 200f
                    )
                )
                .border(
                    width = 1.dp,
                    brush = Brush.linearGradient(
                        colors = listOf(
                            color.copy(alpha = glowAlpha * 0.8f),
                            color.copy(alpha = glowAlpha * 0.4f),
                            Color.Transparent
                        )
                    ),
                    shape = RoundedCornerShape(20.dp)
                )
                .padding(20.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .background(
                            color.copy(alpha = 0.2f),
                            CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = color,
                        modifier = Modifier.size(24.dp)
                    )
                }
                
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                )
                
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = color.copy(alpha = 0.9f),
                        fontWeight = FontWeight.Medium
                    )
                )
            }
        }
    }
}

@Composable
fun FuturisticVaultCard(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "vault_animation")
    
    val shimmer by infiniteTransition.animateFloat(
        initialValue = -1000f,
        targetValue = 1000f,
        animationSpec = infiniteRepeatable(
            animation = tween(3000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "shimmer"
    )
    
    val pulse by infiniteTransition.animateFloat(
        initialValue = 0.8f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )
    
    Card(
        modifier = modifier
            .fillMaxWidth()
            .height(120.dp)
            .clickable { onClick() },
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color.Transparent
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 16.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.linearGradient(
                        colors = listOf(
                            NeonPink.copy(alpha = 0.1f),
                            NeonPurple.copy(alpha = 0.15f),
                            PrimaryCyberBlue.copy(alpha = 0.1f)
                        )
                    )
                )
                .border(
                    width = 2.dp,
                    brush = Brush.linearGradient(
                        colors = listOf(
                            NeonPink.copy(alpha = pulse * 0.8f),
                            NeonPurple.copy(alpha = pulse * 0.6f),
                            PrimaryCyberBlue.copy(alpha = pulse * 0.4f)
                        ),
                        start = Offset(shimmer - 200f, 0f),
                        end = Offset(shimmer + 200f, 100f)
                    ),
                    shape = RoundedCornerShape(24.dp)
                )
        ) {
            // Shimmer overlay
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.linearGradient(
                            colors = listOf(
                                Color.Transparent,
                                Color.White.copy(alpha = 0.1f),
                                Color.Transparent
                            ),
                            start = Offset(shimmer - 100f, 0f),
                            end = Offset(shimmer + 100f, 0f)
                        )
                    )
            )
            
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .background(
                            Brush.radialGradient(
                                colors = listOf(
                                    NeonPink.copy(alpha = 0.3f),
                                    NeonPurple.copy(alpha = 0.2f)
                                )
                            ),
                            CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = NeonPink,
                        modifier = Modifier.size(32.dp)
                    )
                }
                
                Spacer(Modifier.width(20.dp))
                
                Column {
                    Text(
                        title,
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                    )
                    Text(
                        subtitle,
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = NeonPurple,
                            fontWeight = FontWeight.Medium
                        )
                    )
                }
                
                Spacer(Modifier.weight(1f))
                
                Icon(
                    Icons.AutoMirrored.Filled.ArrowForward,
                    contentDescription = "Open",
                    tint = PrimaryCyberBlue,
                    modifier = Modifier.size(24.dp)
                )
            }
        }
    }
}

@Composable
fun AISecurityScoreCard(
    securityAnalysis: SecurityAnalysisResult?,
    isAnalyzing: Boolean,
    onRefresh: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "ai_score_animation")
    
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.7f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )
    
    val shimmer by infiniteTransition.animateFloat(
        initialValue = -1000f,
        targetValue = 1000f,
        animationSpec = infiniteRepeatable(
            animation = tween(3000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "shimmer"
    )
    
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color.Transparent
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 16.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.linearGradient(
                        colors = listOf(
                            PrimaryCyberBlue.copy(alpha = 0.1f),
                            NeonPurple.copy(alpha = 0.15f),
                            NeonGreen.copy(alpha = 0.1f)
                        )
                    )
                )
                .border(
                    width = 2.dp,
                    brush = Brush.linearGradient(
                        colors = listOf(
                            PrimaryCyberBlue.copy(alpha = pulseAlpha * 0.8f),
                            NeonPurple.copy(alpha = pulseAlpha * 0.6f),
                            NeonGreen.copy(alpha = pulseAlpha * 0.4f)
                        ),
                        start = Offset(shimmer - 200f, 0f),
                        end = Offset(shimmer + 200f, 100f)
                    ),
                    shape = RoundedCornerShape(24.dp)
                )
        ) {
            // Shimmer overlay
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.linearGradient(
                            colors = listOf(
                                Color.Transparent,
                                Color.White.copy(alpha = 0.1f),
                                Color.Transparent
                            ),
                            start = Offset(shimmer - 100f, 0f),
                            end = Offset(shimmer + 100f, 0f)
                        )
                    )
            )
            
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Filled.Psychology,
                            contentDescription = null,
                            tint = PrimaryCyberBlue,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = "AI SECURITY ANALYSIS",
                            style = MaterialTheme.typography.labelMedium.copy(
                                color = PrimaryCyberBlue,
                                letterSpacing = 1.sp,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }
                    
                    Spacer(modifier = Modifier.height(12.dp))
                    
                    if (isAnalyzing) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                color = PrimaryCyberBlue,
                                strokeWidth = 2.dp
                            )
                            Spacer(Modifier.width(12.dp))
                            Text(
                                text = "Analyzing device security...",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    color = TextSecondary
                                )
                            )
                        }
                    } else if (securityAnalysis != null) {
                        Text(
                            text = "Security Score",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = TextSecondary
                            )
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            verticalAlignment = Alignment.Bottom
                        ) {
                            Text(
                                text = securityAnalysis.overallScore.toString(),
                                style = MaterialTheme.typography.displayMedium.copy(
                                    color = getSecurityScoreColor(securityAnalysis.overallScore),
                                    fontWeight = FontWeight.Bold
                                )
                            )
                            Text(
                                text = "/100",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    color = TextTertiary
                                ),
                                modifier = Modifier.padding(bottom = 6.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = getRiskLevelText(securityAnalysis.riskLevel),
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = getSecurityScoreColor(securityAnalysis.overallScore),
                                fontWeight = FontWeight.Medium
                            )
                        )
                    } else {
                        Text(
                            text = "Unable to analyze security",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = ErrorRed
                            )
                        )
                    }
                }
                
                // Security Score Visualization
                Box(
                    modifier = Modifier.size(80.dp),
                    contentAlignment = Alignment.Center
                ) {
                    if (isAnalyzing) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(64.dp),
                            color = PrimaryCyberBlue,
                            strokeWidth = 6.dp
                        )
                    } else if (securityAnalysis != null) {
                        SecurityScoreRing(
                            score = securityAnalysis.overallScore,
                            size = 64.dp
                        )
                    } else {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .background(
                                    ErrorRed.copy(alpha = 0.2f),
                                    CircleShape
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Filled.Error,
                                contentDescription = null,
                                tint = ErrorRed,
                                modifier = Modifier.size(32.dp)
                            )
                        }
                    }
                }
                
                Spacer(Modifier.width(16.dp))
                
                IconButton(
                    onClick = onRefresh,
                    enabled = !isAnalyzing
                ) {
                    Icon(
                        Icons.Filled.Refresh,
                        contentDescription = "Refresh Analysis",
                        tint = if (isAnalyzing) TextTertiary else PrimaryCyberBlue,
                        modifier = if (isAnalyzing) Modifier.scale(pulseAlpha) else Modifier
                    )
                }
            }
        }
    }
}

@Composable
fun SecurityScoreRing(
    score: Int,
    size: androidx.compose.ui.unit.Dp,
    strokeWidth: androidx.compose.ui.unit.Dp = 6.dp
) {
    val animatedProgress by animateFloatAsState(
        targetValue = score / 100f,
        animationSpec = tween(
            durationMillis = 2000,
            easing = FastOutSlowInEasing
        ),
        label = "score_progress"
    )
    
    Box(
        modifier = Modifier.size(size),
        contentAlignment = Alignment.Center
    ) {
        Canvas(
            modifier = Modifier.fillMaxSize()
        ) {
            val strokeWidthPx = strokeWidth.toPx()
            val radius = (this.size.width - strokeWidthPx) / 2
            val center = Offset(this.size.width / 2, this.size.height / 2)
            
            // Background circle
            drawCircle(
                color = Color(0xFF2A2F3D),
                radius = radius,
                center = center,
                style = Stroke(strokeWidthPx)
            )
            
            // Progress arc
            val sweepAngle = 360f * animatedProgress
            drawArc(
                color = getSecurityScoreColor(score),
                startAngle = -90f,
                sweepAngle = sweepAngle,
                useCenter = false,
                topLeft = Offset(
                    center.x - radius,
                    center.y - radius
                ),
                size = Size(radius * 2, radius * 2),
                style = Stroke(
                    width = strokeWidthPx,
                    cap = StrokeCap.Round
                )
            )
        }
        
        Icon(
            imageVector = getSecurityIcon(score),
            contentDescription = null,
            tint = getSecurityScoreColor(score),
            modifier = Modifier.size(24.dp)
        )
    }
}

fun getSecurityScoreColor(score: Int): Color {
    return when {
        score >= 90 -> SuccessGreen
        score >= 75 -> NeonGreen
        score >= 60 -> WarningAmber
        score >= 40 -> NeonOrange
        else -> ErrorRed
    }
}

fun getSecurityIcon(score: Int): androidx.compose.ui.graphics.vector.ImageVector {
    return when {
        score >= 90 -> Icons.Filled.Security
        score >= 75 -> Icons.Filled.Shield
        score >= 60 -> Icons.Filled.Warning
        else -> Icons.Filled.Error
    }
}

fun getRiskLevelText(riskLevel: SecurityRiskLevel): String {
    return when (riskLevel) {
        SecurityRiskLevel.EXCELLENT -> "EXCELLENT SECURITY"
        SecurityRiskLevel.GOOD -> "GOOD SECURITY"
        SecurityRiskLevel.FAIR -> "FAIR SECURITY"
        SecurityRiskLevel.POOR -> "POOR SECURITY"
        SecurityRiskLevel.CRITICAL -> "CRITICAL ISSUES"
    }
}
