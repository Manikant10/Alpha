package com.example.alpha

import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.alpha.data.auth.*
import com.example.alpha.ui.theme.*
import kotlinx.coroutines.launch

class RegistrationTestActivity : ComponentActivity() {
    
    private val TAG = "RegistrationTest"
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        Log.d(TAG, "RegistrationTestActivity started")
        
        setContent {
            MaterialTheme {
                RegistrationTestScreen()
            }
        }
    }
}

@Composable
fun RegistrationTestScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val authManager = remember { AuthManager.getInstance(context) }
    
    var username by remember { mutableStateOf("testuser" + System.currentTimeMillis().toString().takeLast(4)) }
    var email by remember { mutableStateOf("test${System.currentTimeMillis().toString().takeLast(4)}@example.com") }
    var password by remember { mutableStateOf("TestPassword123!") }
    var result by remember { mutableStateOf("Ready to test") }
    var isLoading by remember { mutableStateOf(false) }
    
    // Observe auth state
    val authState by authManager.authState.collectAsState()
    
    LaunchedEffect(authState) {
        Log.d("RegistrationTest", "Auth state changed: $authState")
        when (val state = authState) {
            is AuthState.Success -> {
                result = "SUCCESS! User: ${state.user.username}, Token: ${state.token?.take(20)}..."
                isLoading = false
            }
            is AuthState.Error -> {
                result = "ERROR: ${state.message}"
                isLoading = false
            }
            is AuthState.Loading -> {
                result = "Loading..."
                isLoading = true
            }
            else -> {
                // Idle state
                if (!isLoading) {
                    result = "Ready to test"
                }
            }
        }
    }
    
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            "Registration Test",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold
        )
        
        OutlinedTextField(
            value = username,
            onValueChange = { username = it },
            label = { Text("Username") },
            enabled = !isLoading,
            modifier = Modifier.fillMaxWidth()
        )
        
        OutlinedTextField(
            value = email,
            onValueChange = { email = it },
            label = { Text("Email") },
            enabled = !isLoading,
            modifier = Modifier.fillMaxWidth()
        )
        
        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Password") },
            enabled = !isLoading,
            modifier = Modifier.fillMaxWidth()
        )
        
        Button(
            onClick = {
                scope.launch {
                    Log.d("RegistrationTest", "Starting registration test with username: $username, email: $email")
                    try {
                        result = "Testing..."
                        isLoading = true
                        
                        // Test direct API call first
                        val apiService = AuthApiService(context)
                        Log.d("RegistrationTest", "Testing direct API call")
                        val directResponse = apiService.register(username, email, password)
                        Log.d("RegistrationTest", "Direct API response: success=${directResponse.success}, error=${directResponse.error}")
                        
                        // Then test through AuthManager
                        Log.d("RegistrationTest", "Testing through AuthManager")
                        val managerResponse = authManager.register(username, email, password)
                        Log.d("RegistrationTest", "AuthManager response: $managerResponse")
                        
                    } catch (e: Exception) {
                        Log.e("RegistrationTest", "Exception during test", e)
                        result = "Exception: ${e.message}"
                        isLoading = false
                    }
                }
            },
            enabled = !isLoading && username.isNotBlank() && email.isNotBlank() && password.isNotBlank(),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(if (isLoading) "Testing..." else "Test Registration")
        }
        
        Card(
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = result,
                modifier = Modifier.padding(16.dp),
                color = when {
                    result.startsWith("SUCCESS") -> Color.Green
                    result.startsWith("ERROR") -> Color.Red
                    result.startsWith("Exception") -> Color.Red
                    else -> Color.Black
                }
            )
        }
        
        Button(
            onClick = {
                // Generate new test data
                username = "testuser" + System.currentTimeMillis().toString().takeLast(4)
                email = "test${System.currentTimeMillis().toString().takeLast(4)}@example.com"
                password = "TestPassword123!"
                result = "Ready to test"
                authManager.resetAuthState()
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Reset & Generate New Test Data")
        }
    }
}