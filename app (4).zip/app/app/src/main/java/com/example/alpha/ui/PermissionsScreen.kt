package com.example.alpha.ui

import android.content.Intent
import android.provider.Settings
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.alpha.features.permissions.*
import com.example.alpha.ui.components.GradientButton
import com.example.alpha.ui.components.ScreenScaffold
import com.example.alpha.ui.components.BackgroundVariant
import com.example.alpha.ui.components.ButtonStyle
import com.example.alpha.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun PermissionsScreen(
    onBack: () -> Unit,
    onOpenDrawer: () -> Unit = {}
) {
    val context = LocalContext.current
    val permissionsManager = remember { PermissionsManager(context) }
    val scope = rememberCoroutineScope()
    
    var appPermissions by remember { mutableStateOf<List<AppPermissionInfo>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    var selectedTab by remember { mutableStateOf(0) }
    var searchQuery by remember { mutableStateOf("") }
    var filterByRisk by remember { mutableStateOf(RiskLevel.HIGH) }
    
    LaunchedEffect(Unit) {
        scope.launch {
            try {
                appPermissions = permissionsManager.analyzeAllApps()
            } catch (e: Exception) {
                // Handle error
            } finally {
                isLoading = false
            }
        }
    }
    
    val filteredApps = appPermissions.filter { app ->
        (searchQuery.isEmpty() || app.appName.contains(searchQuery, ignoreCase = true)) &&
        (selectedTab == 0 || (selectedTab == 1 && !app.isSystemApp) || (selectedTab == 2 && app.isSystemApp)) &&
        app.riskScore >= when (filterByRisk) {
            RiskLevel.LOW -> 0
            RiskLevel.MEDIUM -> 20
            RiskLevel.HIGH -> 40
            RiskLevel.CRITICAL -> 60
        }
    }
    
    ScreenScaffold(
        title = "App Permission Analyzer",
        onBack = onBack,
        onOpenDrawer = onOpenDrawer,
        backgroundVariant = BackgroundVariant.Security
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            // Analysis Header
            PermissionAnalysisHeader(
                totalApps = appPermissions.size,
                highRiskApps = appPermissions.count { it.riskScore >= 40 },
                isLoading = isLoading
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Search and Filter Section
            SearchAndFilterSection(
                searchQuery = searchQuery,
                onSearchChange = { searchQuery = it },
                filterByRisk = filterByRisk,
                onFilterChange = { filterByRisk = it }
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Tab Row
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = Color.Transparent,
                contentColor = PrimaryCyberBlue,
                indicator = { tabPositions ->
                    if (tabPositions.isNotEmpty()) {
                        TabRowDefaults.Indicator(
                            modifier = Modifier,
                            color = PrimaryCyberBlue
                        )
                    }
                }
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = {
                        Text(
                            "All Apps (${appPermissions.size})",
                            color = if (selectedTab == 0) PrimaryCyberBlue else TextSecondary
                        )
                    }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = {
                        Text(
                            "User Apps (${appPermissions.count { !it.isSystemApp }})",
                            color = if (selectedTab == 1) PrimaryCyberBlue else TextSecondary
                        )
                    }
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = {
                        Text(
                            "System Apps (${appPermissions.count { it.isSystemApp }})",
                            color = if (selectedTab == 2) PrimaryCyberBlue else TextSecondary
                        )
                    }
                )
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Apps List
            if (isLoading) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(color = PrimaryCyberBlue)
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(filteredApps) { appInfo ->
                        AppPermissionCard(
                            appInfo = appInfo,
                            onClick = {
                                val intent = permissionsManager.openAppSettingsIntent(appInfo.packageName)
                                context.startActivity(intent)
                            }
                        )
                    }
                    
                    if (filteredApps.isEmpty() && !isLoading) {
                        item {
                            EmptyStateCard()
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PermissionAnalysisHeader(
    totalApps: Int,
    highRiskApps: Int,
    isLoading: Boolean
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceGlass)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    text = "PERMISSION ANALYSIS",
                    style = MaterialTheme.typography.labelMedium.copy(
                        color = TextSecondary,
                        letterSpacing = 1.sp
                    )
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = if (isLoading) "Scanning..." else "$totalApps Apps Analyzed",
                    style = MaterialTheme.typography.titleMedium.copy(
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                )
                if (!isLoading) {
                    Text(
                        text = "$highRiskApps high-risk apps detected",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = if (highRiskApps > 0) WarningAmber else SuccessGreen
                        )
                    )
                }
            }
            
            Box(
                modifier = Modifier
                    .size(60.dp)
                    .background(
                        if (highRiskApps > 0) WarningAmber.copy(alpha = 0.2f) else SuccessGreen.copy(alpha = 0.2f),
                        CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                if (isLoading) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(32.dp),
                        color = PrimaryCyberBlue
                    )
                } else {
                    Icon(
                        imageVector = if (highRiskApps > 0) Icons.Filled.Warning else Icons.Filled.Security,
                        contentDescription = null,
                        tint = if (highRiskApps > 0) WarningAmber else SuccessGreen,
                        modifier = Modifier.size(32.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun SearchAndFilterSection(
    searchQuery: String,
    onSearchChange: (String) -> Unit,
    filterByRisk: RiskLevel,
    onFilterChange: (RiskLevel) -> Unit
) {
    Column {
        OutlinedTextField(
            value = searchQuery,
            onValueChange = onSearchChange,
            label = { Text("Search apps...", color = TextSecondary) },
            leadingIcon = {
                Icon(
                    Icons.Filled.Search,
                    contentDescription = "Search",
                    tint = PrimaryCyberBlue
                )
            },
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = PrimaryCyberBlue,
                unfocusedBorderColor = TextTertiary,
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary
            ),
            modifier = Modifier.fillMaxWidth()
        )
        
        Spacer(modifier = Modifier.height(12.dp))
        
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = "Risk Level:",
                color = TextSecondary,
                modifier = Modifier.align(Alignment.CenterVertically)
            )
            
            RiskLevel.values().forEach { risk ->
                FilterChip(
                    onClick = { onFilterChange(risk) },
                    label = {
                        Text(
                            text = risk.name,
                            color = if (filterByRisk == risk) BackgroundPrimary else TextPrimary
                        )
                    },
                    selected = filterByRisk == risk,
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = when (risk) {
                            RiskLevel.CRITICAL -> ErrorRed
                            RiskLevel.HIGH -> WarningAmber
                            RiskLevel.MEDIUM -> InfoBlue
                            RiskLevel.LOW -> SuccessGreen
                        },
                        containerColor = SurfaceGlass
                    )
                )
            }
        }
    }
}

@Composable
fun AppPermissionCard(
    appInfo: AppPermissionInfo,
    onClick: () -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { expanded = !expanded },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = SurfaceGlass
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Risk Score Indicator
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .background(
                            getRiskColor(appInfo.riskScore).copy(alpha = 0.2f),
                            CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = appInfo.riskScore.toString(),
                        style = MaterialTheme.typography.labelLarge.copy(
                            color = getRiskColor(appInfo.riskScore),
                            fontWeight = FontWeight.Bold
                        )
                    )
                }
                
                Spacer(modifier = Modifier.width(12.dp))
                
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = appInfo.appName,
                        style = MaterialTheme.typography.titleSmall.copy(
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold
                        ),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "${appInfo.permissions.size} permissions",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = TextSecondary
                        )
                    )
                    if (appInfo.isSystemApp) {
                        Text(
                            text = "SYSTEM APP",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = InfoBlue
                            )
                        )
                    }
                }
                
                Row {
                    IconButton(
                        onClick = onClick
                    ) {
                        Icon(
                            Icons.Filled.Settings,
                            contentDescription = "App Settings",
                            tint = PrimaryCyberBlue
                        )
                    }
                    
                    IconButton(
                        onClick = { expanded = !expanded }
                    ) {
                        Icon(
                            if (expanded) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore,
                            contentDescription = if (expanded) "Collapse" else "Expand",
                            tint = TextSecondary
                        )
                    }
                }
            }
            
            AnimatedVisibility(
                visible = expanded,
                enter = expandVertically(),
                exit = shrinkVertically()
            ) {
                Column {
                    Spacer(modifier = Modifier.height(16.dp))
                    Divider(color = SurfaceGlass)
                    Spacer(modifier = Modifier.height(16.dp))
                    
                    Text(
                        text = "PERMISSIONS BREAKDOWN",
                        style = MaterialTheme.typography.labelMedium.copy(
                            color = TextSecondary,
                            letterSpacing = 1.sp
                        )
                    )
                    
                    Spacer(modifier = Modifier.height(12.dp))
                    
                    // Group permissions by category
                    val permissionsByCategory = appInfo.permissions.groupBy { it.category }
                    
                    permissionsByCategory.forEach { (category, permissions) ->
                        PermissionCategorySection(
                            category = category,
                            permissions = permissions
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun PermissionCategorySection(
    category: PermissionCategory,
    permissions: List<PermissionDetail>
) {
    Column {
        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = getCategoryIcon(category),
                contentDescription = null,
                tint = getCategoryColor(category),
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = category.name,
                style = MaterialTheme.typography.labelSmall.copy(
                    color = getCategoryColor(category),
                    fontWeight = FontWeight.Medium
                )
            )
        }
        
        Spacer(modifier = Modifier.height(8.dp))
        
        permissions.forEach { permission ->
            PermissionDetailItem(permission = permission)
        }
        
        Spacer(modifier = Modifier.height(12.dp))
    }
}

@Composable
fun PermissionDetailItem(
    permission: PermissionDetail
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.Top
    ) {
        Box(
            modifier = Modifier
                .size(12.dp)
                .background(
                    if (permission.isGranted) SuccessGreen else ErrorRed,
                    CircleShape
                )
        )
        
        Spacer(modifier = Modifier.width(8.dp))
        
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = permission.displayName,
                style = MaterialTheme.typography.bodySmall.copy(
                    color = TextPrimary,
                    fontWeight = FontWeight.Medium
                )
            )
            Text(
                text = permission.description,
                style = MaterialTheme.typography.bodySmall.copy(
                    color = TextTertiary
                ),
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
        
        Box(
            modifier = Modifier
                .background(
                    getRiskColor(permission.riskLevel).copy(alpha = 0.2f),
                    RoundedCornerShape(12.dp)
                )
                .border(
                    1.dp,
                    getRiskColor(permission.riskLevel).copy(alpha = 0.5f),
                    RoundedCornerShape(12.dp)
                )
                .padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
            Text(
                text = permission.riskLevel.name,
                style = MaterialTheme.typography.labelSmall.copy(
                    color = getRiskColor(permission.riskLevel),
                    fontWeight = FontWeight.Medium
                )
            )
        }
    }
}

@Composable
fun EmptyStateCard() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceGlass)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                Icons.Filled.Search,
                contentDescription = null,
                tint = TextTertiary,
                modifier = Modifier.size(48.dp)
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "No apps match your criteria",
                style = MaterialTheme.typography.titleMedium.copy(
                    color = TextPrimary
                )
            )
            Text(
                text = "Try adjusting your search or filter settings",
                style = MaterialTheme.typography.bodySmall.copy(
                    color = TextSecondary
                )
            )
        }
    }
}

fun getRiskColor(riskScore: Int): Color {
    return when {
        riskScore >= 60 -> ErrorRed
        riskScore >= 40 -> WarningAmber
        riskScore >= 20 -> InfoBlue
        else -> SuccessGreen
    }
}

fun getRiskColor(riskLevel: RiskLevel): Color {
    return when (riskLevel) {
        RiskLevel.CRITICAL -> ErrorRed
        RiskLevel.HIGH -> WarningAmber
        RiskLevel.MEDIUM -> InfoBlue
        RiskLevel.LOW -> SuccessGreen
    }
}

fun getCategoryIcon(category: PermissionCategory): ImageVector {
    return when (category) {
        PermissionCategory.LOCATION -> Icons.Filled.LocationOn
        PermissionCategory.CAMERA -> Icons.Filled.CameraAlt
        PermissionCategory.MICROPHONE -> Icons.Filled.Mic
        PermissionCategory.CONTACTS -> Icons.Filled.Contacts
        PermissionCategory.STORAGE -> Icons.Filled.Storage
        PermissionCategory.PHONE -> Icons.Filled.Phone
        PermissionCategory.SMS -> Icons.Filled.Message
        PermissionCategory.CALENDAR -> Icons.Filled.CalendarToday
        PermissionCategory.SENSORS -> Icons.Filled.Sensors
        PermissionCategory.NETWORK -> Icons.Filled.Wifi
        PermissionCategory.SYSTEM -> Icons.Filled.Settings
        PermissionCategory.OTHER -> Icons.Filled.MoreHoriz
    }
}

fun getCategoryColor(category: PermissionCategory): Color {
    return when (category) {
        PermissionCategory.LOCATION -> ErrorRed
        PermissionCategory.CAMERA -> WarningAmber
        PermissionCategory.MICROPHONE -> ErrorRed
        PermissionCategory.CONTACTS -> WarningAmber
        PermissionCategory.STORAGE -> InfoBlue
        PermissionCategory.PHONE -> ErrorRed
        PermissionCategory.SMS -> WarningAmber
        PermissionCategory.CALENDAR -> InfoBlue
        PermissionCategory.SENSORS -> SuccessGreen
        PermissionCategory.NETWORK -> SuccessGreen
        PermissionCategory.SYSTEM -> TextSecondary
        PermissionCategory.OTHER -> TextTertiary
    }
}
