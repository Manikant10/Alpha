package com.example.alpha.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.alpha.R
import com.example.alpha.config.ServerConfig
import com.example.alpha.data.auth.AuthManager
import com.example.alpha.device.AdminReceiver
import com.example.alpha.features.antitheft.AntiTheftManager
import io.socket.client.IO
import io.socket.client.Socket
import io.socket.emitter.Emitter
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import org.json.JSONObject

/**
 * Background service that maintains WebSocket connection to Alpha Security Server
 * Listens for remote commands and executes them on the device
 */
class RemoteCommandService : Service() {

    private var socket: Socket? = null
    private lateinit var authManager: AuthManager
    private lateinit var antiTheftManager: AntiTheftManager
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    companion object {
        private const val TAG = "RemoteCommandService"
        private const val NOTIFICATION_ID = 1002
        private const val CHANNEL_ID = "alpha_remote_commands"

        fun start(context: Context) {
            val intent = Intent(context, RemoteCommandService::class.java)
            context.startService(intent)
        }

        fun stop(context: Context) {
            val intent = Intent(context, RemoteCommandService::class.java)
            context.stopService(intent)
        }
    }

    override fun onCreate() {
        super.onCreate()
        Log.d(TAG, "RemoteCommandService created")

        authManager = AuthManager.getInstance(applicationContext)
        val adminComponent = ComponentName(this, AdminReceiver::class.java)
        antiTheftManager = AntiTheftManager(applicationContext, adminComponent)

        createNotificationChannel()
        startForeground(NOTIFICATION_ID, createNotification())

        connectToServer()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Log.d(TAG, "RemoteCommandService started")
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }

    override fun onDestroy() {
        Log.d(TAG, "RemoteCommandService destroyed")
        disconnectFromServer()
        serviceScope.cancel()
        super.onDestroy()
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Remote Commands",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Background service for receiving remote device commands"
        }

        val notificationManager = getSystemService(NotificationManager::class.java)
        notificationManager?.createNotificationChannel(channel)
    }

    private fun createNotification() = NotificationCompat.Builder(this, CHANNEL_ID)
        .setContentTitle("Alpha Security")
        .setContentText("Remote command service active")
        .setSmallIcon(R.drawable.ic_alpha_logo)
        .setPriority(NotificationCompat.PRIORITY_LOW)
        .setOngoing(true)
        .build()

    private fun connectToServer() {
        try {
            val deviceId = getOrCreateDeviceId()
            if (deviceId == null) {
                Log.w(TAG, "No device ID available, cannot connect to server")
                return
            }

            // Parse server URL
            val serverUrl = ServerConfig.WEBSOCKET_URL
            Log.d(TAG, "Connecting to server: $serverUrl")

            val options = IO.Options().apply {
                reconnection = true
                reconnectionDelay = 5000
                reconnectionAttempts = Int.MAX_VALUE
                timeout = 30000
            }

            socket = IO.socket(serverUrl, options)

            socket?.apply {
                on(Socket.EVENT_CONNECT, onConnect)
                on(Socket.EVENT_DISCONNECT, onDisconnect)
                on(Socket.EVENT_CONNECT_ERROR, onConnectError)
                on("remote-command", onRemoteCommand)

                connect()
            }

        } catch (e: Exception) {
            Log.e(TAG, "Failed to connect to server", e)
        }
    }

    private fun disconnectFromServer() {
        try {
            socket?.apply {
                off()
                disconnect()
                close()
            }
            socket = null
            Log.d(TAG, "Disconnected from server")
        } catch (e: Exception) {
            Log.e(TAG, "Error disconnecting from server", e)
        }
    }

    private val onConnect = Emitter.Listener {
        Log.d(TAG, "Connected to server")

        // Join device room for receiving commands
        val deviceId = getOrCreateDeviceId()
        if (deviceId != null) {
            socket?.emit("join-device", deviceId)
            Log.d(TAG, "Joined device room: $deviceId")
        }
    }

    private val onDisconnect = Emitter.Listener {
        Log.d(TAG, "Disconnected from server")
    }

    private val onConnectError = Emitter.Listener { args ->
        Log.e(TAG, "Connection error: ${args.joinToString()}")
    }

    private val onRemoteCommand = Emitter.Listener { args ->
        try {
            val data = args[0] as JSONObject
            val commandId = data.optString("commandId")
            val commandType = data.optString("type")
            val commandData = data.optJSONObject("data")

            Log.d(TAG, "Received remote command: $commandType (ID: $commandId)")

            // Execute command on background thread
            serviceScope.launch(Dispatchers.IO) {
                executeCommand(commandType, commandData, commandId)
            }

        } catch (e: Exception) {
            Log.e(TAG, "Error processing remote command", e)
        }
    }

    private suspend fun executeCommand(commandType: String, data: JSONObject?, commandId: String) {
        try {
            Log.d(TAG, "Executing command: $commandType")

            when (commandType) {
                "LOCK_DEVICE" -> {
                    antiTheftManager.lockDevice()
                    sendCommandResponse(commandId, "completed", "Device locked successfully")
                }

                "UNLOCK_DEVICE" -> {
                    // Note: Unlock typically requires user authentication
                    // This just clears the lock state in the system
                    sendCommandResponse(commandId, "completed", "Unlock command received")
                }

                "REQUEST_LOCATION" -> {
                    val deviceId = getOrCreateDeviceId()
                    if (deviceId == null) {
                        sendCommandResponse(commandId, "failed", "No device ID available")
                    } else {
                        val uploaded = antiTheftManager.fetchLocationAndUpload(
                            serverUrl = ServerConfig.getLocationUploadUrl(),
                            deviceId = deviceId
                        )
                        val status = if (uploaded) "completed" else "failed"
                        val message = if (uploaded) {
                            "Location request processed"
                        } else {
                            "Failed to upload location"
                        }
                        sendCommandResponse(commandId, status, message)
                    }
                }

                "START_ALARM" -> {
                    antiTheftManager.startAlarm()
                    sendCommandResponse(commandId, "completed", "Alarm started")
                }

                "STOP_ALARM" -> {
                    antiTheftManager.stopAlarm()
                    sendCommandResponse(commandId, "completed", "Alarm stopped")
                }

                "FACTORY_RESET" -> {
                    val confirmed = data?.optBoolean("confirmed") ?: false
                    if (confirmed) {
                        antiTheftManager.wipeDevice()
                        sendCommandResponse(commandId, "completed", "Factory reset initiated")
                    } else {
                        sendCommandResponse(commandId, "failed", "Factory reset not confirmed")
                    }
                }

                else -> {
                    Log.w(TAG, "Unknown command type: $commandType")
                    sendCommandResponse(commandId, "failed", "Unknown command type")
                }
            }

        } catch (e: Exception) {
            Log.e(TAG, "Error executing command: $commandType", e)
            sendCommandResponse(commandId, "failed", "Error: ${e.message}")
        }
    }

    private fun sendCommandResponse(commandId: String, status: String, message: String) {
        try {
            val response = JSONObject().apply {
                put("commandId", commandId)
                put("status", status)
                put("message", message)
                put("timestamp", System.currentTimeMillis())
                put("deviceId", getOrCreateDeviceId())
            }

            socket?.emit("command-response", response)
            Log.d(TAG, "Command response sent: $commandId - $status")

        } catch (e: Exception) {
            Log.e(TAG, "Error sending command response", e)
        }
    }

    private fun getOrCreateDeviceId(): String? {
        // Get device ID from stored preferences or generate one
        val prefs = getSharedPreferences("alpha_device_prefs", Context.MODE_PRIVATE)
        var deviceId = prefs.getString("device_id", null)

        if (deviceId == null) {
            // Generate a unique device ID
            deviceId = "android_${android.provider.Settings.Secure.getString(
                contentResolver,
                android.provider.Settings.Secure.ANDROID_ID
            )}"
            prefs.edit().putString("device_id", deviceId).apply()
        }

        return deviceId
    }
}
