package com.example.alpha.data.auth

import android.content.Context
import android.util.Log
import com.example.alpha.config.ServerConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.encodeToString
import kotlinx.serialization.decodeFromString
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets

/**
 * Authentication API Service
 * Handles all authentication-related network calls to the Alpha Security Server
 */
class AuthApiService(private val context: Context) {
    
    private val json = Json {
        ignoreUnknownKeys = true
        coerceInputValues = true
        encodeDefaults = true
    }
    
    companion object {
        private const val TAG = "AuthApiService"
        private const val TIMEOUT_MS = 30000 // 30 seconds
    }
    
    /**
     * Login user with username and password
     */
    suspend fun login(username: String, password: String): AuthResponse {
        return withContext(Dispatchers.IO) {
            try {
                val request = LoginRequest(username, password)
                val response = makeAuthRequest(
                    endpoint = "${ServerConfig.API_BASE_URL}/auth/login",
                    requestBody = json.encodeToString(request)
                )
                
                if (response.isSuccessful) {
                    val responseBody = response.body
                    if (responseBody != null) {
                        try {
                            // Parse the actual server response format
                            val serverResponse = json.decodeFromString<ServerLoginResponse>(responseBody)
                            // Use the API key as our long‑lived credential in the Android app.
                            // The JWT token is only used internally on the server / dashboard.
                            AuthResponse(
                                success = true,
                                message = serverResponse.message,
                                token = serverResponse.user.apiKey,
                                user = User(
                                    id = serverResponse.user.id.toString(),
                                    username = serverResponse.user.username,
                                    email = serverResponse.user.email,
                                    apiKey = serverResponse.user.apiKey,
                                    createdAt = System.currentTimeMillis().toString()
                                )
                            )
                        } catch (e: Exception) {
                            Log.e(TAG, "Failed to parse login response: $responseBody", e)
                            AuthResponse(success = false, error = "Failed to parse server response")
                        }
                    } else {
                        AuthResponse(success = false, error = "Empty response")
                    }
                } else {
                    // Handle error response
                    val errorBody = response.errorBody
                    if (errorBody != null) {
                        try {
                            val errorResponse = json.decodeFromString<ErrorResponse>(errorBody)
                            AuthResponse(success = false, error = errorResponse.error)
                        } catch (e: Exception) {
                            AuthResponse(success = false, error = "HTTP ${response.code}: ${response.message}")
                        }
                    } else {
                        AuthResponse(success = false, error = "HTTP ${response.code}: ${response.message}")
                    }
                }
                
            } catch (e: IOException) {
                Log.e(TAG, "Network error during login", e)
                AuthResponse(success = false, error = "Network error: ${e.message}")
            } catch (e: Exception) {
                Log.e(TAG, "Unexpected error during login", e)
                AuthResponse(success = false, error = "Login failed: ${e.message}")
            }
        }
    }
    
    /**
     * Register new user
     */
    suspend fun register(username: String, email: String, password: String): AuthResponse {
        return withContext(Dispatchers.IO) {
            try {
                Log.d(TAG, "Starting registration for username: $username, email: $email")
                
                val request = RegisterRequest(username, email, password)
                val requestJson = json.encodeToString(request)
                Log.d(TAG, "Registration request: $requestJson")
                
                val endpoint = "${ServerConfig.API_BASE_URL}/auth/register"
                Log.d(TAG, "Registration endpoint: $endpoint")
                
                val response = makeAuthRequest(
                    endpoint = endpoint,
                    requestBody = requestJson
                )
                
                Log.d(TAG, "Registration response code: ${response.code}, successful: ${response.isSuccessful}")
                
                if (response.isSuccessful) {
                    val responseBody = response.body
                    Log.d(TAG, "Registration response body: $responseBody")
                    if (responseBody != null) {
                        try {
                            // Parse the actual server response format
                            val serverResponse = json.decodeFromString<ServerRegisterResponse>(responseBody)
                            Log.d(TAG, "Parsed registration response: userId=${serverResponse.userId}, username=${serverResponse.username}, apiKey=${serverResponse.apiKey}")
                            AuthResponse(
                                success = true,
                                message = serverResponse.message,
                                token = serverResponse.apiKey, // Use apiKey as token for device operations
                                user = User(
                                    id = serverResponse.userId.toString(),
                                    username = serverResponse.username,
                                    email = "", // Email not returned in registration response
                                    apiKey = serverResponse.apiKey,
                                    createdAt = System.currentTimeMillis().toString()
                                )
                            )
                        } catch (e: Exception) {
                            Log.e(TAG, "Failed to parse register response: $responseBody", e)
                            AuthResponse(success = false, error = "Failed to parse server response")
                        }
                    } else {
                        AuthResponse(success = false, error = "Empty response")
                    }
                } else {
                    val errorBody = response.errorBody
                    Log.w(TAG, "Registration failed with error response: $errorBody")
                    if (errorBody != null) {
                        try {
                            val errorResponse = json.decodeFromString<ErrorResponse>(errorBody)
                            Log.w(TAG, "Parsed error response: ${errorResponse.error}")
                            AuthResponse(success = false, error = errorResponse.error)
                        } catch (e: Exception) {
                            AuthResponse(success = false, error = "HTTP ${response.code}: ${response.message}")
                        }
                    } else {
                        AuthResponse(success = false, error = "HTTP ${response.code}: ${response.message}")
                    }
                }
                
            } catch (e: IOException) {
                Log.e(TAG, "Network error during registration", e)
                AuthResponse(success = false, error = "Network error: ${e.message}")
            } catch (e: Exception) {
                Log.e(TAG, "Unexpected error during registration", e)
                AuthResponse(success = false, error = "Registration failed: ${e.message}")
            }
        }
    }
    
/**
     * Update user profile (email and/or password)
     */
    suspend fun updateProfile(
        apiKey: String,
        email: String? = null,
        currentPassword: String? = null,
        newPassword: String? = null
    ): AuthResponse {
        return withContext(Dispatchers.IO) {
            try {
                val request = UpdateProfileRequest(
                    email = email,
                    currentPassword = currentPassword,
                    newPassword = newPassword
                )
                val requestJson = json.encodeToString(request)
                
                val url = URL("${ServerConfig.API_BASE_URL}/auth/profile")
                val connection = url.openConnection() as HttpURLConnection
                
                try {
                    connection.apply {
                        requestMethod = "PUT"
                        doOutput = true
                        connectTimeout = TIMEOUT_MS
                        readTimeout = TIMEOUT_MS
                        setRequestProperty("Content-Type", "application/json")
                        setRequestProperty("Accept", "application/json")
                        setRequestProperty("X-API-Key", apiKey)
                    }
                    
                    // Write request body
                    connection.outputStream.use { outputStream ->
                        outputStream.write(requestJson.toByteArray(StandardCharsets.UTF_8))
                        outputStream.flush()
                    }
                    
                    val responseCode = connection.responseCode
                    
                    if (responseCode in 200..299) {
                        val responseBody = connection.inputStream.bufferedReader().use { it.readText() }
                        val serverResponse = json.decodeFromString<ServerProfileUpdateResponse>(responseBody)
                        
                        AuthResponse(
                            success = true,
                            message = serverResponse.message,
                            user = User(
                                id = serverResponse.user.id.toString(),
                                username = serverResponse.user.username,
                                email = serverResponse.user.email,
                                apiKey = serverResponse.user.apiKey,
                                createdAt = System.currentTimeMillis().toString()
                            )
                        )
                    } else {
                        val errorBody = connection.errorStream?.bufferedReader()?.use { it.readText() }
                        if (errorBody != null) {
                            try {
                                val errorResponse = json.decodeFromString<ErrorResponse>(errorBody)
                                AuthResponse(success = false, error = errorResponse.error)
                            } catch (e: Exception) {
                                AuthResponse(success = false, error = "HTTP $responseCode")
                            }
                        } else {
                            AuthResponse(success = false, error = "HTTP $responseCode")
                        }
                    }
                } finally {
                    connection.disconnect()
                }
            } catch (e: IOException) {
                Log.e(TAG, "Network error during profile update", e)
                AuthResponse(success = false, error = "Network error: ${e.message}")
            } catch (e: Exception) {
                Log.e(TAG, "Unexpected error during profile update", e)
                AuthResponse(success = false, error = "Update failed: ${e.message}")
            }
        }
    }
    
    /**
     * Verify token / API key validity.
     *
     * The Android app uses the user's API key as its long‑lived credential.
     * We validate it by calling the /auth/profile endpoint with X-API-Key.
     */
    suspend fun verifyToken(token: String): Boolean {
        return withContext(Dispatchers.IO) {
            try {
                val url = URL("${ServerConfig.API_BASE_URL}/auth/profile")
                val connection = url.openConnection() as HttpURLConnection

                try {
                    connection.apply {
                        requestMethod = "GET"
                        connectTimeout = TIMEOUT_MS
                        readTimeout = TIMEOUT_MS
                        setRequestProperty("X-API-Key", token)
                        setRequestProperty("Accept", "application/json")
                    }

                    val responseCode = connection.responseCode
                    Log.d(TAG, "Token verification response code: $responseCode")

                    when (responseCode) {
                        in 200..299 -> true // API key is valid
                        401, 403 -> false   // Explicitly invalid credentials
                        else -> {
                            // For other errors (5xx, 4xx unrelated to auth), keep the session
                            Log.w(TAG, "Unexpected response while verifying token: HTTP $responseCode")
                            true
                        }
                    }
                } finally {
                    connection.disconnect()
                }
            } catch (e: Exception) {
                // Network or parsing error – don't force logout, just log it.
                Log.e(TAG, "Token verification error", e)
                true
            }
        }
    }
    
    /**
     * Make authenticated HTTP request
     */
    private fun makeAuthRequest(endpoint: String, requestBody: String): HttpResponse {
        val url = URL(endpoint)
        val connection = url.openConnection() as HttpURLConnection
        
        return try {
            connection.apply {
                requestMethod = "POST"
                doOutput = true
                connectTimeout = TIMEOUT_MS
                readTimeout = TIMEOUT_MS
                setRequestProperty("Content-Type", "application/json")
                setRequestProperty("Accept", "application/json")
                setRequestProperty("User-Agent", "Alpha-Security-Android/1.0")
            }
            
            // Write request body
            connection.outputStream.use { outputStream ->
                outputStream.write(requestBody.toByteArray(StandardCharsets.UTF_8))
                outputStream.flush()
            }
            
            val responseCode = connection.responseCode
            val responseMessage = connection.responseMessage ?: ""
            
            if (responseCode in 200..299) {
                val responseBody = connection.inputStream.bufferedReader().use { it.readText() }
                HttpResponse(responseCode, responseMessage, responseBody, null, true)
            } else {
                val errorBody = connection.errorStream?.bufferedReader()?.use { it.readText() }
                HttpResponse(responseCode, responseMessage, null, errorBody, false)
            }
            
        } catch (e: Exception) {
            Log.e(TAG, "HTTP request failed", e)
            HttpResponse(0, e.message ?: "Unknown error", null, null, false)
        } finally {
            connection.disconnect()
        }
    }
    
    /**
     * Make authenticated request with token
     */
    private fun makeAuthenticatedRequest(endpoint: String, token: String): HttpResponse {
        val url = URL(endpoint)
        val connection = url.openConnection() as HttpURLConnection
        
        return try {
            connection.apply {
                requestMethod = "GET"
                connectTimeout = TIMEOUT_MS
                readTimeout = TIMEOUT_MS
                setRequestProperty("Authorization", "Bearer $token")
                setRequestProperty("Content-Type", "application/json")
                setRequestProperty("Accept", "application/json")
            }
            
            val responseCode = connection.responseCode
            val responseMessage = connection.responseMessage ?: ""
            
            HttpResponse(responseCode, responseMessage, null, null, responseCode in 200..299)
            
        } catch (e: Exception) {
            Log.e(TAG, "Authenticated request failed", e)
            HttpResponse(0, e.message ?: "Unknown error", null, null, false)
        } finally {
            connection.disconnect()
        }
    }
    
    /**
     * HTTP Response data class
     */
    private data class HttpResponse(
        val code: Int,
        val message: String,
        val body: String?,
        val errorBody: String?,
        val isSuccessful: Boolean
    )
    
}

/**
 * Input validation utilities
 */
object AuthValidator {
    
    fun validateUsername(username: String): ValidationResult {
        return when {
            username.isBlank() -> ValidationResult(false, "Username cannot be empty")
            username.length < 3 -> ValidationResult(false, "Username must be at least 3 characters")
            username.length > 30 -> ValidationResult(false, "Username must be less than 30 characters")
            !username.matches(Regex("^[a-zA-Z0-9_]+$")) -> ValidationResult(false, "Username can only contain letters, numbers, and underscores")
            else -> ValidationResult(true)
        }
    }
    
    fun validateEmail(email: String): ValidationResult {
        return when {
            email.isBlank() -> ValidationResult(false, "Email cannot be empty")
            !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches() -> ValidationResult(false, "Please enter a valid email address")
            else -> ValidationResult(true)
        }
    }
    
    fun validatePassword(password: String): ValidationResult {
        return when {
            password.isBlank() -> ValidationResult(false, "Password cannot be empty")
            password.length < 6 -> ValidationResult(false, "Password must be at least 6 characters")
            password.length > 100 -> ValidationResult(false, "Password must be less than 100 characters")
            else -> ValidationResult(true)
        }
    }
    
    fun validatePasswordConfirmation(password: String, confirmPassword: String): ValidationResult {
        return when {
            confirmPassword.isBlank() -> ValidationResult(false, "Please confirm your password")
            password != confirmPassword -> ValidationResult(false, "Passwords do not match")
            else -> ValidationResult(true)
        }
    }
}