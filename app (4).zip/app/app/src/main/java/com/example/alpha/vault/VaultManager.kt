package com.example.alpha.vault

import android.content.Context
import android.content.SharedPreferences
import android.content.pm.PackageManager
import com.example.alpha.features.applock.AppLockService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * VaultManager handles secure storage items for App Vault.
 * Integrates with AppLockService to actually lock apps at the system level.
 */
class VaultManager(private val context: Context) {

    private val sharedPrefs: SharedPreferences = 
        context.getSharedPreferences("app_lock_prefs", Context.MODE_PRIVATE)
    
    private val _vaultItems = MutableStateFlow<List<String>>(emptyList())
    val vaultItems = _vaultItems.asStateFlow()
    
    private val _isAppLockEnabled = MutableStateFlow(false)
    val isAppLockEnabled = _isAppLockEnabled.asStateFlow()
    
    init {
        loadLockedApps()
        _isAppLockEnabled.value = sharedPrefs.getBoolean("app_lock_enabled", false)
    }

    /** Add a new secure item (app to lock) */
    fun addItem(item: String) {
        _vaultItems.value = _vaultItems.value + item
    }
    
    /** Remove a specific item from the vault */
    fun removeItem(item: String) {
        _vaultItems.value = _vaultItems.value - item
    }

    /** Clear all secure items */
    fun clearVault() {
        _vaultItems.value = emptyList()
    }
    
    /** Lock an app by package name */
    fun lockApp(packageName: String, appName: String) {
        val lockedApps = getLockedApps().toMutableSet()
        lockedApps.add(packageName)
        saveLockedApps(lockedApps)
        
        // Add to display list
        if (!_vaultItems.value.contains(appName)) {
            addItem(appName)
        }
    }
    
    /** Unlock an app by package name */
    fun unlockApp(packageName: String, appName: String) {
        val lockedApps = getLockedApps().toMutableSet()
        lockedApps.remove(packageName)
        saveLockedApps(lockedApps)
        
        removeItem(appName)
    }
    
    /** Get list of locked app package names */
    fun getLockedApps(): Set<String> {
        return sharedPrefs.getStringSet("locked_apps", emptySet()) ?: emptySet()
    }
    
    /** Check if app is locked */
    fun isAppLocked(packageName: String): Boolean {
        return getLockedApps().contains(packageName)
    }
    
    /** Get installed apps that can be locked */
    fun getInstallableApps(): List<AppInfo> {
        val pm = context.packageManager
        val packages = pm.getInstalledApplications(PackageManager.GET_META_DATA)
        
        return packages
            .filter { !it.packageName.startsWith("com.android") && 
                     !it.packageName.startsWith("com.google.android") &&
                     it.packageName != context.packageName }
            .map { AppInfo(it.packageName, it.loadLabel(pm).toString()) }
            .sortedBy { it.name }
    }
    
    /** Enable app lock protection */
    fun enableAppLock() {
        sharedPrefs.edit().putBoolean("app_lock_enabled", true).apply()
        _isAppLockEnabled.value = true
        AppLockService.start(context)
    }
    
    /** Disable app lock protection */
    fun disableAppLock() {
        sharedPrefs.edit().putBoolean("app_lock_enabled", false).apply()
        _isAppLockEnabled.value = false
        AppLockService.stop(context)
    }
    
    private fun saveLockedApps(apps: Set<String>) {
        sharedPrefs.edit().putStringSet("locked_apps", apps).apply()
        loadLockedApps()
    }
    
    private fun loadLockedApps() {
        val lockedPackages = getLockedApps()
        if (lockedPackages.isNotEmpty()) {
            val pm = context.packageManager
            val appNames = lockedPackages.mapNotNull { packageName ->
                try {
                    val appInfo = pm.getApplicationInfo(packageName, 0)
                    appInfo.loadLabel(pm).toString()
                } catch (e: Exception) {
                    null
                }
            }
            _vaultItems.value = appNames
        }
    }
}

data class AppInfo(
    val packageName: String,
    val name: String
)
