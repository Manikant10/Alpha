package com.example.alpha.data.device

import android.content.Context
import android.util.Log
import com.example.alpha.config.ServerConfig
import com.example.alpha.data.auth.AuthManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets

/**
 * Device API Service
 * Handles device registration, location updates, and command responses using API key authentication
 */
class DeviceApiService(private val context: Context) {
    
    private val json = Json {
        ignoreUnknownKeys = true
        coerceInputValues = true
    }
    
    private val authManager = AuthManager.getInstance(context)
    
    companion object {
        private const val TAG = "DeviceApiService"
    }
    
    /**
     * Register device with the server
     */
    suspend fun registerDevice(
        deviceId: String,
        deviceName: String,
        deviceModel: String,
        androidVersion: String
    ): DeviceApiResponse<DeviceRegistrationResponse> = withContext(Dispatchers.IO) {
        
        val apiKey = authManager.getCurrentApiKey()
        if (apiKey == null) {
            Log.e(TAG, "No API key available for device registration")
            return@withContext DeviceApiResponse.Error("No API key available. Please login first.")
        }
        
        try {
            val url = URL(ServerConfig.DEVICE_REGISTER_URL)
            val connection = url.openConnection() as HttpURLConnection
            
            connection.apply {
                requestMethod = "POST"
                setRequestProperty("Content-Type", "application/json")
                setRequestProperty("X-API-Key", apiKey)
                setRequestProperty("Accept", "application/json")
                connectTimeout = ServerConfig.CONNECTION_TIMEOUT.toInt()
                readTimeout = ServerConfig.READ_TIMEOUT.toInt()
                doOutput = true
            }
            
            val requestData = DeviceRegistrationRequest(
                deviceId = deviceId,
                deviceName = deviceName,
                deviceModel = deviceModel,
                androidVersion = androidVersion
            )
            
            val requestJson = json.encodeToString(DeviceRegistrationRequest.serializer(), requestData)
            Log.d(TAG, "Registering device: $requestJson")
            
            connection.outputStream.use { os ->
                val input = requestJson.toByteArray(StandardCharsets.UTF_8)
                os.write(input, 0, input.size)
            }
            
            val responseCode = connection.responseCode
            Log.d(TAG, "Device registration response code: $responseCode")
            
            val responseText = if (responseCode >= 400) {
                connection.errorStream?.bufferedReader()?.readText() ?: ""
            } else {
                connection.inputStream.bufferedReader().readText()
            }
            
            Log.d(TAG, "Device registration response: $responseText")
            
            when (responseCode) {
                HttpURLConnection.HTTP_CREATED -> {
                    try {
                        val response = json.decodeFromString<DeviceRegistrationResponse>(responseText)
                        DeviceApiResponse.Success(response)
                    } catch (e: Exception) {
                        Log.e(TAG, "Failed to parse registration response", e)
                        DeviceApiResponse.Error("Failed to parse server response")
                    }
                }
                HttpURLConnection.HTTP_UNAUTHORIZED -> {
                    DeviceApiResponse.Error("Invalid API key")
                }
                else -> {
                    try {
                        val errorResponse = json.decodeFromString<ErrorResponse>(responseText)
                        DeviceApiResponse.Error(errorResponse.error ?: "Registration failed")
                    } catch (e: Exception) {
                        DeviceApiResponse.Error("Registration failed with code: $responseCode")
                    }
                }
            }
            
        } catch (e: IOException) {
            Log.e(TAG, "Network error during device registration", e)
            DeviceApiResponse.Error("Network error: ${e.message}")
        } catch (e: Exception) {
            Log.e(TAG, "Unexpected error during device registration", e)
            DeviceApiResponse.Error("Registration error: ${e.message}")
        }
    }
    
    /**
     * Upload location data to server
     */
    suspend fun uploadLocation(
        deviceId: String,
        latitude: Double,
        longitude: Double,
        accuracy: Float? = null,
        altitude: Double? = null,
        bearing: Float? = null,
        speed: Float? = null,
        source: String = "gps",
        batteryLevel: Int? = null
    ): DeviceApiResponse<LocationUploadResponse> = withContext(Dispatchers.IO) {
        
        val apiKey = authManager.getCurrentApiKey()
        if (apiKey == null) {
            Log.e(TAG, "No API key available for location upload")
            return@withContext DeviceApiResponse.Error("No API key available. Please login first.")
        }
        
        try {
            val url = URL("${ServerConfig.API_BASE_URL}/location/$deviceId/update")
            val connection = url.openConnection() as HttpURLConnection
            
            connection.apply {
                requestMethod = "POST"
                setRequestProperty("Content-Type", "application/json")
                setRequestProperty("X-API-Key", apiKey)
                setRequestProperty("Accept", "application/json")
                connectTimeout = ServerConfig.CONNECTION_TIMEOUT.toInt()
                readTimeout = ServerConfig.READ_TIMEOUT.toInt()
                doOutput = true
            }
            
            val requestData = LocationUploadRequest(
                latitude = latitude,
                longitude = longitude,
                accuracy = accuracy,
                altitude = altitude,
                bearing = bearing,
                speed = speed,
                source = source,
                battery_level = batteryLevel
            )
            
            val requestJson = json.encodeToString(LocationUploadRequest.serializer(), requestData)
            Log.d(TAG, "Uploading location: $requestJson")
            
            connection.outputStream.use { os ->
                val input = requestJson.toByteArray(StandardCharsets.UTF_8)
                os.write(input, 0, input.size)
            }
            
            val responseCode = connection.responseCode
            Log.d(TAG, "Location upload response code: $responseCode")
            
            val responseText = if (responseCode >= 400) {
                connection.errorStream?.bufferedReader()?.readText() ?: ""
            } else {
                connection.inputStream.bufferedReader().readText()
            }
            
            Log.d(TAG, "Location upload response: $responseText")
            
            when (responseCode) {
                HttpURLConnection.HTTP_OK -> {
                    try {
                        val response = json.decodeFromString<LocationUploadResponse>(responseText)
                        DeviceApiResponse.Success(response)
                    } catch (e: Exception) {
                        Log.e(TAG, "Failed to parse location upload response", e)
                        DeviceApiResponse.Error("Failed to parse server response")
                    }
                }
                HttpURLConnection.HTTP_UNAUTHORIZED -> {
                    DeviceApiResponse.Error("Invalid API key")
                }
                HttpURLConnection.HTTP_NOT_FOUND -> {
                    DeviceApiResponse.Error("Device not found. Please register device first.")
                }
                else -> {
                    try {
                        val errorResponse = json.decodeFromString<ErrorResponse>(responseText)
                        DeviceApiResponse.Error(errorResponse.error ?: "Location upload failed")
                    } catch (e: Exception) {
                        DeviceApiResponse.Error("Location upload failed with code: $responseCode")
                    }
                }
            }
            
        } catch (e: IOException) {
            Log.e(TAG, "Network error during location upload", e)
            DeviceApiResponse.Error("Network error: ${e.message}")
        } catch (e: Exception) {
            Log.e(TAG, "Unexpected error during location upload", e)
            DeviceApiResponse.Error("Location upload error: ${e.message}")
        }
    }
    
    /**
     * Send heartbeat to server and check for pending commands
     */
    suspend fun sendHeartbeat(
        deviceId: String,
        status: String = "active",
        batteryLevel: Int? = null,
        networkType: String? = null
    ): DeviceApiResponse<HeartbeatResponse> = withContext(Dispatchers.IO) {
        
        val apiKey = authManager.getCurrentApiKey()
        if (apiKey == null) {
            return@withContext DeviceApiResponse.Error("No API key available. Please login first.")
        }
        
        try {
            val url = URL("${ServerConfig.API_BASE_URL}/devices/$deviceId/heartbeat")
            val connection = url.openConnection() as HttpURLConnection
            
            connection.apply {
                requestMethod = "POST"
                setRequestProperty("Content-Type", "application/json")
                setRequestProperty("X-API-Key", apiKey)
                connectTimeout = ServerConfig.CONNECTION_TIMEOUT.toInt()
                readTimeout = ServerConfig.READ_TIMEOUT.toInt()
                doOutput = true
            }
            
            val requestData = HeartbeatRequest(
                status = status,
                batteryLevel = batteryLevel,
                networkType = networkType
            )
            
            val requestJson = json.encodeToString(HeartbeatRequest.serializer(), requestData)
            
            connection.outputStream.use { os ->
                val input = requestJson.toByteArray(StandardCharsets.UTF_8)
                os.write(input, 0, input.size)
            }
            
            val responseCode = connection.responseCode
            val responseText = if (responseCode >= 400) {
                connection.errorStream?.bufferedReader()?.readText() ?: ""
            } else {
                connection.inputStream.bufferedReader().readText()
            }
            
            when (responseCode) {
                HttpURLConnection.HTTP_OK -> {
                    val response = json.decodeFromString<HeartbeatResponse>(responseText)
                    DeviceApiResponse.Success(response)
                }
                else -> {
                    val errorResponse = json.decodeFromString<ErrorResponse>(responseText)
                    DeviceApiResponse.Error(errorResponse.error ?: "Heartbeat failed")
                }
            }
            
        } catch (e: Exception) {
            Log.e(TAG, "Heartbeat error", e)
            DeviceApiResponse.Error("Heartbeat error: ${e.message}")
        }
    }
}

// Response wrapper
sealed class DeviceApiResponse<out T> {
    data class Success<T>(val data: T) : DeviceApiResponse<T>()
    data class Error(val message: String) : DeviceApiResponse<Nothing>()
}

// Data models
@Serializable
data class DeviceRegistrationRequest(
    val deviceId: String,
    val deviceName: String,
    val deviceModel: String,
    val androidVersion: String
)

@Serializable
data class DeviceRegistrationResponse(
    val message: String,
    val deviceId: String,
    val status: String
)

@Serializable
data class LocationUploadRequest(
    val latitude: Double,
    val longitude: Double,
    val accuracy: Float? = null,
    val altitude: Double? = null,
    val bearing: Float? = null,
    val speed: Float? = null,
    val source: String = "gps",
    val battery_level: Int? = null
)

@Serializable
data class LocationUploadResponse(
    val message: String,
    val locationId: Int,
    val timestamp: String
)

@Serializable
data class HeartbeatRequest(
    val status: String,
    val batteryLevel: Int? = null,
    val networkType: String? = null
)

@Serializable
data class HeartbeatResponse(
    val message: String,
    val pendingCommands: List<PendingCommand> = emptyList(),
    val timestamp: String
)

@Serializable
data class PendingCommand(
    val id: Int,
    val command_type: String,
    val command_data: String? = null,
    val sent_at: String
)

@Serializable
data class ErrorResponse(
    val error: String
)