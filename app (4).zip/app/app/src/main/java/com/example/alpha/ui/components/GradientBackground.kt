package com.example.alpha.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.alpha.ui.theme.*

@Composable
fun GradientBackground(
    modifier: Modifier = Modifier,
    variant: BackgroundVariant = BackgroundVariant.Primary,
    content: @Composable () -> Unit
) {
    // Animated floating orbs for visual depth
    val infiniteTransition = rememberInfiniteTransition(label = "background_animation")
    
    val orb1Offset by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 100f,
        animationSpec = infiniteRepeatable(
            animation = tween(15000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "orb1"
    )
    
    val orb2Offset by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = -80f,
        animationSpec = infiniteRepeatable(
            animation = tween(12000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "orb2"
    )
    
    val orb3Scale by infiniteTransition.animateFloat(
        initialValue = 0.8f,
        targetValue = 1.2f,
        animationSpec = infiniteRepeatable(
            animation = tween(8000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "orb3"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                when (variant) {
                    BackgroundVariant.Primary -> Brush.radialGradient(
                        colors = listOf(
                            BackgroundSecondary,
                            BackgroundPrimary,
                            Color(0xFF000408)
                        ),
                        radius = 1200f
                    )
                    BackgroundVariant.Security -> Brush.linearGradient(
                        colors = listOf(
                            Color(0xFF0F0F23),
                            BackgroundPrimary,
                            Color(0xFF1A0B2E)
                        )
                    )
                    BackgroundVariant.Success -> Brush.linearGradient(
                        colors = listOf(
                            Color(0xFF0A1A0A),
                            BackgroundPrimary,
                            Color(0xFF001A0F)
                        )
                    )
                    BackgroundVariant.Warning -> Brush.linearGradient(
                        colors = listOf(
                            Color(0xFF1A1A0A),
                            BackgroundPrimary,
                            Color(0xFF1A0F00)
                        )
                    )
                }
            )
    ) {
        // Floating orbs for depth and visual interest
        Box(
            modifier = Modifier
                .fillMaxSize()
                .offset(x = orb1Offset.dp, y = (orb1Offset * 0.7f).dp)
                .background(
                    PrimaryCyberBlue.copy(alpha = 0.03f),
                    CircleShape
                )
                .blur(50.dp)
                .scale(0.6f)
        )
        
        Box(
            modifier = Modifier
                .fillMaxSize()
                .offset(x = orb2Offset.dp, y = (-orb2Offset * 0.5f).dp)
                .background(
                    NeonPurple.copy(alpha = 0.02f),
                    CircleShape
                )
                .blur(60.dp)
                .scale(0.8f)
        )
        
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    NeonGreen.copy(alpha = 0.015f),
                    CircleShape
                )
                .blur(80.dp)
                .scale(orb3Scale * 0.4f)
        )

        content()
    }
}

enum class BackgroundVariant {
    Primary,
    Security,
    Success,
    Warning
}
