package com.example.alpha.features.permissions

import android.Manifest
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.content.pm.PermissionInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class AppPermissionInfo(
    val packageName: String,
    val appName: String,
    val permissions: List<PermissionDetail>,
    val isSystemApp: Boolean,
    val riskScore: Int,
    val installTime: Long
)

data class PermissionDetail(
    val name: String,
    val displayName: String,
    val description: String,
    val riskLevel: RiskLevel,
    val isGranted: Boolean,
    val category: PermissionCategory
)

enum class RiskLevel {
    LOW, MEDIUM, HIGH, CRITICAL
}

enum class PermissionCategory {
    LOCATION, CAMERA, MICROPHONE, CONTACTS, STORAGE, PHONE, SMS, CALENDAR, SENSORS, NETWORK, SYSTEM, OTHER
}

class PermissionsManager(private val context: Context) {
    private val packageManager = context.packageManager
    
    suspend fun analyzeAllApps(): List<AppPermissionInfo> = withContext(Dispatchers.IO) {
        val installedApps = packageManager.getInstalledApplications(PackageManager.GET_META_DATA)
        
        installedApps.mapNotNull { appInfo ->
            try {
                val packageInfo = packageManager.getPackageInfo(appInfo.packageName, PackageManager.GET_PERMISSIONS)
                createAppPermissionInfo(appInfo, packageInfo)
            } catch (e: Exception) {
                null
            }
        }.sortedByDescending { it.riskScore }
    }
    
    private fun createAppPermissionInfo(appInfo: ApplicationInfo, packageInfo: PackageInfo): AppPermissionInfo {
        val permissions = packageInfo.requestedPermissions?.mapIndexedNotNull { index, permissionName ->
            val isGranted = packageInfo.requestedPermissionsFlags?.get(index)?.and(PackageInfo.REQUESTED_PERMISSION_GRANTED) != 0
            createPermissionDetail(permissionName, isGranted)
        } ?: emptyList()
        
        val riskScore = calculateRiskScore(permissions)
        val isSystemApp = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
        
        return AppPermissionInfo(
            packageName = appInfo.packageName,
            appName = appInfo.loadLabel(packageManager).toString(),
            permissions = permissions,
            isSystemApp = isSystemApp,
            riskScore = riskScore,
            installTime = packageInfo.firstInstallTime
        )
    }
    
    private fun createPermissionDetail(permissionName: String, isGranted: Boolean): PermissionDetail {
        val permissionInfo = getPermissionInfo(permissionName)
        return PermissionDetail(
            name = permissionName,
            displayName = getPermissionDisplayName(permissionName),
            description = getPermissionDescription(permissionName),
            riskLevel = getPermissionRiskLevel(permissionName),
            isGranted = isGranted,
            category = getPermissionCategory(permissionName)
        )
    }
    
    private fun getPermissionInfo(permissionName: String): PermissionInfo? {
        return try {
            packageManager.getPermissionInfo(permissionName, 0)
        } catch (e: Exception) {
            null
        }
    }
    
    private fun calculateRiskScore(permissions: List<PermissionDetail>): Int {
        var totalScore = 0
        for (permission in permissions) {
            val score = when (permission.riskLevel) {
                RiskLevel.CRITICAL -> if (permission.isGranted) 25 else 10
                RiskLevel.HIGH -> if (permission.isGranted) 15 else 6
                RiskLevel.MEDIUM -> if (permission.isGranted) 8 else 3
                RiskLevel.LOW -> if (permission.isGranted) 2 else 1
            }
            totalScore += score
        }
        return totalScore
    }
    
    private fun getPermissionDisplayName(permission: String): String {
        return when (permission) {
            Manifest.permission.ACCESS_FINE_LOCATION -> "Precise Location"
            Manifest.permission.ACCESS_COARSE_LOCATION -> "Approximate Location"
            Manifest.permission.CAMERA -> "Camera"
            Manifest.permission.RECORD_AUDIO -> "Microphone"
            Manifest.permission.READ_CONTACTS -> "Read Contacts"
            Manifest.permission.WRITE_CONTACTS -> "Modify Contacts"
            Manifest.permission.READ_PHONE_STATE -> "Phone Information"
            Manifest.permission.CALL_PHONE -> "Make Phone Calls"
            Manifest.permission.SEND_SMS -> "Send SMS"
            Manifest.permission.READ_SMS -> "Read SMS"
            Manifest.permission.READ_EXTERNAL_STORAGE -> "Read Storage"
            Manifest.permission.WRITE_EXTERNAL_STORAGE -> "Write Storage"
            Manifest.permission.READ_CALENDAR -> "Read Calendar"
            Manifest.permission.WRITE_CALENDAR -> "Modify Calendar"
            Manifest.permission.ACCESS_NETWORK_STATE -> "Network State"
            Manifest.permission.INTERNET -> "Internet Access"
            Manifest.permission.WAKE_LOCK -> "Keep Device Awake"
            Manifest.permission.VIBRATE -> "Control Vibration"
            else -> permission.substringAfterLast('.').replace('_', ' ').lowercase().replaceFirstChar { it.uppercase() }
        }
    }
    
    private fun getPermissionDescription(permission: String): String {
        return when (permission) {
            Manifest.permission.ACCESS_FINE_LOCATION -> "Access your exact location using GPS, which can be used to track your movements."
            Manifest.permission.ACCESS_COARSE_LOCATION -> "Access your approximate location based on network sources."
            Manifest.permission.CAMERA -> "Take pictures and record videos using your device camera."
            Manifest.permission.RECORD_AUDIO -> "Record audio using your device microphone, potentially listening to conversations."
            Manifest.permission.READ_CONTACTS -> "Read all contacts stored on your device including names, phone numbers, and emails."
            Manifest.permission.WRITE_CONTACTS -> "Add, modify, or delete contacts on your device."
            Manifest.permission.READ_PHONE_STATE -> "Access phone information including phone number, device ID, and call status."
            Manifest.permission.CALL_PHONE -> "Make phone calls without your confirmation, which may incur charges."
            Manifest.permission.SEND_SMS -> "Send SMS messages without your confirmation, which may incur charges."
            Manifest.permission.READ_SMS -> "Read all SMS messages stored on your device."
            Manifest.permission.READ_EXTERNAL_STORAGE -> "Read all files and data stored on your device including photos, documents, and downloads."
            Manifest.permission.WRITE_EXTERNAL_STORAGE -> "Create, modify, or delete files and data on your device storage."
            Manifest.permission.READ_CALENDAR -> "Read all calendar events including private appointments and meetings."
            Manifest.permission.WRITE_CALENDAR -> "Add, modify, or delete calendar events on your device."
            Manifest.permission.ACCESS_NETWORK_STATE -> "Check network connectivity and connection type."
            Manifest.permission.INTERNET -> "Connect to the internet to send and receive data."
            Manifest.permission.WAKE_LOCK -> "Prevent your device from sleeping, which may drain battery faster."
            Manifest.permission.VIBRATE -> "Control device vibration for notifications and feedback."
            else -> "This permission allows the app to perform system-level operations that may affect device security or privacy."
        }
    }
    
    private fun getPermissionRiskLevel(permission: String): RiskLevel {
        return when (permission) {
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.CAMERA,
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.READ_SMS,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.SEND_SMS -> RiskLevel.CRITICAL
            
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.WRITE_CONTACTS,
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.READ_CALENDAR,
            Manifest.permission.WRITE_CALENDAR -> RiskLevel.HIGH
            
            Manifest.permission.ACCESS_NETWORK_STATE,
            Manifest.permission.WAKE_LOCK,
            Manifest.permission.VIBRATE -> RiskLevel.MEDIUM
            
            Manifest.permission.INTERNET -> RiskLevel.LOW
            
            else -> RiskLevel.MEDIUM
        }
    }
    
    private fun getPermissionCategory(permission: String): PermissionCategory {
        return when {
            permission.contains("LOCATION") -> PermissionCategory.LOCATION
            permission.contains("CAMERA") -> PermissionCategory.CAMERA
            permission.contains("AUDIO") || permission.contains("MICROPHONE") -> PermissionCategory.MICROPHONE
            permission.contains("CONTACT") -> PermissionCategory.CONTACTS
            permission.contains("STORAGE") || permission.contains("EXTERNAL") -> PermissionCategory.STORAGE
            permission.contains("PHONE") || permission.contains("CALL") -> PermissionCategory.PHONE
            permission.contains("SMS") -> PermissionCategory.SMS
            permission.contains("CALENDAR") -> PermissionCategory.CALENDAR
            permission.contains("SENSOR") -> PermissionCategory.SENSORS
            permission.contains("NETWORK") || permission.contains("INTERNET") -> PermissionCategory.NETWORK
            else -> PermissionCategory.SYSTEM
        }
    }
    
    fun openAppSettingsIntent(pkgName: String) =
        android.content.Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = android.net.Uri.parse("package:$pkgName")
            addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
        }
}
