package com.example.alpha

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.alpha.ui.components.ButtonStyle
import com.example.alpha.ui.components.GradientButton
import com.example.alpha.ui.theme.*

/**
 * ULTRA-SIMPLE BUTTON TEST
 * If you can't see button text here, the problem is very deep in the system
 */
class SimpleButtonTestActivity : ComponentActivity() {
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        setContent {
            AlphaTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    SimpleButtonTestScreen()
                }
            }
        }
    }
}

@Composable
fun SimpleButtonTestScreen() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(40.dp)
            .background(Color.Black),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(30.dp)
    ) {
        
        Text(
            text = "🔍 CAN YOU SEE THIS WHITE TEXT?",
            color = Color.White,
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold
        )
        
        Text(
            text = "If you can see the text above, but NOT the button text below, then the button rendering is the problem.",
            color = Color.White,
            fontSize = 16.sp,
            modifier = Modifier.padding(16.dp)
        )
        
        // Test the new simplified GradientButton
        GradientButton(
            text = "CAN YOU SEE THIS BUTTON TEXT?",
            icon = Icons.Filled.Star,
            color1 = Color.Blue,
            color2 = Color.Red
        ) {
            // Button click - if this works, button is functional
        }
        
        GradientButton(
            text = "THIS SHOULD BE WHITE TEXT TOO",
            icon = Icons.Filled.CheckCircle,
            color1 = WarningAmber,
            color2 = NeonOrange
        ) {
            // Button click
        }
        
        // Also test a basic Material3 button with forced white
        Button(
            onClick = { },
            colors = ButtonDefaults.buttonColors(
                containerColor = Color.Green,
                contentColor = Color.White
            ),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                "MATERIAL3 BUTTON - FORCED WHITE",
                color = Color.White,
                fontWeight = FontWeight.Bold
            )
        }
        
        Text(
            text = "📋 VISIBILITY TEST RESULTS:\n" +
                  "✅ Can you see the title text above?\n" +
                  "✅ Can you see the GradientButton text?\n" +
                  "✅ Can you see the Material3 button text?\n" +
                  "✅ Are all texts clearly visible?\n\n" +
                  "If ANY text is missing, please check device settings or restart the app.",
            color = Color.White,
            fontSize = 14.sp,
            modifier = Modifier.padding(16.dp)
        )
    }
}