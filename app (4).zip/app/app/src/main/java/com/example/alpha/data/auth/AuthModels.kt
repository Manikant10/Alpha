package com.example.alpha.data.auth

import kotlinx.serialization.Serializable

/**
 * Authentication Data Models for Alpha Security App
 */

// Request models
@Serializable
data class LoginRequest(
    val username: String,
    val password: String
)

@Serializable
data class RegisterRequest(
    val username: String,
    val email: String,
    val password: String
)

@Serializable
data class UpdateProfileRequest(
    val email: String? = null,
    val currentPassword: String? = null,
    val newPassword: String? = null
)

// Response models
@Serializable
data class AuthResponse(
    val success: Boolean = false,
    val message: String = "",
    val token: String? = null,
    val user: User? = null,
    val error: String? = null
)

@Serializable
data class User(
    val id: String,
    val username: String,
    val email: String,
    val apiKey: String,
    val createdAt: String,
    val lastLogin: String? = null
)

// Server response models (actual format from server)
@Serializable
data class ServerRegisterResponse(
    val message: String,
    val userId: Int,
    val apiKey: String,
    val username: String
)

@Serializable
data class ServerLoginResponse(
    val message: String,
    val token: String,
    val user: ServerUser
)

@Serializable
data class ServerUser(
    val id: Int,
    val username: String,
    val email: String,
    val apiKey: String
)

@Serializable
data class ServerProfileUpdateResponse(
    val message: String,
    val user: ServerUser
)

// Error response model
@Serializable
data class ErrorResponse(
    val error: String,
    val message: String? = null,
    val details: String? = null
)

// Auth state sealed class for UI state management
sealed class AuthState {
    object Idle : AuthState()
    object Loading : AuthState()
    data class Success(val user: User, val token: String) : AuthState()
    data class Error(val message: String) : AuthState()
}

// Validation results
data class ValidationResult(
    val isValid: Boolean,
    val errorMessage: String? = null
)

// Authentication preferences keys
object AuthPrefs {
    const val TOKEN_KEY = "auth_token"
    const val USER_KEY = "user_data"
    const val IS_LOGGED_IN = "is_logged_in"
    const val REMEMBER_ME = "remember_me"
}