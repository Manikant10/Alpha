package com.example.alpha.config

/**
 * Server Configuration for Alpha Security App
 * 
 * Update SERVER_BASE_URL when deploying to production
 */
object ServerConfig {
    // ⚠️ IMPORTANT: Update this URL when deploying your server
    // Development: Use your local IP (e.g., http://192.168.1.105:3000)
    // Production: Use your deployed server URL (e.g., https://your-domain.com)
    
    // ⚠️ TODO: Replace with your actual Render deployment URL
    private const val SERVER_BASE_URL = "https://alpha-security-server.onrender.com"
    // Alternative options:
    // private const val SERVER_BASE_URL = "https://your-app-name.herokuapp.com"  
    // private const val SERVER_BASE_URL = "https://your-app-name.up.railway.app"
    // private const val SERVER_BASE_URL = "http://your-server-ip:3000"
    
    // API Endpoints
    const val API_BASE_URL = "$SERVER_BASE_URL/api"
    const val DASHBOARD_URL = "$SERVER_BASE_URL/dashboard"
    
    // Specific endpoints
    const val LOCATION_UPLOAD_URL = "$API_BASE_URL/location/upload"
    const val DEVICE_REGISTER_URL = "$API_BASE_URL/devices/register"
    const val COMMAND_ENDPOINT = "$API_BASE_URL/commands"
    const val AUTH_LOGIN_URL = "$API_BASE_URL/auth/login"
    const val AUTH_REGISTER_URL = "$API_BASE_URL/auth/register"
    
    // WebSocket URL
    const val WEBSOCKET_URL = SERVER_BASE_URL
    
    // Connection settings
    const val CONNECTION_TIMEOUT = 30000L // 30 seconds
    const val READ_TIMEOUT = 30000L // 30 seconds
    const val WRITE_TIMEOUT = 30000L // 30 seconds
    
    // Retry settings
    const val MAX_RETRIES = 3
    const val RETRY_DELAY = 2000L // 2 seconds
    
    /**
     * Get the server URL for location upload
     */
    fun getLocationUploadUrl(): String = LOCATION_UPLOAD_URL
    
    /**
     * Get command URL for specific device
     */
    fun getCommandUrl(deviceId: String, command: String): String {
        return "$COMMAND_ENDPOINT/$deviceId/$command"
    }
    
    /**
     * Check if using development server (localhost/local IP)
     */
    fun isDevelopmentServer(): Boolean {
        return SERVER_BASE_URL.contains("localhost") || 
               SERVER_BASE_URL.contains("127.0.0.1") ||
               SERVER_BASE_URL.contains("192.168.") ||
               SERVER_BASE_URL.contains("10.0.") ||
               SERVER_BASE_URL.contains("172.")
    }
    
    /**
     * Get appropriate device ID based on environment
     */
    fun getDeviceId(): String {
        return if (isDevelopmentServer()) {
            "alpha-device-dev-001"
        } else {
            "alpha-device-${System.currentTimeMillis()}"
        }
    }
}