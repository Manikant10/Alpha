package com.example.alpha

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import com.example.alpha.data.auth.AuthManager
import com.example.alpha.data.auth.AuthState
import com.example.alpha.ui.components.GradientButton
import com.example.alpha.ui.theme.*
import kotlinx.coroutines.launch
import kotlin.random.Random

/**
 * AUTHENTICATION TEST ACTIVITY
 * Quick test to verify account creation and login works
 */
class AuthTestActivity : ComponentActivity() {
    
    private lateinit var authManager: AuthManager
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        authManager = AuthManager.getInstance(this)
        
        setContent {
            AlphaTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    AuthTestScreen()
                }
            }
        }
    }
    
    @Composable
    fun AuthTestScreen() {
        var testResults by remember { mutableStateOf("") }
        var isRunning by remember { mutableStateOf(false) }
        
        // Collect auth state
        val authState by authManager.authState.collectAsState()
        
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            
            Text(
                text = "🔐 AUTHENTICATION TEST",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
            
            Text(
                text = "Test account creation and login functionality",
                style = MaterialTheme.typography.bodyMedium,
                color = Color.White,
                modifier = Modifier
                    .background(Color.Black.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                    .padding(12.dp)
            )
            
            // Current Auth State
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color.Black.copy(alpha = 0.4f)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "🎯 CURRENT AUTH STATE",
                        color = Color.Cyan,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    val stateText = when (val currentState = authState) {
                        is AuthState.Idle -> "📋 Idle - No authentication attempts"
                        is AuthState.Loading -> "⏳ Loading - Processing authentication..."
                        is AuthState.Success -> "✅ Success - User: ${currentState.user.username}, API Key: ${currentState.user.apiKey.take(20)}..."
                        is AuthState.Error -> "❌ Error - ${currentState.message}"
                    }
                    
                    Text(
                        text = stateText,
                        color = Color.White,
                        fontSize = 14.sp
                    )
                }
            }
            
            // Test Buttons
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color.Black.copy(alpha = 0.4f)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "🧪 AUTHENTICATION TESTS",
                        color = Color.Cyan,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                    
                    GradientButton(
                        text = "Test Registration",
                        icon = Icons.Filled.PersonAdd,
                        color1 = SuccessGreen,
                        color2 = NeonGreen,
                        enabled = !isRunning
                    ) {
                        testRegistration { result ->
                            testResults += "📝 REGISTRATION TEST:\n$result\n\n"
                        }
                    }
                    
                    GradientButton(
                        text = "Test Login (Known User)",
                        icon = Icons.Filled.Login,
                        color1 = InfoBlue,
                        color2 = PrimaryCyberBlue,
                        enabled = !isRunning
                    ) {
                        testLogin { result ->
                            testResults += "🔑 LOGIN TEST:\n$result\n\n"
                        }
                    }
                    
                    GradientButton(
                        text = "Clear All Results",
                        icon = Icons.Filled.Clear,
                        color1 = ErrorRed,
                        color2 = NeonPink,
                        enabled = !isRunning
                    ) {
                        testResults = ""
                        authManager.resetAuthState()
                    }
                    
                    GradientButton(
                        text = "Logout",
                        icon = Icons.Filled.Logout,
                        color1 = WarningAmber,
                        color2 = NeonOrange,
                        enabled = !isRunning
                    ) {
                        authManager.logout()
                        testResults += "🚪 LOGGED OUT\n\n"
                    }
                }
            }
            
            // Results Section
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color.Black.copy(alpha = 0.4f)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "📋 TEST RESULTS",
                        color = Color.Cyan,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    if (isRunning) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            CircularProgressIndicator(
                                color = PrimaryCyberBlue,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Running authentication tests...", color = Color.White, fontSize = 14.sp)
                        }
                    } else {
                        Text(
                            text = testResults.ifBlank { 
                                "No tests run yet.\n\n" +
                                "🎯 WHAT TO TEST:\n" +
                                "1. Registration - Creates new account with random username\n" +
                                "2. Login - Tests login with known credentials\n" +
                                "3. Check auth state changes above\n\n" +
                                "✅ SUCCESS CRITERIA:\n" +
                                "• Registration returns success with API key\n" +
                                "• Login returns success with token\n" +
                                "• Auth state shows Success with user data\n" +
                                "• No 'no response' errors"
                            },
                            color = Color.White,
                            fontSize = 14.sp
                        )
                    }
                }
            }
            
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
    
    private fun testRegistration(callback: (String) -> Unit) {
        lifecycleScope.launch {
            // Use local variable for thread safety
            var localIsRunning = true
            try {
                // Generate random test user
                val randomNum = Random.nextInt(1000, 9999)
                val testUsername = "testuser$randomNum"
                val testEmail = "test$randomNum@example.com"
                val testPassword = "testpass123"
                
                val result = authManager.register(testUsername, testEmail, testPassword)
                
                val resultText = when (result) {
                    is AuthState.Success -> {
                        "✅ Registration SUCCESSFUL!\n" +
                        "👤 Username: ${result.user.username}\n" +
                        "🔑 API Key: ${result.user.apiKey.take(30)}...\n" +
                        "🎫 Token: ${result.token.take(30)}...\n" +
                        "📧 Email: ${result.user.email}\n" +
                        "🆔 User ID: ${result.user.id}"
                    }
                    is AuthState.Error -> {
                        "❌ Registration FAILED!\n" +
                        "💡 Error: ${result.message}\n" +
                        "🔍 Check server connection and response format"
                    }
                    else -> {
                        "❓ Registration returned unexpected state: $result"
                    }
                }
                
                callback(resultText)
                
            } catch (e: Exception) {
                callback("💥 Registration EXCEPTION!\n" +
                        "Error: ${e.message}\n" +
                        "Check logs for details")
            }
            localIsRunning = false
        }
    }
    
    private fun testLogin(callback: (String) -> Unit) {
        lifecycleScope.launch {
            var localIsRunning = true
            try {
                // Use a known test account (you might need to create this first)
                val testUsername = "testuser"
                val testPassword = "testpass"
                
                val result = authManager.login(testUsername, testPassword)
                
                val resultText = when (result) {
                    is AuthState.Success -> {
                        "✅ Login SUCCESSFUL!\n" +
                        "👤 Username: ${result.user.username}\n" +
                        "🔑 API Key: ${result.user.apiKey.take(30)}...\n" +
                        "🎫 Token: ${result.token.take(30)}...\n" +
                        "📧 Email: ${result.user.email}\n" +
                        "🆔 User ID: ${result.user.id}"
                    }
                    is AuthState.Error -> {
                        "⚠️ Login FAILED (might be expected)!\n" +
                        "💡 Error: ${result.message}\n" +
                        "📝 Note: User '$testUsername' might not exist\n" +
                        "✅ Server responded (good sign!)"
                    }
                    else -> {
                        "❓ Login returned unexpected state: $result"
                    }
                }
                
                callback(resultText)
                
            } catch (e: Exception) {
                callback("💥 Login EXCEPTION!\n" +
                        "Error: ${e.message}\n" +
                        "Check logs for details")
            }
            localIsRunning = false
        }
    }
}