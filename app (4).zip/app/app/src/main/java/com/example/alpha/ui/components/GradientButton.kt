package com.example.alpha.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.alpha.ui.theme.*

/**
 * SIMPLE GRADIENT BUTTON - GUARANTEED TEXT VISIBILITY
 * This version ensures all button text is always visible with white text
 */
@Composable
fun GradientButton(
    text: String,
    icon: ImageVector,
    color1: Color = PrimaryCyberBlue,
    color2: Color = NeonPurple,
    style: ButtonStyle = ButtonStyle.Primary,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    // Simple gradient background
    val backgroundBrush = when {
        !enabled -> Brush.horizontalGradient(
            listOf(
                color1.copy(alpha = 0.5f),
                color2.copy(alpha = 0.5f)
            )
        )
        else -> Brush.horizontalGradient(listOf(color1, color2))
    }
    
    // FORCE WHITE TEXT - No complex logic, just white
    val textColor = if (enabled) Color.White else Color.White.copy(alpha = 0.7f)
    
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(56.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(backgroundBrush)
            .clickable(enabled = enabled) { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Row(
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 16.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = text,
                tint = textColor,
                modifier = Modifier.size(20.dp)
            )
            Spacer(Modifier.width(8.dp))
            Text(
                text = text,
                color = textColor,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

enum class ButtonStyle {
    Primary,
    Secondary,
    Success,
    Warning,
    Error
}
