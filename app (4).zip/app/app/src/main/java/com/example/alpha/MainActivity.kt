package com.example.alpha

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.alpha.ui.*
import com.example.alpha.ui.auth.AuthScreen
import com.example.alpha.ui.theme.*
import com.example.alpha.data.auth.AuthManager
import com.example.alpha.data.auth.User
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AlphaTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    AppRoot()
                }
            }
        }
    }
}

@Composable
fun AppRoot() {
    val context = LocalContext.current
    val authManager = remember { AuthManager.getInstance(context) }
    
    // Observe authentication state
    val isLoggedIn by authManager.isLoggedIn.collectAsState()
    val currentUser by authManager.currentUser.collectAsState()
    
    // Auto-restore session from stored credentials
    // Token verification is handled in background, not blocking the UI
    
    // Start remote command service when authenticated
    LaunchedEffect(isLoggedIn) {
        if (isLoggedIn && currentUser != null) {
            try {
                com.example.alpha.service.RemoteCommandService.start(context)
            } catch (e: Exception) {
                Log.e("MainActivity", "Failed to start remote command service", e)
            }
        } else {
            try {
                com.example.alpha.service.RemoteCommandService.stop(context)
            } catch (e: Exception) {
                Log.e("MainActivity", "Failed to stop remote command service", e)
            }
        }
    }
    
    if (isLoggedIn && currentUser != null) {
        // User is authenticated, show main app
        AuthenticatedApp(user = currentUser!!, authManager = authManager)
    } else {
        // User is not authenticated, show auth screen
        AuthScreen(
            onAuthSuccess = { user, token ->
                // Authentication successful, AuthManager will handle state updates
            }
        )
    }
}

@Composable
fun AuthenticatedApp(
    user: User,
    authManager: AuthManager
) {
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val screen = remember { mutableStateOf("home") }
    val context = LocalContext.current

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                modifier = Modifier
                    .width(300.dp)
                    .fillMaxHeight(),
                drawerContainerColor = Color.Transparent
            ) {
                DrawerContent(
                    currentScreen = screen.value,
                    user = user,
                    onNavigate = { newScreen ->
                        screen.value = newScreen
                        scope.launch {
                            drawerState.close()
                        }
                    },
                    onContactUs = {
                        val intent = Intent(Intent.ACTION_SENDTO).apply {
                            data = Uri.parse("mailto:")
                            putExtra(Intent.EXTRA_EMAIL, arrayOf("support@alphasecurity.com"))
                            putExtra(Intent.EXTRA_SUBJECT, "Alpha Security Suite Support")
                            putExtra(Intent.EXTRA_TEXT, "Hi Alpha Security Team,\n\n")
                        }
                        context.startActivity(intent)
                        scope.launch {
                            drawerState.close()
                        }
                    },
                    onLogout = {
                        authManager.logout()
                        scope.launch {
                            drawerState.close()
                        }
                    }
                )
            }
        },
        content = {
            when (screen.value) {
                "home" -> HomeScreen(
                    onOpenAntiTheft = { screen.value = "antitheft" },
                    onOpenAntivirus = { screen.value = "antivirus" },
                    onOpenPermissions = { screen.value = "permissions" },
                    onOpenWebProtect = { screen.value = "webprotect" },
                    onOpenAppVault = { screen.value = "vault" },
                    onOpenDrawer = {
                        scope.launch {
                            drawerState.open()
                        }
                    }
                )
                "antitheft" -> AntiTheftScreen(
                    onBack = { screen.value = "home" },
                    onOpenDrawer = {
                        scope.launch {
                            drawerState.open()
                        }
                    }
                )
                "antivirus" -> AntivirusScreen(
                    onBack = { screen.value = "home" },
                    onOpenDrawer = {
                        scope.launch {
                            drawerState.open()
                        }
                    }
                )
                "permissions" -> PermissionsScreen(
                    onBack = { screen.value = "home" },
                    onOpenDrawer = {
                        scope.launch {
                            drawerState.open()
                        }
                    }
                )
                "webprotect" -> WebProtectScreen(
                    onBack = { screen.value = "home" },
                    onOpenDrawer = {
                        scope.launch {
                            drawerState.open()
                        }
                    }
                )
                "vault" -> AppVaultScreen(
                    onBack = { screen.value = "home" },
                    onOpenDrawer = {
                        scope.launch {
                            drawerState.open()
                        }
                    }
                )
                "profile" -> ProfileScreen(
                    onBack = { screen.value = "home" },
                    onOpenDrawer = {
                        scope.launch {
                            drawerState.open()
                        }
                    }
                )
            }
        }
    )
}

data class DrawerItem(
    val title: String,
    val icon: ImageVector,
    val screen: String,
    val description: String
)

@Composable
fun DrawerContent(
    currentScreen: String,
    user: User,
    onNavigate: (String) -> Unit,
    onContactUs: () -> Unit,
    onLogout: () -> Unit
) {
    val drawerItems = listOf(
        DrawerItem(
            title = "Home",
            icon = Icons.Filled.Home,
            screen = "home",
            description = "Main dashboard"
        ),
        DrawerItem(
            title = "Anti-Theft",
            icon = Icons.Filled.Security,
            screen = "antitheft",
            description = "Device protection"
        ),
        DrawerItem(
            title = "Antivirus",
            icon = Icons.Filled.Shield,
            screen = "antivirus",
            description = "Malware scanning"
        ),
        DrawerItem(
            title = "Permissions",
            icon = Icons.Filled.AdminPanelSettings,
            screen = "permissions",
            description = "App permissions"
        ),
        DrawerItem(
            title = "Web Protection",
            icon = Icons.Filled.Language,
            screen = "webprotect",
            description = "Browse safely"
        ),
        DrawerItem(
            title = "App Vault",
            icon = Icons.Filled.Lock,
            screen = "vault",
            description = "Secure your apps"
        )
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF0A0F29),
                        Color(0xFF1B0033),
                        Color(0xFF0A0F29)
                    )
                )
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            // User Header
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.linearGradient(
                            colors = listOf(
                                PrimaryCyberBlue.copy(alpha = 0.2f),
                                NeonPurple.copy(alpha = 0.1f)
                            )
                        ),
                        RoundedCornerShape(16.dp)
                    )
                    .border(
                        1.dp,
                        PrimaryCyberBlue.copy(alpha = 0.3f),
                        RoundedCornerShape(16.dp)
                    )
                    .padding(16.dp)
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        Icons.Filled.AccountCircle,
                        contentDescription = null,
                        tint = PrimaryCyberBlue,
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = user.username,
                        style = MaterialTheme.typography.titleMedium.copy(
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    Text(
                        text = user.email,
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = TextSecondary
                        )
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = "ALPHA SECURITY",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = PrimaryCyberBlue,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    )
                }
            }

            Spacer(Modifier.height(24.dp))

            // Navigation Items
            drawerItems.forEach { item ->
                DrawerNavigationItem(
                    item = item,
                    isSelected = currentScreen == item.screen,
                    onClick = { onNavigate(item.screen) }
                )
                Spacer(Modifier.height(8.dp))
            }

            Spacer(Modifier.weight(1f))

            // Bottom Section
            Divider(
                color = SurfaceGlass.copy(alpha = 0.3f),
                thickness = 1.dp
            )
            
            Spacer(Modifier.height(16.dp))
            
            // Profile Settings Button
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onNavigate("profile") }
                    .background(
                        Brush.linearGradient(
                            colors = listOf(
                                PrimaryCyberBlue.copy(alpha = 0.1f),
                                NeonPurple.copy(alpha = 0.1f)
                            )
                        ),
                        RoundedCornerShape(12.dp)
                    )
                    .border(
                        1.dp,
                        PrimaryCyberBlue.copy(alpha = 0.3f),
                        RoundedCornerShape(12.dp)
                    )
                    .padding(16.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Filled.Settings,
                        contentDescription = null,
                        tint = PrimaryCyberBlue,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "Settings",
                            style = MaterialTheme.typography.titleSmall.copy(
                                color = TextPrimary,
                                fontWeight = FontWeight.Bold
                            )
                        )
                        Text(
                            text = "Manage your profile",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = TextSecondary
                            )
                        )
                    }
                }
            }
            
            Spacer(Modifier.height(12.dp))
            
            // Logout Button
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onLogout() }
                    .background(
                        Brush.linearGradient(
                            colors = listOf(
                                ErrorRed.copy(alpha = 0.1f),
                                NeonPink.copy(alpha = 0.1f)
                            )
                        ),
                        RoundedCornerShape(12.dp)
                    )
                    .border(
                        1.dp,
                        ErrorRed.copy(alpha = 0.3f),
                        RoundedCornerShape(12.dp)
                    )
                    .padding(16.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Filled.Logout,
                        contentDescription = null,
                        tint = ErrorRed,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "Logout",
                            style = MaterialTheme.typography.titleSmall.copy(
                                color = TextPrimary,
                                fontWeight = FontWeight.Bold
                            )
                        )
                        Text(
                            text = "Sign out of your account",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = TextSecondary
                            )
                        )
                    }
                }
            }
            
            Spacer(Modifier.height(12.dp))

            // Contact Us
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onContactUs() }
                    .background(
                        Brush.linearGradient(
                            colors = listOf(
                                NeonGreen.copy(alpha = 0.1f),
                                PrimaryCyberBlue.copy(alpha = 0.1f)
                            )
                        ),
                        RoundedCornerShape(12.dp)
                    )
                    .border(
                        1.dp,
                        NeonGreen.copy(alpha = 0.3f),
                        RoundedCornerShape(12.dp)
                    )
                    .padding(16.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Filled.ContactSupport,
                        contentDescription = null,
                        tint = NeonGreen,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "Contact Us",
                            style = MaterialTheme.typography.titleSmall.copy(
                                color = TextPrimary,
                                fontWeight = FontWeight.Bold
                            )
                        )
                        Text(
                            text = "Get support & feedback",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = TextSecondary
                            )
                        )
                    }
                }
            }

            Spacer(Modifier.height(16.dp))

            // App Version
            Text(
                text = "Alpha Security Suite v1.0.0",
                style = MaterialTheme.typography.bodySmall.copy(
                    color = TextTertiary
                ),
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
fun DrawerNavigationItem(
    item: DrawerItem,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val backgroundColor = if (isSelected) {
        Brush.linearGradient(
            colors = listOf(
                PrimaryCyberBlue.copy(alpha = 0.2f),
                NeonPurple.copy(alpha = 0.15f)
            )
        )
    } else {
        Brush.linearGradient(
            colors = listOf(
                Color.Transparent,
                Color.Transparent
            )
        )
    }

    val borderColor = if (isSelected) {
        PrimaryCyberBlue.copy(alpha = 0.6f)
    } else {
        Color.Transparent
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .background(
                backgroundColor,
                RoundedCornerShape(12.dp)
            )
            .border(
                1.dp,
                borderColor,
                RoundedCornerShape(12.dp)
            )
            .padding(16.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                item.icon,
                contentDescription = null,
                tint = if (isSelected) PrimaryCyberBlue else TextSecondary,
                modifier = Modifier.size(24.dp)
            )
            Spacer(Modifier.width(16.dp))
            Column {
                Text(
                    text = item.title,
                    style = MaterialTheme.typography.titleSmall.copy(
                        color = if (isSelected) TextPrimary else TextSecondary,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                    )
                )
                Text(
                    text = item.description,
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = TextTertiary
                    )
                )
            }
        }
    }
}
