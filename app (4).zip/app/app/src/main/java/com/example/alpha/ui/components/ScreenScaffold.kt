package com.example.alpha.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.alpha.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScreenScaffold(
    title: String,
    onBack: () -> Unit,
    onOpenDrawer: (() -> Unit)? = null,
    backgroundVariant: BackgroundVariant = BackgroundVariant.Security,
    content: @Composable (PaddingValues) -> Unit
) {
    GradientBackground(variant = backgroundVariant) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Text(
                            title,
                            style = MaterialTheme.typography.titleLarge.copy(
                                color = TextPrimary,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                        )
                    },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(
                                Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Back",
                                tint = PrimaryCyberBlue
                            )
                        }
                    },
                    actions = {
                        onOpenDrawer?.let { drawerAction ->
                            IconButton(
                                onClick = drawerAction,
                                modifier = Modifier
                                    .background(
                                        PrimaryCyberBlue.copy(alpha = 0.1f),
                                        CircleShape
                                    )
                                    .border(
                                        1.dp,
                                        PrimaryCyberBlue.copy(alpha = 0.3f),
                                        CircleShape
                                    )
                            ) {
                                Icon(
                                    Icons.Filled.Menu,
                                    contentDescription = "Open menu",
                                    tint = PrimaryCyberBlue
                                )
                            }
                        }
                    },
                    colors = TopAppBarDefaults.mediumTopAppBarColors(
                        containerColor = Color.Transparent
                    )
                )
            },
            containerColor = Color.Transparent,
            contentWindowInsets = WindowInsets(0)
        ) { padding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(top = 8.dp) // Extra spacing to prevent header conflicts
            ) {
                content(PaddingValues(0.dp))
            }
        }
    }
}
