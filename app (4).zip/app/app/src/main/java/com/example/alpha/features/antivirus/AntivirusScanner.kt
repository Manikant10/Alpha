package com.example.alpha.features.antivirus

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build

class AntivirusScanner(private val context: Context) {
    
    // Known malicious package patterns (demo - in production, use cloud-based threat intelligence)
    private val maliciousPatterns = listOf(
        "com.test.malware",
        "com.fake.antivirus",
        "com.example.trojan",
        "com.suspicious.app"
    )
    
    // Suspicious permission combinations
    private val dangerousPermissionSets = setOf(
        setOf("android.permission.SEND_SMS", "android.permission.READ_CONTACTS"),
        setOf("android.permission.CAMERA", "android.permission.INTERNET", "android.permission.RECORD_AUDIO"),
        setOf("android.permission.READ_SMS", "android.permission.RECEIVE_SMS", "android.permission.INTERNET")
    )
    
    fun scanInstalledApps(): List<ScanResult> {
        val pm = context.packageManager
        val packages = pm.getInstalledApplications(PackageManager.GET_META_DATA)
        val results = mutableListOf<ScanResult>()
        
        for (app in packages) {
            val threatInfo = detectThreat(app, pm)
            results.add(
                ScanResult(
                    packageName = app.packageName,
                    label = app.loadLabel(pm).toString(),
                    suspicious = threatInfo.isSuspicious,
                    threatLevel = threatInfo.threatLevel,
                    threatType = threatInfo.threatType,
                    description = threatInfo.description
                )
            )
        }
        
        return results
    }
    
    private fun detectThreat(app: ApplicationInfo, pm: PackageManager): ThreatInfo {
        val packageName = app.packageName
        val isSystem = (app.flags and ApplicationInfo.FLAG_SYSTEM) != 0
        
        // Check for known malicious packages
        if (maliciousPatterns.any { packageName.contains(it, ignoreCase = true) }) {
            return ThreatInfo(
                isSuspicious = true,
                threatLevel = ThreatLevel.CRITICAL,
                threatType = "Malware Detected",
                description = "Known malicious application pattern detected"
            )
        }
        
        // Get app permissions
        val permissions = try {
            pm.getPackageInfo(packageName, PackageManager.GET_PERMISSIONS).requestedPermissions ?: emptyArray()
        } catch (e: Exception) {
            emptyArray()
        }
        
        // Check for dangerous permission combinations
        val appPermissionSet = permissions.toSet()
        for (dangerousSet in dangerousPermissionSets) {
            if (appPermissionSet.containsAll(dangerousSet)) {
                return ThreatInfo(
                    isSuspicious = true,
                    threatLevel = ThreatLevel.HIGH,
                    threatType = "Privacy Risk",
                    description = "App has suspicious permission combination that may compromise privacy"
                )
            }
        }
        
        // Check for excessive permissions in non-system apps
        if (!isSystem && permissions.size > 15) {
            val dangerousPerms = permissions.count { it.startsWith("android.permission.") && 
                (it.contains("SMS") || it.contains("CONTACTS") || it.contains("CAMERA") || 
                 it.contains("MICROPHONE") || it.contains("LOCATION") || it.contains("CALL"))
            }
            
            if (dangerousPerms >= 5) {
                return ThreatInfo(
                    isSuspicious = true,
                    threatLevel = ThreatLevel.MEDIUM,
                    threatType = "Over-privileged App",
                    description = "App requests excessive permissions ($dangerousPerms sensitive permissions)"
                )
            }
        }
        
        // Check for apps with INTERNET + sensitive data permissions
        if (!isSystem && appPermissionSet.contains("android.permission.INTERNET")) {
            val sensitiveDataPerms = listOf(
                "android.permission.READ_CONTACTS",
                "android.permission.READ_SMS",
                "android.permission.READ_CALL_LOG",
                "android.permission.ACCESS_FINE_LOCATION"
            )
            
            val hasSensitiveData = sensitiveDataPerms.any { appPermissionSet.contains(it) }
            if (hasSensitiveData) {
                return ThreatInfo(
                    isSuspicious = true,
                    threatLevel = ThreatLevel.LOW,
                    threatType = "Data Leak Risk",
                    description = "App can access sensitive data and has internet permission"
                )
            }
        }
        
        // App is safe
        return ThreatInfo(
            isSuspicious = false,
            threatLevel = ThreatLevel.SAFE,
            threatType = "Safe",
            description = "No threats detected"
        )
    }
}

data class ScanResult(
    val packageName: String,
    val label: String,
    val suspicious: Boolean,
    val threatLevel: ThreatLevel,
    val threatType: String,
    val description: String
)

enum class ThreatLevel {
    SAFE,
    LOW,
    MEDIUM,
    HIGH,
    CRITICAL
}

private data class ThreatInfo(
    val isSuspicious: Boolean,
    val threatLevel: ThreatLevel,
    val threatType: String,
    val description: String
)
