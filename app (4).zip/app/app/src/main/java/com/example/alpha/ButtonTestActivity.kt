package com.example.alpha

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.alpha.ui.components.ButtonStyle
import com.example.alpha.ui.components.GradientButton
import com.example.alpha.ui.theme.*

/**
 * Test Activity for Button Text Visibility
 * Use this to verify all button text is visible after the fixes
 */
class ButtonTestActivity : ComponentActivity() {
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        setContent {
            AlphaTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    ButtonTestScreen()
                }
            }
        }
    }
}

@Composable
fun ButtonTestScreen() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        
        Text(
            text = "🧪 Button Text Visibility Test",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            color = TextPrimary
        )
        
        Spacer(modifier = Modifier.height(16.dp))
        
        // Test all button styles
        GradientButton(
            text = "PRIMARY BUTTON",
            icon = Icons.Filled.Security,
            style = ButtonStyle.Primary,
            color1 = PrimaryCyberBlue,
            color2 = NeonPurple
        ) {
            // Test click
        }
        
        GradientButton(
            text = "SUCCESS BUTTON",
            icon = Icons.Filled.CheckCircle,
            style = ButtonStyle.Success,
            color1 = SuccessGreen,
            color2 = NeonGreen
        ) {
            // Test click
        }
        
        GradientButton(
            text = "WARNING BUTTON",
            icon = Icons.Filled.Warning,
            style = ButtonStyle.Warning,
            color1 = WarningAmber,
            color2 = NeonOrange
        ) {
            // Test click
        }
        
        GradientButton(
            text = "ERROR BUTTON",
            icon = Icons.Filled.Error,
            style = ButtonStyle.Error,
            color1 = ErrorRed,
            color2 = NeonPink
        ) {
            // Test click
        }
        
        GradientButton(
            text = "SECONDARY BUTTON",
            icon = Icons.Filled.Info,
            style = ButtonStyle.Secondary
        ) {
            // Test click
        }
        
        // Test disabled state
        GradientButton(
            text = "DISABLED BUTTON",
            icon = Icons.Filled.Block,
            style = ButtonStyle.Primary,
            enabled = false
        ) {
            // Test click
        }
        
        Spacer(modifier = Modifier.height(16.dp))
        
        // Standard Material3 Button test
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = SurfaceGlass)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    "Standard Material3 Buttons:",
                    style = MaterialTheme.typography.titleMedium,
                    color = TextPrimary
                )
                
                Button(
                    onClick = { },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("STANDARD BUTTON")
                }
                
                FilledTonalButton(
                    onClick = { },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("TONAL BUTTON")
                }
                
                OutlinedButton(
                    onClick = { },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("OUTLINED BUTTON")
                }
                
                TextButton(
                    onClick = { },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("TEXT BUTTON")
                }
            }
        }
        
        // Color reference
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = SurfaceGlass)
        ) {
            Column(
                modifier = Modifier.padding(16.dp)
            ) {
                Text(
                    "Color Reference:",
                    style = MaterialTheme.typography.titleMedium,
                    color = TextPrimary
                )
                Spacer(modifier = Modifier.height(8.dp))
                
                ColorSwatch("Primary Cyber Blue", PrimaryCyberBlue)
                ColorSwatch("Neon Green", NeonGreen)
                ColorSwatch("Success Green", SuccessGreen)
                ColorSwatch("Warning Amber", WarningAmber)
                ColorSwatch("Error Red", ErrorRed)
                ColorSwatch("Text Primary", TextPrimary)
            }
        }
    }
}

@Composable
private fun ColorSwatch(name: String, color: Color) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(24.dp)
                .background(color)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = name,
            style = MaterialTheme.typography.bodyMedium,
            color = TextSecondary
        )
    }
}