package com.example.alpha.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.alpha.data.auth.AuthManager
import com.example.alpha.ui.components.GradientBackground
import com.example.alpha.ui.components.BackgroundVariant
import com.example.alpha.ui.components.GradientButton
import com.example.alpha.ui.components.ButtonStyle
import com.example.alpha.ui.theme.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
    onBack: () -> Unit = {},
    onOpenDrawer: () -> Unit = {}
) {
    val context = LocalContext.current
    val authManager = remember { AuthManager.getInstance(context) }
    val currentUser by authManager.currentUser.collectAsState()
    val scope = rememberCoroutineScope()
    val focusManager = LocalFocusManager.current
    val scrollState = rememberScrollState()
    
    var email by remember { mutableStateOf(currentUser?.email ?: "") }
    var currentPassword by remember { mutableStateOf("") }
    var newPassword by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    
    var isUpdating by remember { mutableStateOf(false) }
    var updateMessage by remember { mutableStateOf<String?>(null) }
    var updateError by remember { mutableStateOf<String?>(null) }
    
    var showCurrentPassword by remember { mutableStateOf(false) }
    var showNewPassword by remember { mutableStateOf(false) }
    var showConfirmPassword by remember { mutableStateOf(false) }
    
    // Update email when user changes
    LaunchedEffect(currentUser) {
        email = currentUser?.email ?: ""
    }

    GradientBackground(variant = BackgroundVariant.Primary) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Row(
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                Icons.Filled.AccountCircle,
                                contentDescription = null,
                                tint = PrimaryCyberBlue,
                                modifier = Modifier.size(32.dp)
                            )
                            Spacer(Modifier.width(12.dp))
                            Column {
                                Text(
                                    "PROFILE & SETTINGS",
                                    style = MaterialTheme.typography.titleLarge.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = TextPrimary,
                                        letterSpacing = 1.sp
                                    )
                                )
                                Text(
                                    "Manage your account",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = PrimaryCyberBlue
                                    )
                                )
                            }
                        }
                    },
                    navigationIcon = {
                        IconButton(
                            onClick = onBack,
                            modifier = Modifier
                                .background(PrimaryCyberBlue.copy(alpha = 0.1f), CircleShape)
                                .border(1.dp, PrimaryCyberBlue.copy(alpha = 0.3f), CircleShape)
                        ) {
                            Icon(
                                Icons.Filled.ArrowBack,
                                contentDescription = "Back",
                                tint = PrimaryCyberBlue
                            )
                        }
                    },
                    actions = {
                        IconButton(
                            onClick = onOpenDrawer,
                            modifier = Modifier
                                .background(PrimaryCyberBlue.copy(alpha = 0.1f), CircleShape)
                                .border(1.dp, PrimaryCyberBlue.copy(alpha = 0.3f), CircleShape)
                        ) {
                            Icon(
                                Icons.Filled.Menu,
                                contentDescription = "Menu",
                                tint = PrimaryCyberBlue
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = Color.Transparent
                    )
                )
            },
            containerColor = Color.Transparent
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(horizontal = 20.dp)
                    .verticalScroll(scrollState),
                verticalArrangement = Arrangement.spacedBy(24.dp)
            ) {
                Spacer(Modifier.height(8.dp))
                
                // User Info Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.Transparent),
                    elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                Brush.linearGradient(
                                    colors = listOf(
                                        SurfaceGlass,
                                        SurfaceGlassBright,
                                        SurfaceGlass
                                    )
                                )
                            )
                            .border(
                                1.dp,
                                PrimaryCyberBlue.copy(alpha = 0.3f),
                                RoundedCornerShape(20.dp)
                            )
                            .padding(24.dp)
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(80.dp)
                                    .background(
                                        Brush.radialGradient(
                                            colors = listOf(
                                                PrimaryCyberBlue.copy(alpha = 0.3f),
                                                NeonPurple.copy(alpha = 0.2f)
                                            )
                                        ),
                                        CircleShape
                                    )
                                    .border(2.dp, PrimaryCyberBlue.copy(alpha = 0.5f), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    Icons.Filled.Person,
                                    contentDescription = null,
                                    tint = PrimaryCyberBlue,
                                    modifier = Modifier.size(40.dp)
                                )
                            }
                            
                            Spacer(Modifier.height(16.dp))
                            
                            Text(
                                text = currentUser?.username ?: "User",
                                style = MaterialTheme.typography.headlineSmall.copy(
                                    color = TextPrimary,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                            
                            Text(
                                text = currentUser?.email ?: "",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    color = TextSecondary
                                )
                            )
                            
                            Spacer(Modifier.height(8.dp))
                            
                            Text(
                                text = "ALPHA SECURITY USER",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = PrimaryCyberBlue,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp
                                )
                            )
                        }
                    }
                }
                
                // Update Email Section
                Text(
                    "UPDATE EMAIL",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = TextAccent,
                        letterSpacing = 1.sp
                    )
                )
                
                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("Email Address") },
                    leadingIcon = {
                        Icon(Icons.Filled.Email, contentDescription = null)
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = PrimaryCyberBlue,
                        unfocusedBorderColor = TextSecondary,
                        focusedLabelColor = PrimaryCyberBlue,
                        cursorColor = PrimaryCyberBlue,
                        focusedLeadingIconColor = PrimaryCyberBlue
                    ),
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Email,
                        imeAction = ImeAction.Next
                    ),
                    singleLine = true
                )
                
                // Change Password Section
                Text(
                    "CHANGE PASSWORD",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = TextAccent,
                        letterSpacing = 1.sp
                    ),
                    modifier = Modifier.padding(top = 8.dp)
                )
                
                OutlinedTextField(
                    value = currentPassword,
                    onValueChange = { currentPassword = it },
                    label = { Text("Current Password") },
                    leadingIcon = {
                        Icon(Icons.Filled.Lock, contentDescription = null)
                    },
                    trailingIcon = {
                        IconButton(onClick = { showCurrentPassword = !showCurrentPassword }) {
                            Icon(
                                if (showCurrentPassword) Icons.Filled.Visibility else Icons.Filled.VisibilityOff,
                                contentDescription = if (showCurrentPassword) "Hide password" else "Show password"
                            )
                        }
                    },
                    visualTransformation = if (showCurrentPassword) VisualTransformation.None else PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = PrimaryCyberBlue,
                        unfocusedBorderColor = TextSecondary,
                        focusedLabelColor = PrimaryCyberBlue,
                        cursorColor = PrimaryCyberBlue,
                        focusedLeadingIconColor = PrimaryCyberBlue
                    ),
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Password,
                        imeAction = ImeAction.Next
                    ),
                    singleLine = true
                )
                
                OutlinedTextField(
                    value = newPassword,
                    onValueChange = { newPassword = it },
                    label = { Text("New Password") },
                    leadingIcon = {
                        Icon(Icons.Filled.VpnKey, contentDescription = null)
                    },
                    trailingIcon = {
                        IconButton(onClick = { showNewPassword = !showNewPassword }) {
                            Icon(
                                if (showNewPassword) Icons.Filled.Visibility else Icons.Filled.VisibilityOff,
                                contentDescription = if (showNewPassword) "Hide password" else "Show password"
                            )
                        }
                    },
                    visualTransformation = if (showNewPassword) VisualTransformation.None else PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = PrimaryCyberBlue,
                        unfocusedBorderColor = TextSecondary,
                        focusedLabelColor = PrimaryCyberBlue,
                        cursorColor = PrimaryCyberBlue,
                        focusedLeadingIconColor = PrimaryCyberBlue
                    ),
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Password,
                        imeAction = ImeAction.Next
                    ),
                    singleLine = true
                )
                
                OutlinedTextField(
                    value = confirmPassword,
                    onValueChange = { confirmPassword = it },
                    label = { Text("Confirm New Password") },
                    leadingIcon = {
                        Icon(Icons.Filled.CheckCircle, contentDescription = null)
                    },
                    trailingIcon = {
                        IconButton(onClick = { showConfirmPassword = !showConfirmPassword }) {
                            Icon(
                                if (showConfirmPassword) Icons.Filled.Visibility else Icons.Filled.VisibilityOff,
                                contentDescription = if (showConfirmPassword) "Hide password" else "Show password"
                            )
                        }
                    },
                    visualTransformation = if (showConfirmPassword) VisualTransformation.None else PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = PrimaryCyberBlue,
                        unfocusedBorderColor = TextSecondary,
                        focusedLabelColor = PrimaryCyberBlue,
                        cursorColor = PrimaryCyberBlue,
                        focusedLeadingIconColor = PrimaryCyberBlue
                    ),
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Password,
                        imeAction = ImeAction.Done
                    ),
                    keyboardActions = KeyboardActions(
                        onDone = { focusManager.clearFocus() }
                    ),
                    singleLine = true
                )
                
                // Status Messages
                if (updateMessage != null) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = SuccessGreen.copy(alpha = 0.1f)
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .padding(16.dp)
                                .fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                Icons.Filled.CheckCircle,
                                contentDescription = null,
                                tint = SuccessGreen
                            )
                            Spacer(Modifier.width(12.dp))
                            Text(
                                text = updateMessage!!,
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    color = SuccessGreen
                                )
                            )
                        }
                    }
                }
                
                if (updateError != null) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = ErrorRed.copy(alpha = 0.1f)
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .padding(16.dp)
                                .fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                Icons.Filled.Error,
                                contentDescription = null,
                                tint = ErrorRed
                            )
                            Spacer(Modifier.width(12.dp))
                            Text(
                                text = updateError!!,
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    color = ErrorRed
                                )
                            )
                        }
                    }
                }
                
                // Update Button
                GradientButton(
                    text = if (isUpdating) "UPDATING..." else "UPDATE PROFILE",
                    icon = Icons.Filled.Save,
                    style = ButtonStyle.Primary,
                    color1 = PrimaryCyberBlue,
                    color2 = NeonPurple,
                    enabled = !isUpdating
                ) {
                    scope.launch {
                        updateMessage = null
                        updateError = null
                        
                        // Validate inputs
                        val emailChanged = email != currentUser?.email
                        val passwordChanged = newPassword.isNotEmpty()
                        
                        if (!emailChanged && !passwordChanged) {
                            updateError = "No changes to update"
                            return@launch
                        }
                        
                        if (passwordChanged) {
                            if (currentPassword.isEmpty()) {
                                updateError = "Current password required to change password"
                                return@launch
                            }
                            
                            if (newPassword.length < 6) {
                                updateError = "New password must be at least 6 characters"
                                return@launch
                            }
                            
                            if (newPassword != confirmPassword) {
                                updateError = "New passwords do not match"
                                return@launch
                            }
                        }
                        
                        isUpdating = true
                        
                        try {
                            val result = authManager.updateProfile(
                                email = if (emailChanged) email else null,
                                currentPassword = if (passwordChanged) currentPassword else null,
                                newPassword = if (passwordChanged) newPassword else null
                            )
                            
                            if (result.success) {
                                updateMessage = "Profile updated successfully!"
                                // Clear password fields
                                currentPassword = ""
                                newPassword = ""
                                confirmPassword = ""
                            } else {
                                updateError = result.error ?: "Failed to update profile"
                            }
                        } catch (e: Exception) {
                            updateError = "Error: ${e.message}"
                        } finally {
                            isUpdating = false
                        }
                    }
                }
                
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}
