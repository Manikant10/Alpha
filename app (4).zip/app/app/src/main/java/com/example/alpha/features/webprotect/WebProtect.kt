package com.example.alpha.features.webprotect

import android.content.Context
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.URL

class WebProtect(private val context: Context) {
    
    // Known malicious domain patterns (demo list - in production, use cloud-based threat feeds)
    private val maliciousDomains = setOf(
        "malware.com",
        "phishing-site.com",
        "fake-bank.com",
        "virus.download",
        "malicious-ads.net",
        "scam-website.org",
        "fake-login.com",
        "trojan.download"
    )
    
    // Suspicious patterns in URLs
    private val suspiciousPatterns = listOf(
        "free-download",
        "crack",
        "keygen",
        "hack",
        "phishing",
        "malware",
        "virus",
        "trojan"
    )
    
    // Known safe top-level domains
    private val trustedTLDs = setOf(
        ".edu",
        ".gov",
        ".mil"
    )
    
    /**
     * Check if a URL is safe to visit
     * @param url The URL to check
     * @return SafetyResult containing safety status and details
     */
    suspend fun checkUrlSafety(url: String): SafetyResult = withContext(Dispatchers.IO) {
        try {
            val normalizedUrl = url.lowercase().trim()
            
            // Extract domain from URL
            val domain = extractDomain(normalizedUrl)
            
            // Check against known malicious domains
            if (maliciousDomains.any { domain.contains(it) }) {
                return@withContext SafetyResult(
                    isSafe = false,
                    threatLevel = ThreatSeverity.HIGH,
                    reason = "Known malicious domain detected",
                    category = ThreatCategory.MALWARE
                )
            }
            
            // Check for suspicious patterns
            val suspiciousPattern = suspiciousPatterns.find { normalizedUrl.contains(it) }
            if (suspiciousPattern != null) {
                return@withContext SafetyResult(
                    isSafe = false,
                    threatLevel = ThreatSeverity.MEDIUM,
                    reason = "URL contains suspicious keyword: $suspiciousPattern",
                    category = ThreatCategory.SUSPICIOUS
                )
            }
            
            // Check for IP addresses (often used for phishing)
            if (domain.matches(Regex("^\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}$"))) {
                return@withContext SafetyResult(
                    isSafe = false,
                    threatLevel = ThreatSeverity.MEDIUM,
                    reason = "Direct IP address access may be suspicious",
                    category = ThreatCategory.SUSPICIOUS
                )
            }
            
            // Check for trusted TLDs
            if (trustedTLDs.any { domain.endsWith(it) }) {
                return@withContext SafetyResult(
                    isSafe = true,
                    threatLevel = ThreatSeverity.NONE,
                    reason = "Trusted domain",
                    category = ThreatCategory.SAFE
                )
            }
            
            // Check for HTTPS
            val isHttps = normalizedUrl.startsWith("https://")
            if (!isHttps && normalizedUrl.startsWith("http://")) {
                return@withContext SafetyResult(
                    isSafe = true,
                    threatLevel = ThreatSeverity.LOW,
                    reason = "Unencrypted HTTP connection (not HTTPS)",
                    category = ThreatCategory.UNENCRYPTED
                )
            }
            
            // Default: URL appears safe
            SafetyResult(
                isSafe = true,
                threatLevel = ThreatSeverity.NONE,
                reason = "No threats detected",
                category = ThreatCategory.SAFE
            )
            
        } catch (e: Exception) {
            Log.e("WebProtect", "Error checking URL safety: ${e.message}")
            SafetyResult(
                isSafe = true,
                threatLevel = ThreatSeverity.NONE,
                reason = "Unable to verify - proceeding with caution",
                category = ThreatCategory.UNKNOWN
            )
        }
    }
    
    /**
     * Legacy method for backward compatibility
     */
    suspend fun isUrlSafe(url: String): Boolean {
        val result = checkUrlSafety(url)
        return result.isSafe
    }
    
    private fun extractDomain(url: String): String {
        return try {
            val urlObj = URL(url)
            urlObj.host.lowercase()
        } catch (e: Exception) {
            // If URL parsing fails, try to extract domain manually
            url.replace("http://", "")
                .replace("https://", "")
                .split("/")[0]
                .split("?")[0]
                .lowercase()
        }
    }
    
    /**
     * Get statistics about protected browsing
     */
    fun getProtectionStats(): ProtectionStats {
        // In a real implementation, track these from SharedPreferences or database
        return ProtectionStats(
            threatsBlocked = 0,
            sitesScanned = 0,
            lastScanTime = System.currentTimeMillis()
        )
    }
}

data class SafetyResult(
    val isSafe: Boolean,
    val threatLevel: ThreatSeverity,
    val reason: String,
    val category: ThreatCategory
)

enum class ThreatSeverity {
    NONE,
    LOW,
    MEDIUM,
    HIGH,
    CRITICAL
}

enum class ThreatCategory {
    SAFE,
    MALWARE,
    PHISHING,
    SUSPICIOUS,
    UNENCRYPTED,
    UNKNOWN
}

data class ProtectionStats(
    val threatsBlocked: Int,
    val sitesScanned: Int,
    val lastScanTime: Long
)
