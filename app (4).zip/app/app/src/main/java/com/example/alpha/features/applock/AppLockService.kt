package com.example.alpha.features.applock

import android.app.*
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.alpha.MainActivity
import kotlinx.coroutines.*

class AppLockService : Service() {
    
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private var monitoringJob: Job? = null
    private lateinit var sharedPrefs: SharedPreferences
    private var lastCheckedApp: String? = null
    
    companion object {
        private const val TAG = "AppLockService"
        private const val CHANNEL_ID = "app_lock_service"
        private const val NOTIFICATION_ID = 1001
        private const val CHECK_INTERVAL_MS = 1000L
        
        fun start(context: Context) {
            val intent = Intent(context, AppLockService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }
        
        fun stop(context: Context) {
            context.stopService(Intent(context, AppLockService::class.java))
        }
    }
    
    override fun onCreate() {
        super.onCreate()
        sharedPrefs = getSharedPreferences("app_lock_prefs", Context.MODE_PRIVATE)
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, createNotification())
        Log.d(TAG, "AppLockService created")
    }
    
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Log.d(TAG, "AppLockService started")
        startMonitoring()
        return START_STICKY
    }
    
    override fun onBind(intent: Intent?): IBinder? = null
    
    override fun onDestroy() {
        super.onDestroy()
        monitoringJob?.cancel()
        scope.cancel()
        Log.d(TAG, "AppLockService destroyed")
    }
    
    private fun startMonitoring() {
        monitoringJob?.cancel()
        monitoringJob = scope.launch {
            while (isActive) {
                try {
                    checkForegroundApp()
                } catch (e: Exception) {
                    Log.e(TAG, "Error monitoring apps: ${e.message}")
                }
                delay(CHECK_INTERVAL_MS)
            }
        }
    }
    
    private fun checkForegroundApp() {
        val usageStatsManager = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val currentTime = System.currentTimeMillis()
        
        // Get app usage in the last 2 seconds
        val stats = usageStatsManager.queryUsageStats(
            UsageStatsManager.INTERVAL_DAILY,
            currentTime - 2000,
            currentTime
        )
        
        if (stats.isNullOrEmpty()) {
            return
        }
        
        // Find the most recently used app
        val sortedStats = stats.sortedByDescending { it.lastTimeUsed }
        val currentApp = sortedStats.firstOrNull()?.packageName
        
        // Skip if it's the same app we just checked or if it's our own app
        if (currentApp == null || 
            currentApp == lastCheckedApp || 
            currentApp == packageName ||
            currentApp == "com.android.systemui") {
            return
        }
        
        lastCheckedApp = currentApp
        
        // Check if this app is locked
        val lockedApps = getLockedApps()
        if (currentApp in lockedApps) {
            Log.d(TAG, "Locked app detected: $currentApp")
            showLockScreen(currentApp)
        }
    }
    
    private fun showLockScreen(packageName: String) {
        val intent = Intent(this, AppLockActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
            putExtra("locked_package", packageName)
        }
        startActivity(intent)
    }
    
    private fun getLockedApps(): Set<String> {
        return sharedPrefs.getStringSet("locked_apps", emptySet()) ?: emptySet()
    }
    
    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "App Lock Protection",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Monitors and locks protected apps"
                setShowBadge(false)
            }
            
            val notificationManager = getSystemService(NotificationManager::class.java)
            notificationManager.createNotificationChannel(channel)
        }
    }
    
    private fun createNotification(): Notification {
        val notificationIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            notificationIntent,
            PendingIntent.FLAG_IMMUTABLE
        )
        
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("App Lock Active")
            .setContentText("Your apps are protected")
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }
}
