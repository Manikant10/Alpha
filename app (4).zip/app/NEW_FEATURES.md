# Alpha Security Suite - New Features Documentation

## Overview
This document describes the major enhancements made to the Alpha Security Suite mobile app and web dashboard to provide persistent login, profile management, and real-time synchronization between mobile and web platforms.

---

## ✅ Features Implemented

### 1. Persistent Login
**Problem**: Users had to login every time they opened the app.

**Solution**: 
- Removed aggressive token verification that was logging users out
- AuthManager now automatically restores authentication state from secure storage (SharedPreferences)
- Users stay logged in indefinitely until they explicitly logout
- Token verification still happens in the background without disrupting user experience

**Files Modified**:
- `app/src/main/java/com/example/alpha/MainActivity.kt`
- `app/src/main/java/com/example/alpha/data/auth/AuthManager.kt`

---

### 2. Profile Management

**Features Added**:
- New Profile/Settings screen accessible from side menu
- Update email address
- Change password (requires current password verification)
- Beautiful futuristic UI matching the app theme
- Real-time validation and error handling

**New Files**:
- `app/src/main/java/com/example/alpha/ui/ProfileScreen.kt` - Complete profile management UI

**Files Modified**:
- `app/src/main/java/com/example/alpha/MainActivity.kt` - Added profile screen navigation
- `app/src/main/java/com/example/alpha/data/auth/AuthManager.kt` - Added updateProfile method
- `app/src/main/java/com/example/alpha/data/auth/AuthApiService.kt` - Added profile update API
- `app/src/main/java/com/example/alpha/data/auth/AuthModels.kt` - Added request/response models
- `alpha-server/routes/auth.js` - Added PUT /api/auth/profile endpoint

**How to Use**:
1. Open the app side menu (hamburger icon)
2. Tap "Settings" at the bottom
3. Update email or password as needed
4. Tap "UPDATE PROFILE" to save changes

---

### 3. Web Dashboard Remote Control

**Features**:
- Lock/unlock phone remotely
- Start/stop alarm
- Request device location
- Factory reset (with confirmation)
- All features work in real-time via WebSocket

**Already Existed**: The web dashboard at `http://localhost:3000/dashboard` already had complete UI and backend API for all remote control features.

**Server Endpoints** (already functional):
- `POST /api/commands/:deviceId/lock`
- `POST /api/commands/:deviceId/unlock`
- `POST /api/commands/:deviceId/alarm/start`
- `POST /api/commands/:deviceId/alarm/stop`
- `POST /api/commands/:deviceId/locate`
- `POST /api/commands/:deviceId/wipe`

---

### 4. Real-Time Mobile & Web Synchronization

**Implementation**:
- Created `RemoteCommandService` - A background service that maintains WebSocket connection
- Runs as foreground service with notification
- Automatically starts when user logs in
- Listens for commands from web dashboard
- Executes commands via `AntiTheftManager`
- Sends command responses back to server

**New Files**:
- `app/src/main/java/com/example/alpha/service/RemoteCommandService.kt`

**Files Modified**:
- `app/src/main/AndroidManifest.xml` - Registered the service
- `app/build.gradle.kts` - Added Socket.IO client dependency

**Supported Commands**:
- `LOCK_DEVICE` - Locks the phone with a message
- `UNLOCK_DEVICE` - Clears lock state
- `REQUEST_LOCATION` - Tracks and uploads GPS location
- `START_ALARM` - Plays loud alarm
- `STOP_ALARM` - Stops the alarm
- `FACTORY_RESET` - Wipes all device data (requires confirmation)

**How It Works**:
```
┌─────────────────┐         WebSocket         ┌──────────────────┐
│  Web Dashboard  │ ◄────────────────────────► │   Alpha Server   │
└─────────────────┘                            └──────────────────┘
                                                         │
                                                   WebSocket
                                                         │
                                                         ▼
                                              ┌──────────────────────┐
                                              │  Android Device      │
                                              │  RemoteCommandService│
                                              └──────────────────────┘
```

1. User opens web dashboard and logs in
2. User clicks on a device and selects an action (e.g., "Lock Device")
3. Web dashboard sends command to server via HTTP API
4. Server stores command in database and broadcasts via WebSocket
5. Mobile app receives command in real-time
6. `RemoteCommandService` executes the command
7. Mobile app sends response back to server
8. Web dashboard updates to show command completed

---

## 🚀 Setup & Testing

### Prerequisites
1. **Node.js** installed (for server)
2. **Android Studio** (for mobile app)
3. **Active network connection** (mobile and web must reach the server)

### Starting the Server
```bash
cd alpha-server
npm install  # First time only
npm start
```

Server runs on: `http://localhost:3000`
Dashboard URL: `http://localhost:3000/dashboard`

### Running the Mobile App
1. Open Android Studio
2. Load the `C:\app` project
3. Sync Gradle (it will download Socket.IO dependency)
4. Run on emulator or physical device

### Testing Workflow

#### 1. Test Persistent Login
1. Register/login to the mobile app
2. Use the app normally
3. **Close the app completely** (swipe away from recents)
4. **Reopen the app**
5. ✅ You should be automatically logged in without seeing the login screen

#### 2. Test Profile Update
1. Open mobile app
2. Open side menu (☰)
3. Tap "Settings"
4. Change email or password
5. Tap "UPDATE PROFILE"
6. ✅ Success message should appear
7. Logout and login with new credentials

#### 3. Test Web Dashboard Control

**Lock Phone**:
1. Open web dashboard
2. Login with same credentials as mobile app
3. Find your device in the list
4. Click on the device
5. Click "Lock Device"
6. ✅ Phone should lock with a message

**Start Alarm**:
1. In device modal, click "Start Alarm"
2. ✅ Phone should play loud alarm sound
3. Click "Stop Alarm" to stop it

**Locate Device**:
1. Click "Locate Device"
2. ✅ GPS location should update on the map

#### 4. Test Real-Time Sync
1. Keep mobile app running in background
2. Open web dashboard on another device/browser
3. Send lock/alarm commands from web
4. ✅ Commands should execute on mobile within 1-2 seconds
5. Check mobile app notification bar for "Remote command service active"

---

## 📱 Mobile App Permissions

The app requires these permissions for remote commands:
- ✅ `INTERNET` - Network communication
- ✅ `FOREGROUND_SERVICE` - Background WebSocket service
- ✅ `POST_NOTIFICATIONS` - Service notification
- ✅ `ACCESS_FINE_LOCATION` - GPS tracking
- ✅ `DEVICE_ADMIN` - Lock and wipe capabilities (user must enable)

**Device Admin Setup**:
1. Go to Anti-Theft screen
2. Tap "Enable Device Admin"
3. Grant permission in system settings

---

## 🔐 Security Considerations

### API Authentication
- All API requests use API key in `X-API-Key` header
- Each user has unique API key generated on registration
- API keys are stored securely in SharedPreferences (encrypted)

### Password Changes
- Requires current password verification
- Minimum 6 characters
- Passwords are bcrypt hashed on server (12 rounds)

### Remote Commands
- Only authenticated users can send commands
- Commands are tied to device ownership
- WebSocket connection requires valid device ID
- Factory reset requires explicit confirmation

### Data Storage
- User credentials: Encrypted SharedPreferences
- Auth tokens: Secure storage
- API keys: Never logged or exposed in UI

---

## 🛠️ Troubleshooting

### Mobile App Not Receiving Commands

**Check 1: WebSocket Connection**
- Look for logs: `RemoteCommandService: Connected to server`
- If not connected, check server URL in `ServerConfig.kt`

**Check 2: Network**
- Ensure mobile device can reach server (same network or public IP)
- Check firewall settings

**Check 3: Service Running**
- Pull down notification shade
- Look for "Alpha Security - Remote command service active"

### Profile Update Fails

**Error: "Current password is incorrect"**
- Double-check the password you entered
- Password is case-sensitive

**Error: "Not authenticated"**
- Logout and login again
- Check network connection

### Web Dashboard Not Showing Device

**Check 1: Device Registration**
- Device must be registered with server
- Check if API key is configured in mobile app

**Check 2: Device Online Status**
- Device must have active internet connection
- WebSocket connection must be established

---

## 📊 Database Schema Updates

No database changes were required. The existing schema already supports:
- User authentication
- Device management  
- Command history
- Location tracking

---

## 🎯 Future Enhancements

Potential improvements for future versions:
1. **Two-factor authentication** for profile changes
2. **Biometric authentication** for web dashboard login
3. **Push notifications** when commands are executed
4. **Command scheduling** (e.g., lock phone at specific time)
5. **Geofencing** (auto-lock when device leaves area)
6. **Remote screenshot** capability
7. **Device activity logs** in profile screen
8. **Multiple device management** from single account

---

## 📝 Code Quality

### New Dependencies
```kotlin
// build.gradle.kts
implementation("io.socket:socket.io-client:2.1.0")
```

### Code Structure
```
app/
├── service/
│   └── RemoteCommandService.kt        # WebSocket service
├── ui/
│   └── ProfileScreen.kt               # Profile management UI
└── data/auth/
    ├── AuthManager.kt                 # Profile update logic
    ├── AuthApiService.kt              # API calls
    └── AuthModels.kt                  # Data models

alpha-server/
└── routes/
    └── auth.js                        # Profile update endpoint
```

---

## ✨ Summary

All requested features have been successfully implemented:

✅ **Persistent Login** - Users stay logged in automatically  
✅ **Profile Management** - Change email and password from mobile app  
✅ **Web Dashboard Control** - Lock, unlock, alarm from web browser  
✅ **Real-Time Sync** - Instant command execution via WebSocket  

The application now provides a complete, professional security suite with seamless synchronization between mobile and web platforms!

---

**Questions or Issues?**
Check the logs in Android Studio (Logcat) for mobile app debugging.
Check server console for backend issues.
All services log extensively for troubleshooting.
