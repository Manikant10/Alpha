# FCM Server Example Commands

**IMPORTANT:** Do not expose your FCM server key in client apps. These are example commands to run from a secure server.

## Legacy HTTP (example)
Replace YOUR_SERVER_KEY and DEVICE_FCM_TOKEN with actual values.

```
curl -X POST -H "Authorization: key=YOUR_SERVER_KEY" -H "Content-Type: application/json" -d '{
  "to": "DEVICE_FCM_TOKEN",
  "data": {
    "command": "lock"
  }
}' https://fcm.googleapis.com/fcm/send
```

## Example commands (data.command values)
- lock  => devicePolicyManager.lockNow()
- alarm => broadcast to app to play alarm
- locate => signal app to capture & upload location
- wipe => devicePolicyManager.wipeData(0) (destructive — requires admin)

## Recommended (secure) approach
Use the FCM HTTP v1 API with OAuth2, or send commands from your server that
additionally include a signed token you verify in the app before executing any destructive command.
