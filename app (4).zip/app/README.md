# Alpha - Android Security Suite (Scaffold)

This is a ready-to-open Android Studio project scaffold for *Alpha* with Kotlin + Jetpack Compose.
It includes feature stubs for Anti-Theft, Permissions manager, Antivirus scanner, Web Protection, App Lock and a futuristic UI.

## How to open
1. Download and unzip the project.
2. Open Android Studio and choose 'Open' -> select the project folder.
3. If prompted for Gradle wrapper, Android Studio may download a matching Gradle distribution. Alternatively install Gradle locally.

## SDK
- compileSdk = 34, targetSdk = 34, minSdk = 26

## Notes
- This scaffold contains placeholders and TODOs where sensitive integrations (Device Admin, Firebase, backend APIs) are required.
- Do not ship device admin or remote wipe features without clear user consent and robust server authentication.



## Added integrations
- Firebase FCM client service added at `app/src/main/java/com/example/alpha/fcm/AlphaFirebaseService.kt`.
- Device Admin receiver and helper at `app/src/main/java/com/example/alpha/device/AdminReceiver.kt`.
- Anti-theft UI screen and broadcast handlers at `app/src/main/java/com/example/alpha/ui/AntiTheftScreen.kt`.
- Antivirus UI screen at `app/src/main/java/com/example/alpha/ui/AntivirusScreen.kt`.

### Firebase setup (client)
1. Add Firebase to the project via the Firebase Console and download `google-services.json` into `app/`.
2. Add the `com.google.gms:google-services` Gradle plugin to the project if you want auto integration.
3. Register the device token from logs (AlphaFirebaseService.onNewToken) with your server.

### Security notes
- Always authenticate remote commands on the server and verify them on the device before performing destructive actions like wipe.
- Seek explicit user consent before enabling Device Admin; provide clear warnings in the UX.
